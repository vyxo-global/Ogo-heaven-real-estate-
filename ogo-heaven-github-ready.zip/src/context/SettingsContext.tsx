import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { isFirebaseConfigured } from '../lib/firebase';
import { DEFAULT_SETTINGS, mergeWithDefaults, SiteSettings } from '../lib/settings';

const STORAGE_KEY = 'ogo_heavens_site_settings_v1';

interface SettingsContextValue {
  settings: SiteSettings;
  saving: boolean;
  error: string | null;
  save: (settings: SiteSettings) => Promise<void>;
  refresh: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(() => {
    // Load from localStorage cache for instant render
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) return mergeWithDefaults(JSON.parse(cached));
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sync from Firestore on mount (if configured)
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      if (!isFirebaseConfigured) return;
      try {
        const { initializeApp } = await import('firebase/app');
        const { getFirestore, doc, getDoc } = await import('firebase/firestore');
        // Import firebase config dynamically to avoid re-initialization issues
        const { firebaseConfig } = await import('../lib/firebase');

        let app;
        try {
          app = initializeApp(firebaseConfig);
        } catch {
          // Already initialized
          const { getApps, getApp } = await import('firebase/app');
          app = getApps()[0] || getApp();
        }
        const db = getFirestore(app);
        const snap = await getDoc(doc(db, 'site', 'settings'));
        if (!cancelled && snap.exists()) {
          const merged = mergeWithDefaults(snap.data() as Partial<SiteSettings>);
          setSettings(merged);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
          } catch {
            // ignore
          }
        }
      } catch (err) {
        console.warn('Failed to load settings from Firestore', err);
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const save = async (next: SiteSettings) => {
    setSaving(true);
    setError(null);
    try {
      const withTimestamp = { ...next, updatedAt: new Date().toISOString() };

      // Always update localStorage cache
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(withTimestamp));
      } catch {
        // ignore
      }

      // Persist to Firestore if configured
      if (isFirebaseConfigured) {
        try {
          const { initializeApp, getApps, getApp } = await import('firebase/app');
          const { getFirestore, doc, setDoc } = await import('firebase/firestore');
          const { firebaseConfig } = await import('../lib/firebase');

          const app = getApps()[0] || initializeApp(firebaseConfig) || getApp();
          const db = getFirestore(app);
          await setDoc(doc(db, 'site', 'settings'), withTimestamp, { merge: true });
        } catch (err) {
          console.error('Failed to persist settings to Firestore', err);
          // We still keep the localStorage update, so admin sees their change.
        }
      }

      setSettings(withTimestamp);
    } catch (err: any) {
      setError(err.message || 'Unable to save settings');
      throw err;
    } finally {
      setSaving(false);
    }
  };

  const refresh = async () => {
    if (!isFirebaseConfigured) return;
    try {
      const { initializeApp, getApps, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc } = await import('firebase/firestore');
      const { firebaseConfig } = await import('../lib/firebase');
      const app = getApps()[0] || initializeApp(firebaseConfig) || getApp();
      const db = getFirestore(app);
      const snap = await getDoc(doc(db, 'site', 'settings'));
      if (snap.exists()) {
        const merged = mergeWithDefaults(snap.data() as Partial<SiteSettings>);
        setSettings(merged);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
        } catch {
          // ignore
        }
      }
    } catch (err) {
      console.warn('Failed to refresh settings', err);
    }
  };

  return (
    <SettingsContext.Provider value={{ settings, saving, error, save, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used inside <SettingsProvider>');
  return ctx;
}
