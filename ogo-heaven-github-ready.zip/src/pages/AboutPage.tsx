import { Link } from 'react-router-dom';
import { Phone, Mail, Award, TrendingUp, MapPin } from 'lucide-react';
import { teamMembers } from '../data/properties';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gray-900 pt-28 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">About Us</span>
          </div>
          <h1 className="font-serif text-3xl lg:text-5xl text-white font-bold mb-4">About Ogo Heavens</h1>
          <p className="text-gray-400 max-w-2xl text-lg leading-relaxed">
            We're a Nigerian real estate firm built on the belief that finding a home should be personal, transparent, and transformational.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">Our Story</span>
            <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold mt-2 mb-6">Rooted in Nigeria,<br />driven by excellence</h2>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>Founded in 2010 by Chioma Okafor, Ogo Heavens Realtors Limited was born from a simple observation: buying or selling property in Nigeria is one of the most significant financial decisions a family can make, yet the experience was often shrouded in complexity and lack of transparency.</p>
              <p>Chioma set out to build a firm where every client relationship is a partnership. Today, with offices in Lagos and Abuja, our team of dedicated agents brings local expertise, data-driven insights, and an unwavering commitment to white-glove service across Nigeria's most sought-after locations — from Banana Island to Maitama, Lekki to Asokoro.</p>
              <p>Our name captures our mission: every home should feel like heaven, and every transaction should bring <em>ogo</em> — glory — to the families we serve.</p>
            </div>
            <div className="flex gap-6 mt-8">
              {[
                { value: '₦50B+', label: 'Total Sales Volume' },
                { value: '350+', label: 'Families Served' },
                { value: '98%', label: 'Client Satisfaction' },
              ].map(({ value, label }) => (
                <div key={label}>
                  <div className="text-2xl font-bold text-gray-900 font-serif">{value}</div>
                  <div className="text-xs text-gray-500">{label}</div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600"
              alt="Our team"
              className="rounded-2xl w-full aspect-[4/3] object-cover shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="bg-white py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">Our Team</span>
            <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold mt-2">Meet the people behind every key</h2>
            <p className="text-gray-500 mt-3 max-w-lg mx-auto">Experienced, passionate, and deeply connected to Nigerian communities.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map(member => (
              <div key={member.id} className="group bg-gray-50 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="aspect-[3/4] overflow-hidden">
                  <img
                    src={member.photo}
                    alt={member.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-serif text-lg font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-accent-600 text-sm font-medium">{member.role}</p>
                  <p className="text-gray-500 text-sm mt-3 leading-relaxed line-clamp-3">{member.bio}</p>

                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {member.specialties.map(s => (
                      <span key={s} className="text-xs px-2.5 py-1 rounded-full bg-white border border-gray-100 text-gray-600">{s}</span>
                    ))}
                  </div>

                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-200">
                    <div className="text-xs text-gray-500">
                      <span className="font-semibold text-gray-900 block">{member.transactions}+</span> Transactions
                    </div>
                    <div className="text-xs text-gray-500">
                      <span className="font-semibold text-gray-900 block">{member.yearsOfExperience} yrs</span> Experience
                    </div>
                  </div>

                  <div className="flex gap-2 mt-4">
                    <a href={`tel:${member.phone.replace(/\s/g, '')}`} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-gray-900 text-white text-xs font-medium hover:bg-gray-800 transition-colors">
                      <Phone size={13} /> Call
                    </a>
                    <a href={`mailto:${member.email}`} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border border-gray-200 text-gray-700 text-xs font-medium hover:bg-gray-100 transition-colors">
                      <Mail size={13} /> Email
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="text-center mb-14">
          <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold">What we stand for</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: Award, title: 'Integrity First', description: 'Radical transparency in every transaction. No hidden fees, no title surprises — just honest guidance you can trust.' },
            { icon: TrendingUp, title: 'Market Mastery', description: 'Every agent on our team is a local market expert, armed with real-time data and deep neighborhood insights across Nigeria.' },
            { icon: MapPin, title: 'Community Roots', description: 'We don\'t just sell properties — we invest in the communities we serve through local partnerships and philanthropy.' },
          ].map(({ icon: Icon, title, description }) => (
            <div key={title} className="text-center p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all">
              <div className="w-14 h-14 rounded-xl bg-gray-900 flex items-center justify-center mx-auto mb-5">
                <Icon size={24} className="text-accent-400" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-900 mb-3">{title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
