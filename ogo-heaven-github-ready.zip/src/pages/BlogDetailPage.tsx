import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, ArrowLeft, Share2, AlertCircle } from 'lucide-react';
import { blogPosts } from '../data/properties';

export default function BlogDetailPage() {
  const { slug } = useParams();
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle size={48} className="mx-auto text-gray-300 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Article Not Found</h2>
          <Link to="/blog" className="px-6 py-3 rounded-full bg-gray-900 text-white font-medium text-sm">Back to Blog</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gray-900 pt-28 pb-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/blog" className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors mb-4">
            <ArrowLeft size={15} /> Back to Blog
          </Link>
          <span className="inline-block px-3 py-1 rounded-full bg-accent-500/20 text-accent-300 text-xs font-semibold mb-4">{post.category}</span>
          <h1 className="font-serif text-3xl lg:text-4xl text-white font-bold mb-4">{post.title}</h1>
          <div className="flex items-center gap-5 text-sm text-gray-400">
            <span className="flex items-center gap-1.5"><Calendar size={15} /> {new Date(post.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
            <span className="flex items-center gap-1.5"><Clock size={15} /> {post.readTime}</span>
            <button className="flex items-center gap-1.5 hover:text-white transition-colors"><Share2 size={15} /> Share</button>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <img src={post.image} alt={post.title} className="w-full rounded-2xl mb-10 aspect-[16/9] object-cover" />

        <div className="bg-white rounded-2xl border border-gray-100 p-6 lg:p-10">
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 leading-relaxed text-lg">{post.excerpt}</p>
            <p className="text-gray-600 leading-relaxed mt-4">
              This is where the full article content would appear. In a production website, this content would be fetched from a CMS
              or included in the data layer. For this demonstration, the excerpt above captures the article's essence.
            </p>
            <h2 className="font-serif text-xl font-semibold text-gray-900 mt-8 mb-4">Key Takeaways</h2>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent-500 mt-2 shrink-0" /> Understanding current market conditions helps you make informed decisions</li>
              <li className="flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent-500 mt-2 shrink-0" /> Working with an experienced agent gives you a significant advantage</li>
              <li className="flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent-500 mt-2 shrink-0" /> Timing and preparation are everything in real estate</li>
            </ul>
            <p className="text-gray-600 leading-relaxed mt-6">
              For personalized advice on this topic, reach out to one of our expert agents who can guide you through the specifics
              of your situation and local market.
            </p>
          </div>

          <div className="mt-10 pt-8 border-t border-gray-100">
            <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gray-900 text-white font-semibold text-sm hover:bg-gray-800 transition-colors">
              Talk to an Agent About This
            </Link>
          </div>
        </div>

        {/* More Articles */}
        <div className="mt-12">
          <h3 className="font-serif text-xl font-semibold text-gray-900 mb-6">More to Read</h3>
          <div className="grid sm:grid-cols-2 gap-6">
            {blogPosts.filter(p => p.id !== post.id).slice(0, 2).map(p => (
              <Link
                key={p.id}
                to={`/blog/${p.slug}`}
                className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all"
              >
                <div className="aspect-[16/9] overflow-hidden">
                  <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-4">
                  <span className="text-xs font-semibold text-accent-600">{p.category}</span>
                  <h4 className="font-semibold text-gray-900 mt-1 group-hover:text-accent-600 transition-colors line-clamp-2">{p.title}</h4>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
