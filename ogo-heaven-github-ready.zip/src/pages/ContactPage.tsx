import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, Send, MessageSquare, CheckCircle, Loader2, MessageCircle } from 'lucide-react';
import { teamMembers } from '../data/properties';
import { submitInquiry } from '../lib/backend';
import { useSettings } from '../context/SettingsContext';
import { getActiveSocials } from '../lib/settings';
import SocialIcon from '../components/SocialIcon';

function ContactForm() {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', interest: 'Buying a home', message: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await submitInquiry(formData);
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="lg:col-span-2">
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-emerald-600" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-gray-900 mb-2">Message Sent!</h2>
          <p className="text-gray-500 mb-6 max-w-md mx-auto">
            Thank you for reaching out. One of our agents will contact you within 24 hours.
          </p>
          <button
            onClick={() => { setSubmitted(false); setFormData({ firstName: '', lastName: '', email: '', phone: '', interest: 'Buying a home', message: '' }); }}
            className="px-6 py-2.5 rounded-xl bg-gray-900 text-white text-sm font-semibold hover:bg-gray-800"
          >
            Send Another Message
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="lg:col-span-2">
      <div className="bg-white rounded-2xl border border-gray-100 p-6 lg:p-10">
        <h2 className="font-serif text-xl font-semibold text-gray-900 mb-6">Send Us a Message</h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">First Name *</label>
              <input
                type="text" required
                value={formData.firstName}
                onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm"
                placeholder="John"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Last Name *</label>
              <input
                type="text" required
                value={formData.lastName}
                onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm"
                placeholder="Doe"
              />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Email *</label>
              <input
                type="email" required
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm"
                placeholder="john@email.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone *</label>
              <input
                type="tel" required
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm"
                placeholder="+234 800 000 0000"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">I'm interested in</label>
            <select
              value={formData.interest}
              onChange={e => setFormData({ ...formData, interest: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm bg-white"
            >
              <option>Buying a home</option>
              <option>Selling my home</option>
              <option>Both buying and selling</option>
              <option>Property investment</option>
              <option>General inquiry</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Message *</label>
            <textarea
              rows={5} required
              value={formData.message}
              onChange={e => setFormData({ ...formData, message: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-gray-400 text-sm resize-none"
              placeholder="Tell us about what you're looking for..."
            />
          </div>
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">{error}</div>
          )}
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-800 transition-colors disabled:opacity-50"
          >
            {submitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            {submitting ? 'Sending...' : 'Send Message'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function ContactPage() {
  const { settings } = useSettings();
  const activeSocials = getActiveSocials(settings.socials);
  const c = settings.contact;

  const fullAddress = [c.addressLine1, c.addressLine2].filter(Boolean).join(', ');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gray-900 pt-28 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Contact Us</span>
          </div>
          <h1 className="font-serif text-3xl lg:text-4xl text-white font-bold mb-2">Let's Talk</h1>
          <p className="text-gray-400 max-w-lg">We'd love to hear from you. Whether buying, selling, or just curious — reach out to the {settings.company.name} team.</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Contact Form */}
          <ContactForm />

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="font-serif text-lg font-semibold text-gray-900 mb-5">Reach Us Instantly</h3>
              <div className="grid grid-cols-3 gap-3">
                <a
                  href={`tel:${c.phone}`}
                  className="flex flex-col items-center gap-2 rounded-xl bg-gray-900 px-3 py-4 text-white transition-colors hover:bg-gray-800"
                >
                  <Phone size={20} />
                  <span className="text-xs font-semibold">Call</span>
                </a>
                <a
                  href={`https://wa.me/${c.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex flex-col items-center gap-2 rounded-xl bg-emerald-500 px-3 py-4 text-white transition-colors hover:bg-emerald-600"
                >
                  <MessageCircle size={20} />
                  <span className="text-xs font-semibold">WhatsApp</span>
                </a>
                <a
                  href={`mailto:${c.email}`}
                  className="flex flex-col items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-4 text-gray-800 transition-colors hover:bg-gray-50"
                >
                  <Mail size={20} />
                  <span className="text-xs font-semibold">Email</span>
                </a>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="font-serif text-lg font-semibold text-gray-900 mb-5">Get in Touch</h3>
              <div className="space-y-4">
                <a href={`tel:${c.phone}`} className="flex items-center gap-3 group">
                  <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center shrink-0">
                    <Phone size={17} className="text-white" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 block">Call Us</span>
                    <span className="font-semibold text-gray-900 group-hover:text-accent-600 transition-colors">{c.phoneDisplay}</span>
                  </div>
                </a>
                <a href={`mailto:${c.email}`} className="flex items-center gap-3 group">
                  <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center shrink-0">
                    <Mail size={17} className="text-white" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 block">Email</span>
                    <span className="font-semibold text-gray-900 group-hover:text-accent-600 transition-colors">{c.email}</span>
                  </div>
                </a>
                <a href={`https://wa.me/${c.whatsapp}`} target="_blank" rel="noreferrer" className="flex items-center gap-3 group">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shrink-0">
                    <MessageCircle size={17} className="text-white" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 block">WhatsApp</span>
                    <span className="font-semibold text-gray-900 group-hover:text-accent-600 transition-colors">{c.phoneDisplay}</span>
                  </div>
                </a>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center shrink-0">
                    <MapPin size={17} className="text-white" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 block">Head Office</span>
                    <span className="font-semibold text-gray-900 block">{fullAddress}</span>
                    <span className="text-sm text-gray-500 block">{c.city}, {c.state}, {c.country}</span>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center shrink-0">
                    <Clock size={17} className="text-white" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 block">Office Hours</span>
                    <span className="font-semibold text-gray-900">{c.hoursWeekday}</span>
                    <span className="text-sm text-gray-500 block">{c.hoursWeekend}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Links — only rendered when at least one is configured */}
            {activeSocials.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="font-serif text-lg font-semibold text-gray-900 mb-4">Follow Us</h3>
                <div className="grid grid-cols-3 gap-3">
                  {activeSocials.map(({ platform, url }) => (
                    <a
                      key={platform}
                      href={url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex flex-col items-center gap-2 rounded-xl border border-gray-200 bg-gray-50 px-3 py-4 text-gray-700 transition-colors hover:bg-gray-900 hover:text-white hover:border-gray-900"
                    >
                      <SocialIcon platform={platform} size={20} />
                      <span className="text-xs font-semibold capitalize">{platform}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Connect */}
            <div className="bg-gray-900 rounded-2xl p-6 text-white">
              <h3 className="font-serif text-lg font-semibold mb-2 flex items-center gap-2">
                <MessageSquare size={18} className="text-accent-400" />
                Quick Connect
              </h3>
              <p className="text-gray-400 text-sm mb-4">Prefer to speak with someone directly? Choose an agent below.</p>
              <div className="space-y-3">
                {teamMembers.slice(0, 3).map(m => (
                  <a
                    key={m.id}
                    href={`tel:${m.phone}`}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <img src={m.photo} alt={m.name} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                      <span className="font-medium text-sm block">{m.name}</span>
                      <span className="text-xs text-gray-400">{m.role}</span>
                    </div>
                    <Phone size={14} className="ml-auto text-gray-400" />
                  </a>
                ))}
              </div>
            </div>

            {/* Map */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="aspect-[4/3] bg-gray-200">
                <iframe
                  src={`https://www.google.com/maps?q=${encodeURIComponent(`${fullAddress} ${c.city} ${c.state} ${c.country}`)}&output=embed`}
                  className="w-full h-full"
                  style={{ border: 0 }}
                  title="Office location"
                  allowFullScreen
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
