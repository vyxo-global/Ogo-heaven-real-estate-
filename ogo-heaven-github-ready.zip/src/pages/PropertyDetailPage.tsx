import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import {
  Bed, Bath, Square, Calendar, Car, Ruler, MapPin,
  Heart, Share2, ChevronLeft, ChevronRight, Camera, Play,
  X, Calculator, Phone, Mail, Clock, Landmark, UtensilsCrossed, Bus, Footprints,
  School, AlertCircle
} from 'lucide-react';
import { properties } from '../data/properties';
import { cn } from '../utils/cn';
import { formatPrice } from '../utils/currency';

export default function PropertyDetailPage() {
  const { id } = useParams();
  const property = properties.find(p => p.id === id);
  const [activeImg, setActiveImg] = useState(0);
  const [showGallery, setShowGallery] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calcValues, setCalcValues] = useState({ price: property?.price || 0, downPayment: 20, rate: 6.5, years: 30 });
  const [isLiked, setIsLiked] = useState(false);

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle size={48} className="mx-auto text-gray-300 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Property Not Found</h2>
          <p className="text-gray-500 mb-6">The listing you're looking for may have been removed.</p>
          <Link to="/listings" className="px-6 py-3 rounded-full bg-gray-900 text-white font-medium text-sm">Browse Listings</Link>
        </div>
      </div>
    );
  }

  // Using centralized currency formatter

  const monthlyPayment = (() => {
    const loan = calcValues.price * (1 - calcValues.downPayment / 100);
    const r = calcValues.rate / 100 / 12;
    const n = calcValues.years * 12;
    if (r === 0) return loan / n;
    return (loan * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
  })();

  const statusColors = { 'For Sale': 'bg-emerald-500', 'For Rent': 'bg-indigo-500', 'Sold': 'bg-red-500', 'Coming Soon': 'bg-blue-500' };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Gallery Modal */}
      {showGallery && (
        <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
          <button onClick={() => setShowGallery(false)} className="absolute top-4 right-4 text-white/80 hover:text-white z-10"><X size={28} /></button>
          <button
            onClick={() => setActiveImg((activeImg - 1 + property.images.length) % property.images.length)}
            className="absolute left-4 text-white/80 hover:text-white z-10"
          ><ChevronLeft size={36} /></button>
          <img src={property.images[activeImg]} alt="" className="max-h-[90vh] max-w-[90vw] object-contain" />
          <button
            onClick={() => setActiveImg((activeImg + 1) % property.images.length)}
            className="absolute right-4 text-white/80 hover:text-white z-10"
          ><ChevronRight size={36} /></button>
          <div className="absolute bottom-6 text-white/70 text-sm">{activeImg + 1} / {property.images.length}</div>
        </div>
      )}

      {/* Header */}
      <section className="bg-gray-900 pt-28 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link to="/listings" className="hover:text-white transition-colors">Listings</Link>
            <span>/</span>
            <span className="text-white">{property.address}</span>
          </div>
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${statusColors[property.status]}`}>{property.status}</span>
                <span className="text-gray-400 text-sm">{property.type}</span>
              </div>
              <h1 className="font-serif text-2xl lg:text-4xl text-white font-bold">{property.address}</h1>
              <p className="text-gray-400 flex items-center gap-1 mt-1">
                <MapPin size={14} /> {property.city}, {property.state} {property.zip} — {property.neighborhood}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div>
                <span className="text-3xl lg:text-4xl font-bold text-white font-serif">{formatPrice(property.price)}</span>
                {property.status === 'For Rent' && property.rentalPeriod && (
                  <span className="text-lg text-white/70 font-medium ml-1">/{property.rentalPeriod === 'weekly' ? 'week' : property.rentalPeriod === 'monthly' ? 'month' : 'year'}</span>
                )}
                {property.status === 'For Rent' && property.rentalNotes && (
                  <p className="text-sm text-gray-300 mt-1">{property.rentalNotes}</p>
                )}
              </div>
              <button onClick={() => setIsLiked(!isLiked)} className="p-2.5 rounded-xl border border-white/20 text-white/70 hover:text-white hover:border-white/40 transition-colors">
                <Heart size={18} className={isLiked ? 'fill-red-500 text-red-500' : ''} />
              </button>
              <button className="p-2.5 rounded-xl border border-white/20 text-white/70 hover:text-white hover:border-white/40 transition-colors">
                <Share2 size={18} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Image Gallery */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-0">
        <div className="relative rounded-2xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-1">
            <div className="md:col-span-2 md:row-span-2 relative cursor-pointer" onClick={() => { setActiveImg(0); setShowGallery(true); }}>
              <img src={property.images[0]} alt="" className="w-full h-full object-cover md:aspect-auto aspect-[4/3] hover:brightness-90 transition-all" />
            </div>
            {property.images.slice(1, 3).map((img, i) => (
              <div key={i} className="relative cursor-pointer" onClick={() => { setActiveImg(i + 1); setShowGallery(true); }}>
                <img src={img} alt="" className="w-full h-full object-cover aspect-[4/3] hover:brightness-90 transition-all" />
              </div>
            ))}
            <div
              className="relative cursor-pointer bg-gray-800"
              onClick={() => { setActiveImg(2); setShowGallery(true); }}
            >
              {property.images[3] ? (
                <>
                  <img src={property.images[3]} alt="" className="w-full h-full object-cover aspect-[4/3] hover:brightness-90 transition-all" />
                  {property.images.length > 4 && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center hover:bg-black/60 transition-colors">
                      <div className="text-center text-white">
                        <Camera size={28} className="mx-auto mb-2" />
                        <span className="font-semibold">+{property.images.length - 4} more</span>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white/70">
                    <Camera size={28} className="mx-auto mb-2" />
                    <span className="font-semibold">View All Photos</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Left: Details */}
          <div className="lg:col-span-2 space-y-10">
            {/* Key Specs */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="font-serif text-xl font-semibold text-gray-900 mb-5">Key Details</h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-5">
                {[
                  { icon: Bed, value: property.beds, label: 'Bedrooms' },
                  { icon: Bath, value: `${property.baths}${property.halfBaths ? `.5` : ''}`, label: 'Bathrooms' },
                  { icon: Square, value: property.sqft.toLocaleString(), label: 'Square Feet' },
                  { icon: Ruler, value: property.lotSize ? `${property.lotSize} acres` : 'N/A', label: 'Lot Size' },
                  { icon: Calendar, value: property.yearBuilt, label: 'Year Built' },
                  { icon: Car, value: property.garage, label: 'Garage Spaces' },
                  { icon: Landmark, value: property.floors, label: 'Stories' },
                  { icon: Clock, value: property.neighborhood, label: 'Neighborhood' },
                ].map(({ icon: Icon, value, label }) => (
                  <div key={label} className="text-center p-3 rounded-xl bg-gray-50">
                    <Icon size={18} className="text-gray-400 mx-auto mb-1.5" />
                    <div className="font-bold text-gray-900">{value}</div>
                    <div className="text-xs text-gray-500">{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Description */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="font-serif text-xl font-semibold text-gray-900 mb-4">About This Home</h2>
              <p className="text-gray-600 leading-relaxed">{property.description}</p>

              <h3 className="font-semibold text-gray-900 mt-6 mb-3">Highlights</h3>
              <ul className="grid sm:grid-cols-2 gap-2">
                {property.highlights.map(h => (
                  <li key={h} className="flex items-start gap-2 text-sm text-gray-600">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent-500 mt-1.5 shrink-0" />
                    {h}
                  </li>
                ))}
              </ul>
            </div>

            {/* Virtual Tour */}
            {property.virtualTour && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h2 className="font-serif text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Play size={18} className="text-accent-500" />
                  Virtual Tour
                </h2>
                <div className="aspect-video rounded-xl overflow-hidden bg-gray-100">
                  <iframe
                    src={property.virtualTour}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
                    allowFullScreen
                  />
                </div>
              </div>
            )}

            {/* Map & Nearby */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="font-serif text-xl font-semibold text-gray-900 mb-4">Location & Nearby</h2>
              <div className="aspect-[16/9] rounded-xl overflow-hidden bg-gray-200 mb-6">
                <iframe
                  src={`https://www.google.com/maps?q=${encodeURIComponent(property.address + ' ' + property.city + ' ' + property.state)}&output=embed`}
                  className="w-full h-full"
                  title="Property location"
                  style={{ border: 0 }}
                  loading="lazy"
                />
              </div>

              {/* Walk Scores */}
              <div className="flex gap-4 mb-6">
                {[
                  { icon: Footprints, score: property.walkScore, label: 'Walk' },
                  { icon: Bus, score: property.transitScore, label: 'Transit' },
                  { icon: Footprints, score: property.bikeScore, label: 'Bike' },
                ].map(({ icon: Icon, score, label }) => (
                  <div key={label} className="flex-1 bg-gray-50 rounded-xl p-4 text-center">
                    <Icon size={18} className="text-gray-400 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{score}</div>
                    <div className="text-xs text-gray-500">{label} Score</div>
                  </div>
                ))}
              </div>

              {/* Schools */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <School size={16} className="text-accent-500" /> Nearby Schools
                </h3>
                <div className="space-y-2">
                  {property.nearbySchools.map(s => (
                    <div key={s.name} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <div>
                        <span className="text-sm font-medium text-gray-900">{s.name}</span>
                        <span className="text-xs text-gray-400 ml-2 capitalize">({s.type})</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-medium">{s.rating}/10</span>
                        <span className="text-xs text-gray-400">{s.distance}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <UtensilsCrossed size={16} className="text-accent-500" /> Nearby Amenities
                </h3>
                <div className="space-y-2">
                  {property.nearbyAmenities.map(a => (
                    <div key={a.name} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <span className="text-sm text-gray-700">{a.name}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-gray-400 bg-gray-50 px-2 py-0.5 rounded-full">{a.type}</span>
                        <span className="text-xs text-gray-400">{a.distance}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Price History */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="font-serif text-xl font-semibold text-gray-900 mb-4">Price History</h2>
              <div className="space-y-3">
                {property.priceHistory.map((h, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${i === 0 ? 'bg-accent-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">{h.event}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-semibold text-gray-900">{formatPrice(h.price)}</span>
                      <span className="text-xs text-gray-400 block">{new Date(h.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* MLS Info */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="font-serif text-xl font-semibold text-gray-900 mb-4">MLS Information</h2>
              <div className="grid sm:grid-cols-2 gap-4 text-sm">
                <div><span className="text-gray-400 block">MLS Number</span><span className="font-medium text-gray-900">{property.mlsNumber}</span></div>
                <div><span className="text-gray-400 block">Property Type</span><span className="font-medium text-gray-900">{property.type}</span></div>
                <div><span className="text-gray-400 block">Listing Agent</span><span className="font-medium text-gray-900">{property.listingAgent}</span></div>
                <div><span className="text-gray-400 block">Listing Date</span><span className="font-medium text-gray-900">{new Date(property.listingDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span></div>
                {property.propertyTax !== undefined && <div><span className="text-gray-400 block">Annual Property Tax</span><span className="font-medium text-gray-900">{formatPrice(property.propertyTax)}</span></div>}
                {property.hoaFees !== undefined && property.hoaFees > 0 && <div><span className="text-gray-400 block">Monthly HOA Fees</span><span className="font-medium text-gray-900">{formatPrice(property.hoaFees)}</span></div>}
                {property.status === 'For Rent' && property.rentalPeriod && (
                  <div><span className="text-gray-400 block">Rental Period</span><span className="font-medium text-gray-900 capitalize">{property.rentalPeriod}</span></div>
                )}
                {property.status === 'For Rent' && property.rentalNotes && (
                  <div className="sm:col-span-2"><span className="text-gray-400 block">Rental Notes</span><span className="font-medium text-gray-900">{property.rentalNotes}</span></div>
                )}
              </div>
            </div>
          </div>

          {/* Right: Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-24">
              <h3 className="font-serif text-lg font-semibold text-gray-900 mb-4">Interested in this property?</h3>

              {/* Schedule Tour */}
              <button className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-800 transition-colors mb-3 flex items-center justify-center gap-2">
                <Calendar size={16} />
                Schedule a Tour
              </button>

              {/* Contact */}
              <a
                href={`tel:+2348025550123`}
                className="w-full py-3 rounded-xl border border-gray-200 text-gray-900 font-semibold text-sm hover:bg-gray-50 transition-colors mb-3 flex items-center justify-center gap-2"
              >
                <Phone size={16} />
                +234 802 555 0123
              </a>

              {/* Email */}
              <button className="w-full py-3 rounded-xl border border-gray-200 text-gray-900 font-semibold text-sm hover:bg-gray-50 transition-colors mb-6 flex items-center justify-center gap-2">
                <Mail size={16} />
                Email Agent
              </button>

              {/* Quick Contact Form */}
              <div className="space-y-3 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">Or send a quick message:</p>
                <input type="text" placeholder="Your Name" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-400" />
                <input type="email" placeholder="Your Email" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-400" />
                <textarea placeholder="I'm interested in this property..." rows={3} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-400 resize-none" />
                <button className="w-full py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 transition-colors">Send Message</button>
              </div>

              {/* Mortgage Calculator */}
              <div className="pt-4 mt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowCalculator(!showCalculator)}
                  className="flex items-center justify-between w-full text-sm font-medium text-gray-700 hover:text-gray-900"
                >
                  <span className="flex items-center gap-2"><Calculator size={15} /> Mortgage Calculator</span>
                  <ChevronLeft size={15} className={cn('transition-transform', showCalculator && '-rotate-90')} />
                </button>

                <div className={cn('overflow-hidden transition-all duration-300', showCalculator ? 'max-h-80 mt-4' : 'max-h-0')}>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">Home Price</label>
                      <input
                        type="number"
                        value={calcValues.price}
                        onChange={e => setCalcValues({ ...calcValues, price: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">Down Payment ({calcValues.downPayment}%)</label>
                      <input
                        type="range" min={5} max={50} value={calcValues.downPayment}
                        onChange={e => setCalcValues({ ...calcValues, downPayment: Number(e.target.value) })}
                        className="w-full"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Interest Rate</label>
                        <input
                          type="number" step={0.1} value={calcValues.rate}
                          onChange={e => setCalcValues({ ...calcValues, rate: Number(e.target.value) })}
                          className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Loan Term (yrs)</label>
                        <select
                          value={calcValues.years}
                          onChange={e => setCalcValues({ ...calcValues, years: Number(e.target.value) })}
                          className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none"
                        >
                          <option value={15}>15</option>
                          <option value={30}>30</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-accent-50 rounded-xl p-4 text-center">
                      <span className="text-xs text-accent-700 block">Estimated Monthly Payment</span>
                      <span className="text-2xl font-bold text-accent-800 font-serif">{formatPrice(monthlyPayment)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
