import { Link } from 'react-router-dom';
import { ArrowRight, Star, Award, TrendingUp, Home, Building2, ShieldCheck, Search, MapPin, Bed, Bath, Square } from 'lucide-react';
import { properties, testimonials } from '../data/properties';
import { formatPrice } from '../utils/currency';

export default function HomePage() {
  const featuredProperties = properties.filter(p => p.status === 'For Sale').slice(0, 3);

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1920"
            alt="Luxury Nigerian home"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/75" />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
          <div className="max-w-3xl">
            <span className="inline-block px-4 py-1.5 rounded-full border border-white/30 text-white/90 text-sm font-medium mb-6 backdrop-blur-sm">
              Trusted Nigerian Real Estate — Since 2010
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-7xl text-white font-bold leading-tight mb-6">
              Find Your <br />
              <span className="text-accent-300 italic">Heaven on Earth.</span>
            </h1>
            <p className="text-lg sm:text-xl text-white/70 max-w-xl mb-10 leading-relaxed">
              Premium properties across Lagos, Abuja, and beyond. We connect discerning buyers with exceptional homes that match their lifestyle and aspirations.
            </p>

            {/* Search Bar */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/20 shadow-2xl max-w-2xl">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/60" />
                  <input
                    type="text"
                    placeholder="Search by city, neighborhood, or address..."
                    className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/50 outline-none focus:border-white/40 text-sm"
                  />
                </div>
                <Link
                  to="/listings"
                  className="px-8 py-3.5 rounded-xl bg-accent-500 hover:bg-accent-600 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2"
                >
                  Search Listings
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            <div className="mt-5 flex flex-col sm:flex-row gap-3 max-w-2xl">
              <Link
                to="/listings"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-semibold text-gray-900 transition-colors hover:bg-gray-100"
              >
                View Properties
                <ArrowRight size={16} />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/15"
              >
                Speak With an Agent
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="flex flex-wrap gap-6 mt-10">
              {[
                { label: 'Properties Listed', value: '500+' },
                { label: 'Happy Clients', value: '350+' },
                { label: 'Cities Covered', value: '15+' },
              ].map(({ label, value }) => (
                <div key={label} className="text-white/90">
                  <span className="text-2xl font-bold font-serif">{value}</span>
                  <span className="text-sm ml-2 text-white/60">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50">
          <span className="text-xs uppercase tracking-[0.2em]">Scroll</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-white/50 to-transparent" />
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-gray-900 -mt-1 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { value: '15+', label: 'Years in Business', icon: TrendingUp },
              { value: '₦50B+', label: 'Properties Sold', icon: Award },
              { value: '98%', label: 'Client Satisfaction', icon: Star },
              { value: '350+', label: 'Happy Families', icon: ShieldCheck },
            ].map(({ value, label, icon: Icon }) => (
              <div key={label} className="text-center">
                <Icon size={20} className="text-accent-400 mx-auto mb-2" />
                <div className="text-2xl lg:text-3xl font-bold text-white font-serif">{value}</div>
                <div className="text-sm text-gray-400 mt-1">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-end justify-between mb-12">
            <div>
              <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">Featured Properties</span>
              <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold mt-2">Handpicked for you</h2>
              <p className="text-gray-500 mt-3 max-w-lg">Premium properties across Nigeria's most sought-after locations.</p>
            </div>
            <Link
              to="/listings"
              className="inline-flex items-center gap-2 text-gray-900 font-medium text-sm mt-4 sm:mt-0 hover:text-accent-600 transition-colors group"
            >
              View All Listings
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {featuredProperties.map((property) => (
              <Link
                key={property.id}
                to={`/property/${property.id}`}
                className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-2xl hover:shadow-gray-200/60 hover:-translate-y-1 transition-all duration-500"
              >
                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={property.images[0]}
                    alt={property.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />

                  {/* Status badge */}
                  <span className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold text-white ${property.status === 'For Sale' ? 'bg-emerald-500' : 'bg-amber-500'}`}>
                    {property.status}
                  </span>

                  {/* Price */}
                  <div className="absolute bottom-3 left-3 right-3">
                    <span className="text-xl font-bold text-white drop-shadow-lg">{formatPrice(property.price)}</span>
                    {property.status === 'For Rent' && property.rentalPeriod && (
                      <span className="text-sm text-white/80 font-medium ml-1">/{property.rentalPeriod === 'weekly' ? 'wk' : property.rentalPeriod === 'monthly' ? 'mo' : 'yr'}</span>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 sm:p-5">
                  <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1 group-hover:text-accent-600 transition-colors">
                    {property.address}
                  </h3>
                  <div className="flex items-center gap-1 text-gray-500 text-sm mb-3">
                    <MapPin size={13} />
                    <span>{property.city}, {property.state}</span>
                  </div>

                  <div className="flex items-center gap-4 pt-3 border-t border-gray-100">
                    <div className="flex items-center gap-1.5 text-sm">
                      <Bed size={15} className="text-gray-400" />
                      <span className="font-medium text-gray-700">{property.beds}</span>
                      <span className="text-gray-400">Beds</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-sm">
                      <Bath size={15} className="text-gray-400" />
                      <span className="font-medium text-gray-700">{property.baths}</span>
                      <span className="text-gray-400">Baths</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-sm">
                      <Square size={15} className="text-gray-400" />
                      <span className="font-medium text-gray-700">{property.sqft.toLocaleString()}</span>
                      <span className="text-gray-400">Sq Ft</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">What We Do</span>
            <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold mt-2">Your journey starts here</h2>
            <p className="text-gray-500 mt-3 max-w-md mx-auto">
              Whether you're buying your first home or selling a luxury property, we're here to guide you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            <Link
              to="/listings"
              className="group p-8 rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-xl hover:shadow-gray-100 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center mb-5 group-hover:bg-accent-500 transition-colors">
                <Home size={22} className="text-white" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-900 mb-3">Buy a Home</h3>
              <p className="text-gray-500 leading-relaxed mb-4 text-sm">
                From first-time buyers to seasoned investors, our agents guide you through every step with market intelligence and personalized service across Nigeria's premium locations.
              </p>
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-gray-900 group-hover:text-accent-600 transition-colors">
                Browse Listings
                <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>

            <Link
              to="/about"
              className="group p-8 rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-xl hover:shadow-gray-100 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center mb-5 group-hover:bg-accent-500 transition-colors">
                <Building2 size={22} className="text-white" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-gray-900 mb-3">Meet Our Team</h3>
              <p className="text-gray-500 leading-relaxed mb-4 text-sm">
                Get to know the experienced agents behind Ogo Heavens. Our team brings decades of combined experience in Nigerian real estate and a commitment to exceptional service.
              </p>
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-gray-900 group-hover:text-accent-600 transition-colors">
                About Us
                <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">Testimonials</span>
            <h2 className="font-serif text-3xl lg:text-4xl text-gray-900 font-bold mt-2">What our clients say</h2>
            <p className="text-gray-500 mt-3 max-w-md mx-auto">
              93% of our business comes from referrals. Here's why.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.id} className="bg-white rounded-2xl p-6 lg:p-8">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={16} className="fill-accent-400 text-accent-400" />
                  ))}
                </div>
                <blockquote className="text-gray-600 leading-relaxed mb-6 text-sm">"{t.quote}"</blockquote>
                <div className="flex items-center gap-3">
                  <img src={t.avatar} alt={t.name} className="w-11 h-11 rounded-full object-cover" />
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                    <div className="text-gray-500 text-xs">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-accent-500 blur-[128px]" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-blue-500 blur-[128px]" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl lg:text-5xl text-white font-bold mb-4">Ready to find your heaven?</h2>
          <p className="text-gray-300 text-lg max-w-lg mx-auto mb-8">
            Let our expert team guide you home. Schedule a consultation today.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/contact"
              className="px-8 py-3.5 rounded-full bg-accent-500 text-white font-semibold hover:bg-accent-600 transition-colors shadow-lg shadow-accent-500/25"
            >
              Contact an Agent
            </Link>
            <Link
              to="/listings"
              className="px-8 py-3.5 rounded-full border border-white/30 text-white font-semibold hover:bg-white/10 transition-colors"
            >
              Start Your Search
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
