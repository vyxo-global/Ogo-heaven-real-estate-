import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, Send, Loader2, CheckCircle, MessageSquare } from 'lucide-react';
import { submitReview, subscribeApprovedReviews, Review, ReviewSummary } from '../lib/reviews';
import { useSettings } from '../context/SettingsContext';

function Stars({ value, interactive = false, onChange }: { value: number; interactive?: boolean; onChange?: (value: number) => void }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map(star => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          onClick={() => onChange?.(star)}
          className={interactive ? 'transition-transform hover:scale-110' : ''}
        >
          <Star
            size={interactive ? 26 : 18}
            className={star <= value ? 'fill-accent-400 text-accent-400' : 'text-gray-300'}
          />
        </button>
      ))}
    </div>
  );
}

export default function ReviewsPage() {
  const { settings } = useSettings();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [summary, setSummary] = useState<ReviewSummary>({ totalApproved: 0, averageRating: 0 });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    rating: 5,
    message: '',
  });

  useEffect(() => {
    let unsub: (() => void) | undefined;
    subscribeApprovedReviews((nextReviews, nextSummary) => {
      setReviews(nextReviews);
      setSummary(nextSummary);
      setLoading(false);
    }).then(fn => { unsub = fn; });
    return () => unsub?.();
  }, []);

  const ratingPercent = useMemo(() => (summary.averageRating / 5) * 100, [summary.averageRating]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await submitReview(formData);
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', rating: 5, message: '' });
    } catch (err: any) {
      setError(err.message || 'Unable to submit review. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-gray-900 pt-28 pb-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Reviews</span>
          </div>
          <div className="grid lg:grid-cols-2 gap-10 items-end">
            <div>
              <h1 className="font-serif text-3xl lg:text-5xl text-white font-bold mb-4">Client Reviews</h1>
              <p className="text-gray-400 max-w-xl text-lg">
                Real feedback from clients of {settings.company.name}. Share your experience and, once approved, it will appear here automatically.
              </p>
            </div>
            <div className="bg-white/10 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
              <div className="flex items-center justify-between gap-6">
                <div>
                  <p className="text-sm text-gray-300">Overall Rating</p>
                  <div className="font-serif text-5xl font-bold text-white mt-1">
                    {summary.averageRating ? summary.averageRating.toFixed(1) : '0.0'}
                    <span className="text-xl text-gray-400">/5</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">Based on {summary.totalApproved} approved review{summary.totalApproved === 1 ? '' : 's'}</p>
                </div>
                <div className="min-w-32">
                  <Stars value={Math.round(summary.averageRating)} />
                  <div className="mt-3 h-2 rounded-full bg-white/10 overflow-hidden">
                    <div className="h-full bg-accent-400" style={{ width: `${ratingPercent}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-24">
              {submitted ? (
                <div className="text-center py-8">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle size={28} className="text-emerald-600" />
                  </div>
                  <h2 className="font-serif text-xl font-bold text-gray-900 mb-2">Review submitted</h2>
                  <p className="text-sm text-gray-500 mb-5">Thank you. Your review is pending admin approval.</p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-5 py-2.5 rounded-xl bg-gray-900 text-white text-sm font-semibold hover:bg-gray-800"
                  >
                    Submit Another Review
                  </button>
                </div>
              ) : (
                <>
                  <h2 className="font-serif text-xl font-bold text-gray-900 mb-2">Drop a Review</h2>
                  <p className="text-sm text-gray-500 mb-6">Reviews appear publicly only after admin approval.</p>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">Your Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">Email *</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                        placeholder="you@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone (optional)</label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                        placeholder="+234 800 000 0000"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Rating *</label>
                      <Stars
                        value={formData.rating}
                        interactive
                        onChange={rating => setFormData({ ...formData, rating })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">Review *</label>
                      <textarea
                        rows={5}
                        required
                        value={formData.message}
                        onChange={e => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 resize-none"
                        placeholder="Tell us about your experience..."
                      />
                    </div>
                    {error && <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">{error}</div>}
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 transition-colors disabled:opacity-50"
                    >
                      {submitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                      {submitting ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="flex items-end justify-between gap-4 mb-6">
              <div>
                <span className="text-accent-600 font-semibold text-sm tracking-wide uppercase">Approved Reviews</span>
                <h2 className="font-serif text-3xl font-bold text-gray-900 mt-1">What clients are saying</h2>
              </div>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 size={30} className="animate-spin text-accent-500" />
              </div>
            ) : reviews.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
                <MessageSquare size={44} className="mx-auto text-gray-300 mb-4" />
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">No approved reviews yet</h3>
                <p className="text-gray-500 text-sm">Be the first to submit a review. Once approved, it will appear here.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-5">
                {reviews.map(review => (
                  <article key={review.id} className="bg-white rounded-2xl border border-gray-100 p-6">
                    <Stars value={review.rating} />
                    <blockquote className="text-gray-600 leading-relaxed my-5 text-sm">"{review.message}"</blockquote>
                    <div>
                      <div className="font-semibold text-gray-900 text-sm">{review.name}</div>
                      <div className="text-xs text-gray-400 mt-1">
                        {new Date(review.approvedAt || review.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
