import { useState, useMemo } from 'react';
import { SlidersHorizontal, Map as MapIcon, Grid3X3, X } from 'lucide-react';
import SearchWidget from '../components/SearchWidget';
import PropertyCard from '../components/PropertyCard';
import PropertyLeadActions from '../components/PropertyLeadActions';
import { properties } from '../data/properties';
import { cn } from '../utils/cn';
import { formatPrice } from '../utils/currency';

export default function ListingsPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    type: '',
    minPrice: '',
    maxPrice: '',
    beds: '',
    baths: '',
    city: '',
  });

  const [sortBy, setSortBy] = useState('newest');

  const filtered = useMemo(() => {
    let result = [...properties];

    if (filters.status) result = result.filter(p => p.status === filters.status);
    if (filters.type) result = result.filter(p => p.type === filters.type);
    if (filters.minPrice) result = result.filter(p => p.price >= parseInt(filters.minPrice));
    if (filters.maxPrice) result = result.filter(p => p.price <= parseInt(filters.maxPrice));
    if (filters.beds) result = result.filter(p => p.beds >= parseInt(filters.beds));
    if (filters.baths) result = result.filter(p => p.baths >= parseInt(filters.baths));
    if (filters.city) result = result.filter(p => p.city.toLowerCase().includes(filters.city.toLowerCase()));

    switch (sortBy) {
      case 'price-asc': result.sort((a, b) => a.price - b.price); break;
      case 'price-desc': result.sort((a, b) => b.price - a.price); break;
      case 'sqft': result.sort((a, b) => b.sqft - a.sqft); break;
      case 'newest':
      default:
        result.sort((a, b) => new Date(b.listingDate).getTime() - new Date(a.listingDate).getTime());
    }

    return result;
  }, [filters, sortBy]);

  const clearFilters = () => setFilters({ status: '', type: '', minPrice: '', maxPrice: '', beds: '', baths: '', city: '' });

  const hasActiveFilters = Object.values(filters).some(v => v !== '');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gray-900 pt-28 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <a href="/" className="hover:text-white transition-colors">Home</a>
            <span>/</span>
            <span className="text-white">Listings</span>
          </div>
          <h1 className="font-serif text-3xl lg:text-4xl text-white font-bold mb-2">Find Your Home</h1>
          <p className="text-gray-400 max-w-lg">Browse our curated collection of exceptional properties.</p>
        </div>
      </section>

      {/* Search & Controls */}
      <section className="bg-white border-b border-gray-200 sticky top-16 lg:top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1 w-full sm:max-w-xl">
              <SearchWidget variant="inline" />
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors',
                  showFilters ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700 border-gray-200 hover:border-gray-300'
                )}
              >
                <SlidersHorizontal size={15} />
                Filters
                {hasActiveFilters && <span className="w-2 h-2 rounded-full bg-accent-500" />}
              </button>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-700 bg-white cursor-pointer outline-none"
              >
                <option value="newest">Newest</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="sqft">Largest</option>
              </select>

              <div className="hidden sm:flex items-center border border-gray-200 rounded-xl overflow-hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  className={cn('p-2.5 transition-colors', viewMode === 'grid' ? 'bg-gray-900 text-white' : 'text-gray-500 hover:text-gray-700')}
                >
                  <Grid3X3 size={16} />
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  className={cn('p-2.5 transition-colors', viewMode === 'map' ? 'bg-gray-900 text-white' : 'text-gray-500 hover:text-gray-700')}
                >
                  <MapIcon size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Filter Panel */}
        <div className={cn('overflow-hidden transition-all duration-300', showFilters ? 'max-h-96' : 'max-h-0')}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 border-t border-gray-100">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
              <select value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none">
                <option value="">All Status</option>
                <option value="For Sale">For Sale</option>
                <option value="For Rent">For Rent</option>
                <option value="Sold">Sold</option>
                <option value="Coming Soon">Coming Soon</option>
              </select>
              <select value={filters.type} onChange={e => setFilters({ ...filters, type: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none">
                <option value="">All Types</option>
                <option value="Detached House">Detached House</option>
                <option value="Duplex">Duplex</option>
                <option value="Apartment">Apartment</option>
                <option value="Townhouse">Townhouse</option>
                <option value="Land">Land</option>
              </select>
              <input type="number" placeholder="Min Price" value={filters.minPrice} onChange={e => setFilters({ ...filters, minPrice: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none" />
              <input type="number" placeholder="Max Price" value={filters.maxPrice} onChange={e => setFilters({ ...filters, maxPrice: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none" />
              <input type="number" placeholder="Beds" value={filters.beds} onChange={e => setFilters({ ...filters, beds: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none" />
              <input type="number" placeholder="Baths" value={filters.baths} onChange={e => setFilters({ ...filters, baths: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none" />
              <input type="text" placeholder="City" value={filters.city} onChange={e => setFilters({ ...filters, city: e.target.value })} className="px-3 py-2.5 rounded-xl border border-gray-200 text-sm outline-none" />
            </div>
            {hasActiveFilters && (
              <button onClick={clearFilters} className="flex items-center gap-1 text-accent-600 text-sm font-medium mt-3 hover:text-accent-700">
                <X size={14} /> Clear all filters
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <p className="text-sm text-gray-500 mb-6">
          <span className="font-semibold text-gray-900">{filtered.length}</span> properties found
        </p>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🏠</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No properties match your filters</h3>
            <p className="text-gray-500 mb-6">Try adjusting your search criteria</p>
            <button onClick={clearFilters} className="px-6 py-3 rounded-full bg-gray-900 text-white font-medium text-sm hover:bg-gray-800">Clear Filters</button>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filtered.map(p => (
              <PropertyCard key={p.id} property={p} showLeadActions />
            ))}
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4 max-h-[70vh] overflow-y-auto pr-2">
              {filtered.map(p => (
                <div key={p.id} className="p-4 rounded-xl bg-white border border-gray-100 hover:border-gray-200 transition-colors">
                  <div className="font-semibold text-gray-900">{p.address}</div>
                  <div className="text-accent-600 font-bold mt-1">
                    {formatPrice(p.price)}
                    {p.status === 'For Rent' && p.rentalPeriod && (
                      <span className="text-sm font-medium text-gray-500 ml-1">/{p.rentalPeriod === 'weekly' ? 'wk' : p.rentalPeriod === 'monthly' ? 'mo' : 'yr'}</span>
                    )}
                  </div>
                  <div className="text-sm text-gray-500 flex gap-3 mt-1">{p.beds} bd | {p.baths} ba | {p.sqft.toLocaleString()} sqft</div>
                  <PropertyLeadActions property={p} compact />
                </div>
              ))}
            </div>
            <div className="lg:col-span-2 rounded-2xl overflow-hidden border border-gray-200 h-[70vh] bg-gray-200 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <MapIcon size={48} className="mx-auto mb-3" />
                <p className="font-medium">Map View</p>
                <p className="text-sm">Interactive map with polygon search available</p>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
