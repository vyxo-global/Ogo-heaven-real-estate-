import { useState, useRef, ChangeEvent } from 'react';
import { Save, Loader2, CheckCircle, Upload, X, Globe, Building2, Phone, Share2, Key, Search, Home, Shield, Sparkles, Plus, Trash2, Image as ImageIcon, AlertCircle, ArrowLeft } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useSettings } from '../../context/SettingsContext';
import { SiteSettings, StatItem, ServiceItem, TestimonialItem, uid } from '../../lib/settings';
import { uploadFile } from '../../lib/backend';
import { isFirebaseConfigured } from '../../lib/firebase';
import SocialIcon from '../../components/SocialIcon';
import { cn } from '../../utils/cn';

type Tab = 'company' | 'contact' | 'socials' | 'homepage' | 'security' | 'api' | 'seo' | 'demo';

export default function AdminSettings() {
  const { settings, save, saving, error } = useSettings();
  const [draft, setDraft] = useState<SiteSettings>(settings);
  const [activeTab, setActiveTab] = useState<Tab>('company');
  const [successMessage, setSuccessMessage] = useState('');
  const [logoUploading, setLogoUploading] = useState(false);
  const [heroImageUploading, setHeroImageUploading] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const heroInputRef = useRef<HTMLInputElement>(null);

  const hasChanges = JSON.stringify(draft) !== JSON.stringify(settings);

  const update = <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) => {
    setDraft(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSuccessMessage('');
    try {
      await save(draft);
      setSuccessMessage('Settings saved. Changes are live across the site.');
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch { /* error handled by context */ }
  };

  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>, target: 'logo' | 'heroImage') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const readFileAsDataUrl = () => new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    if (!isFirebaseConfigured) {
      const dataUrl = await readFileAsDataUrl();
      if (target === 'logo') update('company', { ...draft.company, logoUrl: dataUrl });
      else update('homepage', { ...draft.homepage, heroImage: dataUrl });
      return;
    }

    if (target === 'logo') setLogoUploading(true); else setHeroImageUploading(true);
    try {
      const url = await uploadFile(file, 'settings');
      if (target === 'logo') update('company', { ...draft.company, logoUrl: url });
      else update('homepage', { ...draft.homepage, heroImage: url });
    } catch {
      alert('Failed to upload image');
    } finally {
      if (target === 'logo') setLogoUploading(false); else setHeroImageUploading(false);
      (target === 'logo' ? logoInputRef : heroInputRef).current &&
        ((target === 'logo' ? logoInputRef : heroInputRef).current!.value = '');
    }
  };

  // --- Homepage editors ---
  const addStat = () => update('homepage', { ...draft.homepage, stats: [...draft.homepage.stats, { id: uid(), value: '', label: '' }] });
  const updateStat = (id: string, patch: Partial<StatItem>) =>
    update('homepage', { ...draft.homepage, stats: draft.homepage.stats.map(s => s.id === id ? { ...s, ...patch } : s) });
  const removeStat = (id: string) =>
    update('homepage', { ...draft.homepage, stats: draft.homepage.stats.filter(s => s.id !== id) });

  const addService = () => update('homepage', {
    ...draft.homepage,
    services: [...draft.homepage.services, { id: uid(), title: '', description: '', linkLabel: 'Learn more', linkHref: '/', icon: 'home' }],
  });
  const updateService = (id: string, patch: Partial<ServiceItem>) =>
    update('homepage', { ...draft.homepage, services: draft.homepage.services.map(s => s.id === id ? { ...s, ...patch } : s) });
  const removeService = (id: string) =>
    update('homepage', { ...draft.homepage, services: draft.homepage.services.filter(s => s.id !== id) });

  const addTestimonial = () => update('homepage', {
    ...draft.homepage,
    testimonials: [...draft.homepage.testimonials, { id: uid(), name: '', role: '', quote: '', avatar: '' }],
  });
  const updateTestimonial = (id: string, patch: Partial<TestimonialItem>) =>
    update('homepage', { ...draft.homepage, testimonials: draft.homepage.testimonials.map(t => t.id === id ? { ...t, ...patch } : t) });
  const removeTestimonial = (id: string) =>
    update('homepage', { ...draft.homepage, testimonials: draft.homepage.testimonials.filter(t => t.id !== id) });

  const tabs: Array<{ id: Tab; label: string; icon: typeof Building2; description: string }> = [
    { id: 'company', label: 'Company', icon: Building2, description: 'Logo, name, branding' },
    { id: 'contact', label: 'Contact', icon: Phone, description: 'Phone, email, address' },
    { id: 'socials', label: 'Social Links', icon: Share2, description: 'Only configured ones appear publicly' },
    { id: 'homepage', label: 'Homepage', icon: Home, description: 'Hero, stats, testimonials, CTA' },
    { id: 'security', label: 'Security', icon: Shield, description: 'Admin username & password' },
    { id: 'api', label: 'API Keys', icon: Key, description: 'Web3Forms and integrations' },
    { id: 'seo', label: 'SEO', icon: Search, description: 'Meta tags and keywords' },
    { id: 'demo', label: 'Demo Data', icon: Sparkles, description: 'Control example content' },
  ];

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <button
            onClick={() => window.history.back()}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900 font-medium text-sm transition-all active:scale-95 mb-2"
          >
            <ArrowLeft size={18} /> Back
          </button>
          <h1 className="font-serif text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-500 mt-1">Configure site-wide details. Changes appear instantly across the public site.</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving || !hasChanges}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-accent-600 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
          {saving ? 'Saving...' : hasChanges ? 'Save Changes' : 'Saved'}
        </button>
      </div>

      {!isFirebaseConfigured && (
        <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          <strong>Note:</strong> Firebase isn't configured, so these settings are saved in your browser only. Configure Firebase to sync settings across all devices.
        </div>
      )}

      {successMessage && (
        <div className="mb-6 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
          <CheckCircle size={16} className="shrink-0" />
          {successMessage}
        </div>
      )}

      {error && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Tabs */}
        <aside className="lg:col-span-1">
          <nav className="sticky top-6 space-y-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'flex w-full items-center gap-3 rounded-xl p-3 text-left transition-colors',
                  activeTab === tab.id
                    ? 'bg-white border border-gray-200 shadow-sm'
                    : 'hover:bg-white/70 border border-transparent'
                )}
              >
                <div className={cn(
                  'w-9 h-9 rounded-lg flex items-center justify-center shrink-0',
                  activeTab === tab.id ? 'bg-accent-500 text-white' : 'bg-gray-100 text-gray-500'
                )}>
                  <tab.icon size={16} />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-gray-900">{tab.label}</div>
                  <div className="text-xs text-gray-500 truncate">{tab.description}</div>
                </div>
              </button>
            ))}
          </nav>
        </aside>

        {/* Content */}
        <div className="lg:col-span-3 space-y-6">
          {activeTab === 'company' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Company & Branding</h2>
              <p className="text-sm text-gray-500 mb-6">Appears in navbar, footer, and across the site.</p>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Logo</label>
                  <div className="flex items-start gap-5">
                    <div className="w-20 h-20 rounded-xl bg-gray-900 flex items-center justify-center overflow-hidden shrink-0">
                      {draft.company.logoUrl ? (
                        <img src={draft.company.logoUrl} alt="logo" className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-serif text-white text-3xl font-bold italic">{draft.company.logoText || 'O'}</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <label className="block w-full">
                        <div className="w-full rounded-xl border-2 border-dashed border-gray-200 bg-gray-50 px-4 py-3 text-center text-sm text-gray-600 hover:border-accent-400 hover:bg-white cursor-pointer flex items-center justify-center gap-2">
                          {logoUploading ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                          {logoUploading ? 'Uploading...' : 'Upload Logo Image'}
                        </div>
                        <input ref={logoInputRef} type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'logo')} className="hidden" />
                      </label>
                      {draft.company.logoUrl && (
                        <button
                          onClick={() => update('company', { ...draft.company, logoUrl: '' })}
                          className="mt-2 text-xs text-red-600 hover:text-red-700 flex items-center gap-1"
                        >
                          <X size={12} /> Remove logo
                        </button>
                      )}
                      <div className="mt-2">
                        <label className="text-xs text-gray-500 block mb-1">Logo fallback monogram (if no image)</label>
                        <input
                          type="text" maxLength={2}
                          value={draft.company.logoText}
                          onChange={e => update('company', { ...draft.company, logoText: e.target.value })}
                          className="w-20 rounded-lg border border-gray-200 px-3 py-1.5 text-sm outline-none focus:border-accent-400"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Company Name</label>
                  <input type="text" value={draft.company.name} onChange={e => update('company', { ...draft.company, name: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Tagline / Subtitle</label>
                  <input type="text" value={draft.company.tagline} onChange={e => update('company', { ...draft.company, tagline: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Registration Number</label>
                  <input type="text" value={draft.company.rcNumber} onChange={e => update('company', { ...draft.company, rcNumber: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" placeholder="RC 1234567" />
                </div>
                <div className="md:col-span-2">
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">About (used in footer)</label>
                  <textarea rows={3} value={draft.company.about} onChange={e => update('company', { ...draft.company, about: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400 resize-none" />
                </div>
              </div>
            </section>
          )}

          {activeTab === 'contact' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Contact Information</h2>
              <p className="text-sm text-gray-500 mb-6">Powers Contact page buttons, footer, and property WhatsApp/email actions.</p>

              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Phone (E.164 format)</label>
                  <input type="tel" value={draft.contact.phone} onChange={e => update('contact', { ...draft.contact, phone: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" placeholder="+2348035243518" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Phone (display format)</label>
                  <input type="text" value={draft.contact.phoneDisplay} onChange={e => update('contact', { ...draft.contact, phoneDisplay: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" placeholder="+234 803 524 3518" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">WhatsApp Number (digits only)</label>
                  <input type="tel" value={draft.contact.whatsapp} onChange={e => update('contact', { ...draft.contact, whatsapp: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" placeholder="2348035243518" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Email</label>
                  <input type="email" value={draft.contact.email} onChange={e => update('contact', { ...draft.contact, email: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div className="md:col-span-2">
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Address Line 1</label>
                  <input type="text" value={draft.contact.addressLine1} onChange={e => update('contact', { ...draft.contact, addressLine1: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div className="md:col-span-2">
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Address Line 2 (optional)</label>
                  <input type="text" value={draft.contact.addressLine2} onChange={e => update('contact', { ...draft.contact, addressLine2: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">City</label>
                  <input type="text" value={draft.contact.city} onChange={e => update('contact', { ...draft.contact, city: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">State</label>
                  <input type="text" value={draft.contact.state} onChange={e => update('contact', { ...draft.contact, state: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Country</label>
                  <input type="text" value={draft.contact.country} onChange={e => update('contact', { ...draft.contact, country: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Weekday Hours</label>
                  <input type="text" value={draft.contact.hoursWeekday} onChange={e => update('contact', { ...draft.contact, hoursWeekday: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
                <div className="md:col-span-2">
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Weekend Hours</label>
                  <input type="text" value={draft.contact.hoursWeekend} onChange={e => update('contact', { ...draft.contact, hoursWeekend: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
              </div>
            </section>
          )}

          {activeTab === 'socials' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Social Media Links</h2>
              <p className="text-sm text-gray-500 mb-6">Leave a field blank to hide it from the public site.</p>

              <div className="space-y-4">
                {(['facebook', 'instagram', 'twitter', 'linkedin', 'youtube', 'tiktok'] as const).map(platform => (
                  <div key={platform} className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gray-100 flex items-center justify-center text-gray-600 shrink-0">
                      <SocialIcon platform={platform} size={18} />
                    </div>
                    <div className="flex-1">
                      <label className="mb-1 block text-xs font-medium text-gray-500 uppercase tracking-wider">{platform}</label>
                      <input
                        type="url"
                        placeholder={`https://${platform}.com/your-page`}
                        value={draft.socials[platform]}
                        onChange={e => update('socials', { ...draft.socials, [platform]: e.target.value })}
                        className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400"
                      />
                    </div>
                    {draft.socials[platform] && (
                      <div className="flex items-center gap-2">
                        <a href={draft.socials[platform]} target="_blank" rel="noreferrer" className="text-xs text-accent-600 hover:text-accent-700 font-medium whitespace-nowrap">Test ↗</a>
                        <button
                          onClick={() => update('socials', { ...draft.socials, [platform]: '' })}
                          className="p-2 rounded-lg text-red-500 hover:bg-red-50"
                          title={`Delete ${platform} link`}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {(['facebook', 'instagram', 'twitter', 'linkedin', 'youtube', 'tiktok'] as const).some(platform => draft.socials[platform]) && (
                <button
                  onClick={() => update('socials', { facebook: '', instagram: '', twitter: '', linkedin: '', youtube: '', tiktok: '' })}
                  className="mt-4 inline-flex items-center gap-1.5 rounded-xl border border-red-200 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50"
                >
                  <Trash2 size={14} /> Delete All Social Links
                </button>
              )}

              <div className="mt-8 rounded-2xl bg-gray-50 p-5">
                <p className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
                  <Globe size={14} /> Preview (live on contact page & footer)
                </p>
                <div className="flex flex-wrap gap-3">
                  {(['facebook', 'instagram', 'twitter', 'linkedin', 'youtube', 'tiktok'] as const)
                    .filter(p => draft.socials[p])
                    .map(platform => (
                      <div key={platform} className="flex items-center gap-2 rounded-xl bg-white border border-gray-200 px-3 py-2">
                        <SocialIcon platform={platform} size={16} />
                        <span className="text-sm font-medium text-gray-700 capitalize">{platform}</span>
                      </div>
                    ))}
                  {(['facebook', 'instagram', 'twitter', 'linkedin', 'youtube', 'tiktok'] as const).every(p => !draft.socials[p]) && (
                    <p className="text-sm text-gray-400 italic">No social links configured yet.</p>
                  )}
                </div>
              </div>
            </section>
          )}

          {activeTab === 'homepage' && (
            <>
              {/* Hero */}
              <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
                <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Hero Section</h2>
                <p className="text-sm text-gray-500 mb-6">The main banner on the homepage.</p>
                <div className="space-y-5">
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Badge / Eyebrow text</label>
                    <input type="text" value={draft.homepage.heroBadge} onChange={e => update('homepage', { ...draft.homepage, heroBadge: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Title (first line)</label>
                      <input type="text" value={draft.homepage.heroTitle} onChange={e => update('homepage', { ...draft.homepage, heroTitle: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Title (accent, second line)</label>
                      <input type="text" value={draft.homepage.heroTitleAccent} onChange={e => update('homepage', { ...draft.homepage, heroTitleAccent: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Subtitle</label>
                    <textarea rows={2} value={draft.homepage.heroSubtitle} onChange={e => update('homepage', { ...draft.homepage, heroSubtitle: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400 resize-none" />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Primary CTA Label</label>
                      <input type="text" value={draft.homepage.primaryCtaLabel} onChange={e => update('homepage', { ...draft.homepage, primaryCtaLabel: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Primary CTA Link</label>
                      <input type="text" value={draft.homepage.primaryCtaHref} onChange={e => update('homepage', { ...draft.homepage, primaryCtaHref: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Secondary CTA Label</label>
                      <input type="text" value={draft.homepage.secondaryCtaLabel} onChange={e => update('homepage', { ...draft.homepage, secondaryCtaLabel: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Secondary CTA Link</label>
                      <input type="text" value={draft.homepage.secondaryCtaHref} onChange={e => update('homepage', { ...draft.homepage, secondaryCtaHref: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Hero Background Image</label>
                    <div className="flex items-start gap-4">
                      <div className="w-40 h-24 rounded-xl overflow-hidden bg-gray-100 shrink-0">
                        {draft.homepage.heroImage && <img src={draft.homepage.heroImage} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div className="flex-1">
                        <label className="block w-full mb-2">
                          <div className="rounded-xl border-2 border-dashed border-gray-200 bg-gray-50 px-4 py-2.5 text-center text-sm text-gray-600 hover:border-accent-400 cursor-pointer flex items-center justify-center gap-2">
                            {heroImageUploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                            {heroImageUploading ? 'Uploading...' : 'Upload Image'}
                          </div>
                          <input ref={heroInputRef} type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'heroImage')} className="hidden" />
                        </label>
                        <input
                          type="url"
                          placeholder="Or paste image URL"
                          value={draft.homepage.heroImage}
                          onChange={e => update('homepage', { ...draft.homepage, heroImage: e.target.value })}
                          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400"
                        />
                        {draft.homepage.heroImage && (
                          <button
                            onClick={() => update('homepage', { ...draft.homepage, heroImage: '' })}
                            className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-red-600 hover:text-red-700"
                          >
                            <Trash2 size={14} /> Delete Hero Image
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Stats */}
              <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="font-serif text-xl font-bold text-gray-900">Stats Bar</h2>
                    <p className="text-sm text-gray-500">Numbers displayed just below the hero.</p>
                  </div>
                  <button onClick={addStat} className="inline-flex items-center gap-1.5 rounded-xl bg-gray-900 text-white px-3 py-2 text-sm font-semibold hover:bg-gray-800">
                    <Plus size={14} /> Add Stat
                  </button>
                </div>
                <div className="space-y-3">
                  {draft.homepage.stats.map((s) => (
                    <div key={s.id} className="flex items-center gap-3 rounded-xl border border-gray-200 p-3">
                      <input type="text" placeholder="Value (e.g. 15+)" value={s.value} onChange={e => updateStat(s.id, { value: e.target.value })} className="w-24 rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400 font-bold" />
                      <input type="text" placeholder="Label" value={s.label} onChange={e => updateStat(s.id, { label: e.target.value })} className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400" />
                      <button onClick={() => removeStat(s.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                  {draft.homepage.stats.length === 0 && (
                    <p className="text-sm text-gray-400 italic py-3">No stats yet. Click Add Stat.</p>
                  )}
                </div>
              </section>

              {/* Services */}
              <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="font-serif text-xl font-bold text-gray-900">Services</h2>
                    <p className="text-sm text-gray-500">Service cards in the "What We Do" section.</p>
                  </div>
                  <button onClick={addService} className="inline-flex items-center gap-1.5 rounded-xl bg-gray-900 text-white px-3 py-2 text-sm font-semibold hover:bg-gray-800">
                    <Plus size={14} /> Add Service
                  </button>
                </div>
                <div className="space-y-3">
                  {draft.homepage.services.map((s) => (
                    <div key={s.id} className="rounded-xl border border-gray-200 p-4 space-y-3">
                      <div className="flex items-start gap-2">
                        <select value={s.icon} onChange={e => updateService(s.id, { icon: e.target.value as any })} className="rounded-lg border border-gray-200 px-2 py-2 text-sm bg-white outline-none">
                          <option value="home">🏠 Home</option>
                          <option value="building">🏢 Building</option>
                          <option value="trend">📈 Trend</option>
                          <option value="key">🔑 Key</option>
                          <option value="handshake">🤝 Handshake</option>
                          <option value="shield">🛡️ Shield</option>
                        </select>
                        <input type="text" placeholder="Title" value={s.title} onChange={e => updateService(s.id, { title: e.target.value })} className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400 font-semibold" />
                        <button onClick={() => removeService(s.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <textarea rows={2} placeholder="Description" value={s.description} onChange={e => updateService(s.id, { description: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400 resize-none" />
                      <div className="grid grid-cols-2 gap-2">
                        <input type="text" placeholder="Link label" value={s.linkLabel} onChange={e => updateService(s.id, { linkLabel: e.target.value })} className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400" />
                        <input type="text" placeholder="Link href (e.g. /listings)" value={s.linkHref} onChange={e => updateService(s.id, { linkHref: e.target.value })} className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400" />
                      </div>
                    </div>
                  ))}
                  {draft.homepage.services.length === 0 && (
                    <p className="text-sm text-gray-400 italic py-3">No services yet. Click Add Service.</p>
                  )}
                </div>
              </section>

              {/* Testimonials */}
              <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="font-serif text-xl font-bold text-gray-900">Testimonials</h2>
                    <p className="text-sm text-gray-500">Client reviews shown on the homepage.</p>
                  </div>
                  <button onClick={addTestimonial} className="inline-flex items-center gap-1.5 rounded-xl bg-gray-900 text-white px-3 py-2 text-sm font-semibold hover:bg-gray-800">
                    <Plus size={14} /> Add Testimonial
                  </button>
                </div>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Section Heading</label>
                    <input type="text" value={draft.homepage.testimonialsHeading} onChange={e => update('homepage', { ...draft.homepage, testimonialsHeading: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Subheading</label>
                    <input type="text" value={draft.homepage.testimonialsSubheading} onChange={e => update('homepage', { ...draft.homepage, testimonialsSubheading: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                  </div>
                </div>
                <div className="space-y-3">
                  {draft.homepage.testimonials.map((t) => (
                    <div key={t.id} className="rounded-xl border border-gray-200 p-4 space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="w-14 h-14 rounded-full bg-gray-100 overflow-hidden shrink-0">
                          {t.avatar ? (
                            <img src={t.avatar} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center"><ImageIcon size={18} className="text-gray-300" /></div>
                          )}
                        </div>
                        <div className="flex-1 grid sm:grid-cols-2 gap-2">
                          <input type="text" placeholder="Client name" value={t.name} onChange={e => updateTestimonial(t.id, { name: e.target.value })} className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400 font-semibold" />
                          <input type="text" placeholder="Role / Title" value={t.role} onChange={e => updateTestimonial(t.id, { role: e.target.value })} className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400" />
                        </div>
                        <button onClick={() => removeTestimonial(t.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <textarea rows={2} placeholder="Testimonial quote" value={t.quote} onChange={e => updateTestimonial(t.id, { quote: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400 resize-none" />
                      <input type="url" placeholder="Avatar image URL" value={t.avatar} onChange={e => updateTestimonial(t.id, { avatar: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-accent-400" />
                    </div>
                  ))}
                  {draft.homepage.testimonials.length === 0 && (
                    <p className="text-sm text-gray-400 italic py-3">No testimonials yet. Click Add Testimonial.</p>
                  )}
                </div>
              </section>

              {/* CTA */}
              <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
                <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Final CTA Section</h2>
                <p className="text-sm text-gray-500 mb-6">The closing call-to-action on the homepage.</p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Heading</label>
                    <input type="text" value={draft.homepage.ctaHeading} onChange={e => update('homepage', { ...draft.homepage, ctaHeading: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Subheading</label>
                    <input type="text" value={draft.homepage.ctaSubheading} onChange={e => update('homepage', { ...draft.homepage, ctaSubheading: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                  </div>
                </div>
              </section>
            </>
          )}

          {activeTab === 'security' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Admin Access</h2>
              <p className="text-sm text-gray-500 mb-6">Set credentials required to access the admin dashboard. Leave both blank to allow open access (no login needed).</p>

              {!draft.security.adminUsername && !draft.security.adminPassword && (
                <div className="mb-6 rounded-xl border border-blue-200 bg-blue-50 p-4 flex items-start gap-3">
                  <AlertCircle size={18} className="text-blue-600 shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-900">
                    <strong>Open access mode.</strong> Anyone who visits <code className="bg-blue-100 px-1 rounded text-xs">/admin/login</code> can access the dashboard without credentials.
                  </div>
                </div>
              )}

              {(draft.security.adminUsername || draft.security.adminPassword) && (
                <div className="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
                  <CheckCircle size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                  <div className="text-sm text-emerald-900">
                    <strong>Password protected.</strong> Only users with the configured username and password can sign in.
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Admin Username</label>
                  <input
                    type="text"
                    value={draft.security.adminUsername}
                    onChange={e => update('security', { ...draft.security, adminUsername: e.target.value })}
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400"
                    placeholder="admin"
                    autoComplete="off"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Admin Password</label>
                  <input
                    type="text"
                    value={draft.security.adminPassword}
                    onChange={e => update('security', { ...draft.security, adminPassword: e.target.value })}
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400"
                    placeholder="••••••••"
                    autoComplete="off"
                  />
                  <p className="mt-1 text-xs text-gray-400">Stored in plain text. For stronger security, configure Firebase Auth instead.</p>
                </div>
              </div>

              {(draft.security.adminUsername || draft.security.adminPassword) && (
                <button
                  onClick={() => update('security', { adminUsername: '', adminPassword: '' })}
                  className="mt-4 inline-flex items-center gap-1.5 text-sm text-red-600 hover:text-red-700 font-medium"
                >
                  <X size={14} /> Clear credentials (enable open access)
                </button>
              )}
            </section>
          )}

          {activeTab === 'api' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">API Keys</h2>
              <p className="text-sm text-gray-500 mb-6">Connect third-party services used by the site.</p>

              <div className="space-y-6">
                <div className="rounded-2xl border border-gray-200 p-5">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <h3 className="font-semibold text-gray-900">Web3Forms</h3>
                      <p className="text-xs text-gray-500 mt-1">
                        Used to send property email inquiries. Get a free key at{' '}
                        <a href="https://web3forms.com" target="_blank" rel="noreferrer" className="text-accent-600 hover:underline">web3forms.com</a>.
                      </p>
                    </div>
                    {draft.api.web3formsAccessKey && draft.api.web3formsAccessKey !== 'REPLACE_WITH_WEB3FORMS_ACCESS_KEY' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
                        <CheckCircle size={12} /> Connected
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-700">Not connected</span>
                    )}
                  </div>
                  <input
                    type="text"
                    placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                    value={draft.api.web3formsAccessKey}
                    onChange={e => update('api', { ...draft.api, web3formsAccessKey: e.target.value })}
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400 font-mono"
                  />
                  {draft.api.web3formsAccessKey && (
                    <button
                      onClick={() => update('api', { ...draft.api, web3formsAccessKey: '' })}
                      className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} /> Delete Web3Forms API Key
                    </button>
                  )}
                </div>
              </div>
            </section>
          )}

          {activeTab === 'seo' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">SEO</h2>
              <p className="text-sm text-gray-500 mb-6">Default meta content for the site.</p>

              <div className="space-y-5">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Meta Description</label>
                  <textarea rows={3} value={draft.seo.metaDescription} onChange={e => update('seo', { ...draft.seo, metaDescription: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400 resize-none" />
                  <p className="mt-1 text-xs text-gray-400">{draft.seo.metaDescription.length}/160 recommended</p>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">Keywords (comma-separated)</label>
                  <input type="text" value={draft.seo.keywords} onChange={e => update('seo', { ...draft.seo, keywords: e.target.value })} className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-accent-400" />
                </div>
              </div>
            </section>
          )}

          {activeTab === 'demo' && (
            <section className="rounded-2xl border border-gray-100 bg-white p-6 lg:p-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-1">Demo Data Control</h2>
              <p className="text-sm text-gray-500 mb-6">Example properties, blog posts, and team members are pre-loaded for preview. You can hide them or delete them once you add your own content.</p>

              <label className="flex items-start gap-3 rounded-2xl border border-gray-200 bg-gray-50 p-4 cursor-pointer hover:bg-gray-100 transition-colors">
                <input
                  type="checkbox"
                  checked={draft.demoData.hideDemoData}
                  onChange={e => update('demoData', { ...draft.demoData, hideDemoData: e.target.checked })}
                  className="mt-1 w-4 h-4 accent-accent-500"
                />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900">Hide demo content from public site</div>
                  <div className="text-xs text-gray-500 mt-1">
                    When enabled, only content you create in the admin panel will appear on the public site. Demo records stay in the database but are hidden from visitors.
                  </div>
                </div>
              </label>

              <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                <div className="font-semibold mb-1 flex items-center gap-2">
                  <AlertCircle size={14} /> How to replace demo data
                </div>
                <ol className="list-decimal list-inside space-y-1 text-xs text-amber-800 mt-2">
                  <li>Go to <strong>Properties</strong>, <strong>Blog Posts</strong>, or <strong>Team</strong> and add your own content.</li>
                  <li>Delete demo items one by one using the trash icon, or toggle the setting above to hide them all at once.</li>
                  <li>Your new content will appear on the public site immediately.</li>
                </ol>
              </div>
            </section>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
