import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Building2, FileText, Users, MessageSquare, TrendingUp, DollarSign, ArrowRight, Loader2 } from 'lucide-react';
import { getProperties, getBlogPosts, getTeamMembers, getInquiries } from '../../lib/backend';
import AdminLayout from '../../components/admin/AdminLayout';
import { formatPrice } from '../../utils/currency';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ properties: 0, blog: 0, team: 0, inquiries: 0, totalValue: 0 });
  const [loading, setLoading] = useState(true);
  const [recentProperties, setRecentProperties] = useState<any[]>([]);
  const [recentInquiries, setRecentInquiries] = useState<any[]>([]);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const [properties, blog, team, inquiries] = await Promise.all([
          getProperties(),
          getBlogPosts(),
          getTeamMembers(),
          getInquiries(),
        ]);
        setStats({
          properties: properties.length,
          blog: blog.length,
          team: team.length,
          inquiries: inquiries.length,
          totalValue: properties.reduce((sum, p) => sum + (p.price || 0), 0),
        });
        setRecentProperties(properties.slice(0, 5));
        setRecentInquiries(inquiries.slice(0, 5));
      } catch (error) {
        console.error('Error loading stats:', error);
      } finally {
        setLoading(false);
      }
    };
    loadStats();
  }, []);

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back! Here's what's happening with your listings.</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : (
        <>
          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {[
              { label: 'Properties', value: stats.properties, icon: Building2, color: 'bg-blue-500', link: '/admin/properties' },
              { label: 'Blog Posts', value: stats.blog, icon: FileText, color: 'bg-purple-500', link: '/admin/blog' },
              { label: 'Team Members', value: stats.team, icon: Users, color: 'bg-emerald-500', link: '/admin/team' },
              { label: 'Inquiries', value: stats.inquiries, icon: MessageSquare, color: 'bg-amber-500', link: '/admin/inquiries' },
            ].map(({ label, value, icon: Icon, color, link }) => (
              <Link
                key={label}
                to={link}
                className="bg-white rounded-xl p-5 border border-gray-100 hover:shadow-lg hover:-translate-y-0.5 transition-all"
              >
                <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center mb-3`}>
                  <Icon size={20} className="text-white" />
                </div>
                <div className="text-2xl lg:text-3xl font-bold text-gray-900 font-serif">{value}</div>
                <div className="text-sm text-gray-500 mt-1">{label}</div>
              </Link>
            ))}
          </div>

          {/* Total Value */}
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 lg:p-8 mb-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-accent-500 opacity-10 blur-3xl" />
            <div className="relative">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-accent-500/20 flex items-center justify-center">
                  <DollarSign size={20} className="text-accent-400" />
                </div>
                <span className="text-sm text-gray-300">Total Portfolio Value</span>
              </div>
              <div className="text-3xl lg:text-4xl font-bold font-serif">{formatPrice(stats.totalValue)}</div>
              <div className="flex items-center gap-2 mt-2 text-sm text-gray-300">
                <TrendingUp size={14} className="text-emerald-400" />
                <span>Across {stats.properties} active listings</span>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Recent Properties */}
            <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between p-5 border-b border-gray-100">
                <h2 className="font-semibold text-gray-900">Recent Properties</h2>
                <Link to="/admin/properties" className="text-sm text-accent-600 hover:text-accent-700 flex items-center gap-1">
                  View All <ArrowRight size={14} />
                </Link>
              </div>
              <div className="divide-y divide-gray-50">
                {recentProperties.length === 0 ? (
                  <p className="p-5 text-sm text-gray-500">No properties yet.</p>
                ) : (
                  recentProperties.map((p) => (
                    <Link key={p.id} to={`/admin/properties/${p.id}`} className="flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors">
                      {p.images?.[0] ? (
                        <img src={p.images[0]} alt="" className="w-14 h-14 rounded-lg object-cover" />
                      ) : (
                        <div className="w-14 h-14 rounded-lg bg-gray-100 flex items-center justify-center">
                          <Building2 size={18} className="text-gray-400" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm text-gray-900 truncate">{p.title || p.address}</div>
                        <div className="text-xs text-gray-500">{p.city}, {p.state}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold text-gray-900">{formatPrice(p.price)}</div>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          p.status === 'For Sale' ? 'bg-emerald-50 text-emerald-700' :
                          p.status === 'Pending' ? 'bg-amber-50 text-amber-700' :
                          'bg-gray-50 text-gray-700'
                        }`}>
                          {p.status}
                        </span>
                      </div>
                    </Link>
                  ))
                )}
              </div>
            </div>

            {/* Recent Inquiries */}
            <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between p-5 border-b border-gray-100">
                <h2 className="font-semibold text-gray-900">Recent Inquiries</h2>
                <Link to="/admin/inquiries" className="text-sm text-accent-600 hover:text-accent-700 flex items-center gap-1">
                  View All <ArrowRight size={14} />
                </Link>
              </div>
              <div className="divide-y divide-gray-50">
                {recentInquiries.length === 0 ? (
                  <p className="p-5 text-sm text-gray-500">No inquiries yet.</p>
                ) : (
                  recentInquiries.map((i) => (
                    <div key={i.id} className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <div className="font-medium text-sm text-gray-900">{i.firstName} {i.lastName}</div>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          i.status === 'new' ? 'bg-blue-50 text-blue-700' :
                          i.status === 'contacted' ? 'bg-amber-50 text-amber-700' :
                          'bg-gray-50 text-gray-700'
                        }`}>
                          {i.status}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 mb-1">{i.email} • {i.phone}</div>
                      <div className="text-sm text-gray-600 line-clamp-2">{i.message}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </AdminLayout>
  );
}
