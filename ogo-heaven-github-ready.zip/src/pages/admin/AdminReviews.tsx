import { useEffect, useMemo, useState } from 'react';
import { Check, Loader2, MessageSquare, Star, Trash2, X } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { deleteReview, Review, ReviewStatus, subscribeAllReviews, updateReviewStatus } from '../../lib/reviews';

function Stars({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(star => (
        <Star key={star} size={14} className={star <= value ? 'fill-accent-400 text-accent-400' : 'text-gray-300'} />
      ))}
    </div>
  );
}

function statusClass(status: ReviewStatus) {
  if (status === 'approved') return 'bg-emerald-50 text-emerald-700';
  if (status === 'rejected') return 'bg-red-50 text-red-700';
  return 'bg-amber-50 text-amber-700';
}

export default function AdminReviews() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | ReviewStatus>('pending');

  useEffect(() => {
    let unsub: (() => void) | undefined;
    subscribeAllReviews((nextReviews) => {
      setReviews(nextReviews);
      setLoading(false);
    }).then(fn => { unsub = fn; });
    return () => unsub?.();
  }, []);

  const filtered = useMemo(() => (
    filter === 'all' ? reviews : reviews.filter(review => review.status === filter)
  ), [reviews, filter]);

  const counts = useMemo(() => ({
    all: reviews.length,
    pending: reviews.filter(r => r.status === 'pending').length,
    approved: reviews.filter(r => r.status === 'approved').length,
    rejected: reviews.filter(r => r.status === 'rejected').length,
  }), [reviews]);

  const averageApproved = useMemo(() => {
    const approved = reviews.filter(r => r.status === 'approved');
    if (!approved.length) return 0;
    return Math.round((approved.reduce((sum, r) => sum + r.rating, 0) / approved.length) * 10) / 10;
  }, [reviews]);

  const handleStatus = async (id: string, status: ReviewStatus) => {
    await updateReviewStatus(id, status);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this review permanently?')) return;
    await deleteReview(id);
  };

  return (
    <AdminLayout>
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold text-gray-900">Reviews</h1>
          <p className="text-gray-500 mt-1">Approve client reviews before they appear publicly.</p>
        </div>
        <div className="rounded-2xl bg-white border border-gray-100 p-4 min-w-64">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">Approved Rating</p>
          <div className="mt-1 flex items-end gap-2">
            <span className="font-serif text-4xl font-bold text-gray-900">{averageApproved.toFixed(1)}</span>
            <span className="pb-1 text-gray-400">/5</span>
            <Stars value={Math.round(averageApproved)} />
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {(['all', 'pending', 'approved', 'rejected'] as const).map(status => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors capitalize ${
              filter === status
                ? 'bg-gray-900 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {status} ({counts[status]})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
          <MessageSquare size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">No reviews here</h3>
          <p className="text-gray-500 text-sm">No reviews match this status.</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-5">
          {filtered.map(review => (
            <article key={review.id} className="bg-white rounded-2xl border border-gray-100 p-5">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{review.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${statusClass(review.status)}`}>
                      {review.status}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">{review.email}{review.phone ? ` • ${review.phone}` : ''}</div>
                  <div className="text-xs text-gray-400 mt-1">
                    Submitted {new Date(review.createdAt).toLocaleString()}
                  </div>
                </div>
                <Stars value={review.rating} />
              </div>

              <blockquote className="rounded-xl bg-gray-50 p-4 text-sm leading-relaxed text-gray-700 mb-4">
                "{review.message}"
              </blockquote>

              <div className="flex flex-wrap gap-2">
                {review.status !== 'approved' && (
                  <button
                    onClick={() => handleStatus(review.id, 'approved')}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-500 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-600"
                  >
                    <Check size={14} /> Approve
                  </button>
                )}
                {review.status !== 'rejected' && (
                  <button
                    onClick={() => handleStatus(review.id, 'rejected')}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
                  >
                    <X size={14} /> Reject
                  </button>
                )}
                {review.status !== 'pending' && (
                  <button
                    onClick={() => handleStatus(review.id, 'pending')}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
                  >
                    Mark Pending
                  </button>
                )}
                <button
                  onClick={() => handleDelete(review.id)}
                  className="ml-auto inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50"
                >
                  <Trash2 size={14} /> Delete
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
