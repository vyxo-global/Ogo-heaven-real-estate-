import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Plus, Edit2, Trash2, ArrowLeft, Loader2, Save, FileText } from 'lucide-react';
import { getBlogPosts, saveBlogPost, deleteBlogPost } from '../../lib/backend';
import AdminLayout from '../../components/admin/AdminLayout';
import { isFirebaseConfigured } from '../../lib/firebase';

const emptyPost = {
  title: '',
  excerpt: '',
  content: '',
  category: 'Market Update',
  date: new Date().toISOString().split('T')[0],
  readTime: '5 min read',
  image: '',
  slug: '',
};

export default function AdminBlog() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) loadPosts();
  }, [id]);

  useEffect(() => {
    if (id === 'new') {
      setEditing({ ...emptyPost });
    } else if (id) {
      const post = posts.find(p => p.id === id);
      if (post) setEditing({ ...emptyPost, ...post });
    }
  }, [id, posts]);

  const loadPosts = async () => {
    setLoading(true);
    try {
      const data = await getBlogPosts();
      setPosts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!isFirebaseConfigured) { alert('Firebase not configured.'); return; }
    setSaving(true);
    try {
      const { id: postId, ...data } = editing;
      const slug = data.slug || data.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      await saveBlogPost({ ...data, slug }, postId === 'new' ? undefined : postId);
      navigate('/admin/blog');
    } catch (err) {
      console.error(err);
      alert('Error saving post');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!confirm('Delete this post?')) return;
    try {
      await deleteBlogPost(postId);
      await loadPosts();
    } catch (err) {
      console.error(err);
    }
  };

  const updateField = (field: string, value: any) => {
    setEditing((prev: any) => ({ ...prev, [field]: value }));
  };

  if (editing) {
    return (
      <AdminLayout>
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div>
            <button
              onClick={() => navigate('/admin/blog')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900 font-medium text-sm transition-all active:scale-95 mb-2"
            >
              <ArrowLeft size={18} /> Back to Blog Posts
            </button>
            <h1 className="font-serif text-2xl lg:text-3xl font-bold text-gray-900">
              {id === 'new' ? 'New Blog Post' : 'Edit Blog Post'}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {id && id !== 'new' && (
              <button
                onClick={async () => {
                  if (!confirm('Delete this post permanently?')) return;
                  try {
                    await deleteBlogPost(id);
                  } catch {
                    // Local mode
                  }
                  navigate('/admin/blog');
                }}
                className="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 font-semibold text-sm hover:bg-red-50 flex items-center gap-2"
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 disabled:opacity-50 flex items-center gap-2"
            >
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
              {saving ? 'Saving...' : 'Save Post'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Title</label>
                <input
                  type="text"
                  value={editing.title}
                  onChange={(e) => updateField('title', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
                <select
                  value={editing.category}
                  onChange={(e) => updateField('category', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 bg-white"
                >
                  <option>Market Update</option>
                  <option>Buying</option>
                  <option>Selling</option>
                  <option>Neighborhoods</option>
                  <option>Lifestyle</option>
                  <option>Resources</option>
                  <option>Investment</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Date</label>
                <input
                  type="date"
                  value={editing.date}
                  onChange={(e) => updateField('date', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Read Time</label>
                <input
                  type="text"
                  value={editing.readTime}
                  onChange={(e) => updateField('readTime', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Slug (URL)</label>
                <input
                  type="text"
                  value={editing.slug}
                  onChange={(e) => updateField('slug', e.target.value)}
                  placeholder="auto-generated-from-title"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Cover Image URL</label>
                <input
                  type="url"
                  value={editing.image}
                  onChange={(e) => updateField('image', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                  placeholder="https://..."
                />
                {editing.image && (
                  <div className="mt-3">
                    <img src={editing.image} alt="" className="w-full max-w-md rounded-lg aspect-[16/9] object-cover" />
                    <button
                      onClick={() => updateField('image', '')}
                      className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} /> Delete Cover Image
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Excerpt</label>
            <textarea
              rows={3}
              value={editing.excerpt}
              onChange={(e) => updateField('excerpt', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 resize-none"
            />
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Content</label>
            <textarea
              rows={12}
              value={editing.content}
              onChange={(e) => updateField('content', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 resize-y font-mono"
              placeholder="Write your blog post content here..."
            />
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-gray-900">Blog Posts</h1>
          <p className="text-gray-500 mt-1">Manage your blog content</p>
        </div>
        <Link
          to="/admin/blog/new"
          className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 flex items-center gap-2"
        >
          <Plus size={16} />
          New Post
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : posts.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-100 p-16 text-center">
          <FileText size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="font-semibold text-gray-900 mb-1">No blog posts yet</h3>
          <p className="text-sm text-gray-500 mb-4">Create your first blog post.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {posts.map((post) => (
            <div key={post.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all">
              <div className="aspect-[16/9] overflow-hidden bg-gray-100">
                {post.image && <img src={post.image} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="p-4">
                <span className="text-xs font-semibold text-accent-600 uppercase">{post.category}</span>
                <h3 className="font-semibold text-gray-900 mt-1 line-clamp-2">{post.title}</h3>
                <p className="text-sm text-gray-500 mt-1 line-clamp-2">{post.excerpt}</p>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                  <span className="text-xs text-gray-400">{post.date}</span>
                  <div className="flex items-center gap-2">
                    <Link to={`/admin/blog/${post.id}`} className="p-2 rounded-lg text-gray-500 hover:bg-gray-100" title="Edit">
                      <Edit2 size={14} />
                    </Link>
                    <button onClick={() => handleDelete(post.id)} className="p-2 rounded-lg text-gray-500 hover:bg-red-50 hover:text-red-600" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
