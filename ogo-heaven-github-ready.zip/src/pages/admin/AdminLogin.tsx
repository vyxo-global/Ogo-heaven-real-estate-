import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, Lock, Loader2, AlertCircle, ArrowLeft, ShieldCheck } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { isAdminOpenAccess, setAdminSession, verifyCredentials, getAdminSession } from '../../lib/adminAuth';

export default function AdminLogin() {
  const { settings } = useSettings();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const openAccess = isAdminOpenAccess(settings.security.adminUsername, settings.security.adminPassword);

  // If already logged in, redirect
  useEffect(() => {
    if (getAdminSession()) navigate('/admin');
  }, [navigate]);

  // If open access, any visit to the login page should still let the user proceed.
  // Show a helpful banner that no password is set.

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // If open access: accept any input (or even empty).
    if (openAccess) {
      setAdminSession({ username: username || 'open-access', loggedAt: new Date().toISOString() });
      navigate('/admin');
      return;
    }

    // Otherwise verify
    await new Promise(r => setTimeout(r, 300)); // tiny delay for UX
    if (verifyCredentials(username, password, settings.security.adminUsername, settings.security.adminPassword)) {
      setAdminSession({ username, loggedAt: new Date().toISOString() });
      navigate('/admin');
    } else {
      setError('Invalid username or password.');
      setLoading(false);
    }
  };

  const handleOpenAccessContinue = () => {
    setAdminSession({ username: 'open-access', loggedAt: new Date().toISOString() });
    navigate('/admin');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 py-12">
      <div className="w-full max-w-md">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 mb-6">
          <ArrowLeft size={16} />
          Back to Website
        </Link>

        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-xl bg-gray-900 flex items-center justify-center mx-auto mb-4 relative">
              <span className="font-serif text-white text-2xl font-bold italic">
                {settings.company.logoUrl ? (
                  <img src={settings.company.logoUrl} alt="" className="w-full h-full object-cover rounded-xl" />
                ) : (
                  settings.company.logoText || 'O'
                )}
              </span>
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-accent-500" />
            </div>
            <h1 className="font-serif text-2xl font-bold text-gray-900">Admin Sign In</h1>
            <p className="text-sm text-gray-500 mt-1">{settings.company.name} {settings.company.tagline}</p>
          </div>

          {openAccess && (
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="flex items-start gap-3">
                <ShieldCheck size={18} className="text-blue-600 shrink-0 mt-0.5" />
                <div className="text-xs text-blue-900">
                  <strong>Open access mode.</strong>
                  <p className="mt-1">No admin password is set yet. You can continue without credentials, or set one later in <strong>Settings → Security</strong>.</p>
                </div>
              </div>
              <button
                onClick={handleOpenAccessContinue}
                className="mt-3 w-full rounded-xl bg-blue-600 text-white py-2.5 text-sm font-semibold hover:bg-blue-700 transition-colors"
              >
                Continue to Dashboard
              </button>
            </div>
          )}

          {!openAccess && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Username</label>
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    autoFocus
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-accent-400 text-sm"
                    placeholder="admin"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 outline-none focus:border-accent-400 text-sm"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700 flex items-start gap-2">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-800 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : null}
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          )}

          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-500 text-center">
              {openAccess
                ? 'Configure credentials under Admin → Settings → Security.'
                : 'Protected area. Only authorized administrators may access.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
