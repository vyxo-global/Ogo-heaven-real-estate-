import { useState, useEffect } from 'react';
import { Trash2, Loader2, MessageSquare, Mail, Phone, Calendar, Check, X } from 'lucide-react';
import { getInquiries, updateInquiryStatus, deleteInquiry } from '../../lib/backend';
import AdminLayout from '../../components/admin/AdminLayout';
import { isFirebaseConfigured } from '../../lib/firebase';

export default function AdminInquiries() {
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'new' | 'contacted' | 'closed'>('all');
  const [selected, setSelected] = useState<any>(null);

  useEffect(() => { loadInquiries(); }, []);

  const loadInquiries = async () => {
    setLoading(true);
    try {
      const data = await getInquiries();
      setInquiries(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (id: string, status: 'new' | 'contacted' | 'closed') => {
    try {
      await updateInquiryStatus(id, status);
      await loadInquiries();
      if (selected?.id === id) setSelected({ ...selected, status });
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this inquiry?')) return;
    try {
      await deleteInquiry(id);
      await loadInquiries();
      if (selected?.id === id) setSelected(null);
    } catch (err) {
      console.error(err);
    }
  };

  const filtered = filter === 'all' ? inquiries : inquiries.filter(i => i.status === filter);
  const statusCounts = {
    all: inquiries.length,
    new: inquiries.filter(i => i.status === 'new').length,
    contacted: inquiries.filter(i => i.status === 'contacted').length,
    closed: inquiries.filter(i => i.status === 'closed').length,
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="font-serif text-3xl font-bold text-gray-900">Inquiries</h1>
        <p className="text-gray-500 mt-1">Manage contact form submissions</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {(['all', 'new', 'contacted', 'closed'] as const).map(status => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors capitalize ${
              filter === status
                ? 'bg-gray-900 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {status} ({statusCounts[status]})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-100 p-16 text-center">
          <MessageSquare size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="font-semibold text-gray-900 mb-1">No inquiries</h3>
          <p className="text-sm text-gray-500">No inquiries match this filter.</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* List */}
          <div className="lg:col-span-2 space-y-3">
            {filtered.map(inq => (
              <div
                key={inq.id}
                onClick={() => setSelected(inq)}
                className={`bg-white rounded-xl border p-4 cursor-pointer transition-all hover:shadow-md ${
                  selected?.id === inq.id ? 'border-accent-400 shadow-md' : 'border-gray-100'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900">{inq.firstName} {inq.lastName}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${
                        inq.status === 'new' ? 'bg-blue-50 text-blue-700' :
                        inq.status === 'contacted' ? 'bg-amber-50 text-amber-700' :
                        'bg-gray-50 text-gray-700'
                      }`}>
                        {inq.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1"><Mail size={12} /> {inq.email}</span>
                      <span className="flex items-center gap-1"><Phone size={12} /> {inq.phone}</span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400 whitespace-nowrap flex items-center gap-1">
                    <Calendar size={12} />
                    {new Date(inq.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="text-sm text-gray-700 line-clamp-2 bg-gray-50 p-2 rounded-lg">
                  <span className="text-xs font-semibold text-gray-500 uppercase">Interested in: {inq.interest}</span>
                  <p className="mt-1">{inq.message}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Detail Panel */}
          <div className="lg:sticky lg:top-6 h-fit">
            {selected ? (
              <div className="bg-white rounded-xl border border-gray-100 p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900 text-lg">{selected.firstName} {selected.lastName}</h3>
                    <p className="text-sm text-gray-500">{new Date(selected.createdAt).toLocaleString()}</p>
                  </div>
                  <button onClick={() => setSelected(null)} className="p-1 text-gray-400 hover:text-gray-700">
                    <X size={18} />
                  </button>
                </div>

                <div className="space-y-3 mb-5 pb-5 border-b border-gray-100">
                  <a href={`mailto:${selected.email}`} className="flex items-center gap-2 text-sm text-gray-700 hover:text-accent-600">
                    <Mail size={14} className="text-gray-400" /> {selected.email}
                  </a>
                  <a href={`tel:${selected.phone}`} className="flex items-center gap-2 text-sm text-gray-700 hover:text-accent-600">
                    <Phone size={14} className="text-gray-400" /> {selected.phone}
                  </a>
                </div>

                <div className="mb-4">
                  <span className="text-xs font-semibold text-gray-500 uppercase">Interest</span>
                  <p className="text-sm text-gray-900 mt-1">{selected.interest}</p>
                </div>

                <div className="mb-5">
                  <span className="text-xs font-semibold text-gray-500 uppercase">Message</span>
                  <p className="text-sm text-gray-700 mt-1 whitespace-pre-wrap">{selected.message}</p>
                </div>

                <div className="space-y-2 pt-4 border-t border-gray-100">
                  <span className="text-xs font-semibold text-gray-500 uppercase block mb-2">Update Status</span>
                  <div className="flex gap-2">
                    {(['new', 'contacted', 'closed'] as const).map(status => (
                      <button
                        key={status}
                        onClick={() => handleStatusUpdate(selected.id, status)}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium capitalize transition-colors ${
                          selected.status === status
                            ? 'bg-gray-900 text-white'
                            : 'border border-gray-200 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {status === 'contacted' && <Check size={12} className="inline mr-1" />}
                        {status}
                      </button>
                    ))}
                  </div>
                </div>

                {isFirebaseConfigured && (
                  <button
                    onClick={() => handleDelete(selected.id)}
                    className="w-full mt-4 py-2 rounded-lg text-red-600 text-sm font-medium hover:bg-red-50 flex items-center justify-center gap-1"
                  >
                    <Trash2 size={14} /> Delete Inquiry
                  </button>
                )}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-100 p-8 text-center">
                <MessageSquare size={32} className="mx-auto text-gray-300 mb-2" />
                <p className="text-sm text-gray-500">Select an inquiry to view details</p>
              </div>
            )}
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
