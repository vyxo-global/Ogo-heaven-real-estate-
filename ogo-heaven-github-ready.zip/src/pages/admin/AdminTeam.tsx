import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, X, Loader2, Save, Users, ArrowLeft, Upload } from 'lucide-react';
import { getTeamMembers, saveTeamMember, deleteTeamMember, uploadFile } from '../../lib/backend';
import AdminLayout from '../../components/admin/AdminLayout';
import { isFirebaseConfigured } from '../../lib/firebase';

const emptyMember = {
  name: '',
  role: '',
  photo: '',
  bio: '',
  specialties: [] as string[],
  phone: '',
  email: '',
  transactions: 0,
  yearsOfExperience: 0,
};

export default function AdminTeam() {
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [specialtyInput, setSpecialtyInput] = useState('');
  const [photoUploading, setPhotoUploading] = useState(false);

  useEffect(() => { loadMembers(); }, []);

  const loadMembers = async () => {
    setLoading(true);
    try {
      const data = await getTeamMembers();
      setMembers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (member: any) => {
    setEditing({ ...emptyMember, ...member, specialties: [...(member.specialties || [])] });
  };

  const startNew = () => setEditing({ ...emptyMember });

  const handleSave = async () => {
    if (!isFirebaseConfigured) { alert('Firebase not configured.'); return; }
    setSaving(true);
    try {
      const { id, ...data } = editing;
      await saveTeamMember(data, id);
      setEditing(null);
      await loadMembers();
    } catch (err) {
      console.error(err);
      alert('Error saving member');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (memberId: string) => {
    if (!confirm('Remove this team member?')) return;
    try {
      await deleteTeamMember(memberId);
      await loadMembers();
    } catch (err) {
      console.error(err);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoUploading(true);
    try {
      const url = await uploadFile(file, 'team');
      setEditing((prev: any) => ({ ...prev, photo: url }));
    } catch (err) {
      console.error(err);
      alert('Upload failed');
    } finally {
      setPhotoUploading(false);
    }
  };

  const addSpecialty = () => {
    if (!specialtyInput.trim()) return;
    setEditing((prev: any) => ({ ...prev, specialties: [...prev.specialties, specialtyInput.trim()] }));
    setSpecialtyInput('');
  };

  const removeSpecialty = (idx: number) => {
    setEditing((prev: any) => ({ ...prev, specialties: prev.specialties.filter((_: any, i: number) => i !== idx) }));
  };

  if (editing) {
    return (
      <AdminLayout>
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div>
            <button
              onClick={() => setEditing(null)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900 font-medium text-sm transition-all active:scale-95 mb-2"
            >
              <ArrowLeft size={18} /> Back to Team
            </button>
            <h1 className="font-serif text-2xl lg:text-3xl font-bold text-gray-900">
              {editing.id ? 'Edit Team Member' : 'New Team Member'}
            </h1>
          </div>
        <div className="flex items-center gap-2">
          {editing.id && (
            <button
              onClick={async () => {
                if (!confirm('Delete this team member permanently?')) return;
                try {
                  await deleteTeamMember(editing.id);
                } catch {
                  // Local mode
                }
                setEditing(null);
                await loadMembers();
              }}
              className="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 font-semibold text-sm hover:bg-red-50 flex items-center gap-2"
            >
              <Trash2 size={16} />
              Delete
            </button>
          )}
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 disabled:opacity-50 flex items-center gap-2"
          >
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h2 className="font-semibold text-gray-900 mb-4">Personal Info</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Name</label>
                  <input type="text" value={editing.name} onChange={e => setEditing((p: any) => ({ ...p, name: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Role</label>
                  <input type="text" value={editing.role} onChange={e => setEditing((p: any) => ({ ...p, role: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone</label>
                  <input type="text" value={editing.phone} onChange={e => setEditing((p: any) => ({ ...p, phone: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
                  <input type="email" value={editing.email} onChange={e => setEditing((p: any) => ({ ...p, email: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Transactions</label>
                  <input type="number" value={editing.transactions} onChange={e => setEditing((p: any) => ({ ...p, transactions: Number(e.target.value) }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Years of Experience</label>
                  <input type="number" value={editing.yearsOfExperience} onChange={e => setEditing((p: any) => ({ ...p, yearsOfExperience: Number(e.target.value) }))} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Bio</label>
                  <textarea rows={4} value={editing.bio} onChange={e => setEditing((p: any) => ({ ...p, bio: e.target.value }))} className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 resize-none" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-100 p-6">
              <h2 className="font-semibold text-gray-900 mb-4">Specialties</h2>
              <div className="flex flex-wrap gap-2 mb-3">
                {(editing.specialties || []).map((s: string, i: number) => (
                  <span key={i} className="inline-flex items-center gap-1 px-3 py-1 bg-gray-50 border border-gray-200 rounded-full text-sm">
                    {s}
                    <button onClick={() => removeSpecialty(i)} className="text-gray-400 hover:text-red-500">
                      <X size={14} />
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={specialtyInput}
                  onChange={e => setSpecialtyInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addSpecialty())}
                  className="flex-1 px-4 py-2 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                  placeholder="e.g., Luxury Homes"
                />
                <button onClick={addSpecialty} className="px-4 py-2 rounded-xl bg-gray-900 text-white text-sm font-medium">Add</button>
              </div>
            </div>
          </div>

          {/* Photo */}
          <div className="bg-white rounded-xl border border-gray-100 p-6 h-fit sticky top-6">
            <h2 className="font-semibold text-gray-900 mb-4">Profile Photo</h2>
            {editing.photo ? (
              <img src={editing.photo} alt="" className="w-full aspect-[3/4] rounded-xl object-cover mb-3" />
            ) : (
              <div className="w-full aspect-[3/4] rounded-xl bg-gray-100 flex items-center justify-center mb-3">
                <Users size={32} className="text-gray-300" />
              </div>
            )}
            <label className="block w-full">
              <div className="w-full py-2.5 rounded-xl border-2 border-dashed border-gray-200 text-center text-sm text-gray-600 hover:border-accent-400 hover:bg-gray-50 cursor-pointer flex items-center justify-center gap-2">
                {photoUploading ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                {photoUploading ? 'Uploading...' : 'Upload Photo'}
              </div>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" disabled={!isFirebaseConfigured} />
            </label>
            <input
              type="url"
              placeholder="Or paste photo URL"
              value={editing.photo || ''}
              onChange={e => setEditing((p: any) => ({ ...p, photo: e.target.value }))}
              className="w-full mt-2 px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400"
            />
            {editing.photo && (
              <button
                onClick={() => setEditing((p: any) => ({ ...p, photo: '' }))}
                className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-red-600 hover:text-red-700"
              >
                <Trash2 size={14} /> Delete Photo
              </button>
            )}
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-gray-900">Team</h1>
          <p className="text-gray-500 mt-1">Manage your team members</p>
        </div>
        <button onClick={startNew} className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 flex items-center gap-2">
          <Plus size={16} /> Add Member
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : members.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-100 p-16 text-center">
          <Users size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="font-semibold text-gray-900 mb-1">No team members yet</h3>
          <p className="text-sm text-gray-500">Add your first team member.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {members.map((m) => (
            <div key={m.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all">
              <div className="aspect-[3/4] overflow-hidden bg-gray-100">
                {m.photo && <img src={m.photo} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-gray-900">{m.name}</h3>
                <p className="text-sm text-accent-600">{m.role}</p>
                <p className="text-xs text-gray-500 mt-2">{m.transactions}+ transactions • {m.yearsOfExperience} yrs</p>
                <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                  <button onClick={() => startEdit(m)} className="flex-1 py-1.5 rounded-lg text-sm text-gray-700 hover:bg-gray-100 flex items-center justify-center gap-1" title="Edit">
                    <Edit2 size={13} /> Edit
                  </button>
                  <button onClick={() => handleDelete(m.id)} className="py-1.5 px-3 rounded-lg text-sm text-red-600 hover:bg-red-50 flex items-center justify-center gap-1" title="Delete">
                    <Trash2 size={13} /> Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
