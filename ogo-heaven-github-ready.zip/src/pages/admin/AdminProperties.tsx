import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Plus, Edit2, Trash2, ArrowLeft, Loader2, Save, Image as ImageIcon, X, Building2 } from 'lucide-react';
import { getProperties, saveProperty, deleteProperty, getProperty } from '../../lib/backend';
import AdminLayout from '../../components/admin/AdminLayout';
import MediaUploader from '../../components/admin/MediaUploader';
import { formatPrice } from '../../utils/currency';
import { isFirebaseConfigured } from '../../lib/firebase';

const emptyProperty = {
  title: '',
  address: '',
  city: '',
  state: '',
  zip: '',
  price: 0,
  type: 'Detached House',
  status: 'For Sale',
  beds: 3,
  baths: 2,
  sqft: 0,
  yearBuilt: new Date().getFullYear(),
  garage: 1,
  floors: 1,
  description: '',
  highlights: [] as string[],
  neighborhood: '',
  mlsNumber: '',
  listingAgent: '',
  listingDate: new Date().toISOString().split('T')[0],
  images: [] as string[],
  videos: [] as string[],
  coordinates: { lat: 6.4432, lng: 3.4327 },
  nearbySchools: [] as any[],
  nearbyAmenities: [] as any[],
  priceHistory: [] as any[],
};

export default function AdminProperties() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [highlightInput, setHighlightInput] = useState('');

  useEffect(() => {
    if (!id) {
      loadProperties();
    }
  }, [id]);

  useEffect(() => {
    if (id === 'new') {
      setEditing({ ...emptyProperty });
    } else if (id) {
      loadProperty(id);
    }
  }, [id]);

  const loadProperties = async () => {
    setLoading(true);
    try {
      const data = await getProperties();
      setProperties(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadProperty = async (propertyId: string) => {
    setLoading(true);
    try {
      const data = await getProperty(propertyId);
      if (data) {
        setEditing({
          ...emptyProperty,
          ...data,
          highlights: data.highlights || [],
          images: data.images || [],
          videos: data.videos || [],
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!isFirebaseConfigured) {
      alert('Firebase not configured. Cannot save.');
      return;
    }
    setSaving(true);
    try {
      const { id: propId, ...data } = editing;
      await saveProperty(data, propId === 'new' ? undefined : propId);
      navigate('/admin/properties');
    } catch (err) {
      console.error(err);
      alert('Error saving property');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (propertyId: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return;
    try {
      await deleteProperty(propertyId);
      await loadProperties();
    } catch (err) {
      console.error(err);
      alert('Error deleting property');
    }
  };

  const updateField = (field: string, value: any) => {
    setEditing((prev: any) => ({ ...prev, [field]: value }));
  };

  const addHighlight = () => {
    if (!highlightInput.trim()) return;
    updateField('highlights', [...(editing.highlights || []), highlightInput.trim()]);
    setHighlightInput('');
  };

  const removeHighlight = (idx: number) => {
    updateField('highlights', editing.highlights.filter((_: any, i: number) => i !== idx));
  };

  const updateArrayItem = (field: 'nearbySchools' | 'nearbyAmenities' | 'priceHistory', idx: number, patch: Record<string, any>) => {
    updateField(field, (editing[field] || []).map((item: any, i: number) => i === idx ? { ...item, ...patch } : item));
  };

  const removeArrayItem = (field: 'nearbySchools' | 'nearbyAmenities' | 'priceHistory', idx: number) => {
    updateField(field, (editing[field] || []).filter((_: any, i: number) => i !== idx));
  };

  const addSchool = () => {
    updateField('nearbySchools', [
      ...(editing.nearbySchools || []),
      { name: '', rating: 8, distance: '', type: 'primary' },
    ]);
  };

  const addAmenity = () => {
    updateField('nearbyAmenities', [
      ...(editing.nearbyAmenities || []),
      { name: '', type: '', distance: '' },
    ]);
  };

  const addPriceHistory = () => {
    updateField('priceHistory', [
      ...(editing.priceHistory || []),
      { date: new Date().toISOString().split('T')[0], price: editing.price || 0, event: 'Listed' },
    ]);
  };

  // Editor view
  if (editing) {
    return (
      <AdminLayout>
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div>
            <button
              onClick={() => navigate('/admin/properties')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900 font-medium text-sm transition-all active:scale-95 mb-2"
            >
              <ArrowLeft size={18} /> Back to Properties
            </button>
            <h1 className="font-serif text-2xl lg:text-3xl font-bold text-gray-900">
              {id === 'new' ? 'New Property' : 'Edit Property'}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {id && id !== 'new' && (
              <button
                onClick={async () => {
                  if (!confirm('Delete this property permanently?')) return;
                  try {
                    await deleteProperty(id);
                  } catch {
                    // Works in local mode too
                  }
                  navigate('/admin/properties');
                }}
                className="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 font-semibold text-sm hover:bg-red-50 flex items-center gap-2"
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 disabled:opacity-50 flex items-center gap-2"
            >
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
              {saving ? 'Saving...' : 'Save Property'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Basic Information</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Title</label>
                <input
                  type="text"
                  value={editing.title}
                  onChange={(e) => updateField('title', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                  placeholder="Luxury Villa in Banana Island"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Address</label>
                <input
                  type="text"
                  value={editing.address}
                  onChange={(e) => updateField('address', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                  placeholder="123 Example Street"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">City</label>
                <input
                  type="text"
                  value={editing.city}
                  onChange={(e) => updateField('city', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">State</label>
                <input
                  type="text"
                  value={editing.state}
                  onChange={(e) => updateField('state', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Neighborhood</label>
                <input
                  type="text"
                  value={editing.neighborhood}
                  onChange={(e) => updateField('neighborhood', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">MLS Number</label>
                <input
                  type="text"
                  value={editing.mlsNumber}
                  onChange={(e) => updateField('mlsNumber', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Price (₦)</label>
                <input
                  type="number"
                  value={editing.price}
                  onChange={(e) => updateField('price', Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                <select
                  value={editing.status}
                  onChange={(e) => updateField('status', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 bg-white"
                >
                  <option value="For Sale">For Sale</option>
                  <option value="For Rent">For Rent</option>
                  <option value="Sold">Sold</option>
                  <option value="Coming Soon">Coming Soon</option>
                </select>
              </div>

              {editing.status === 'For Rent' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Rental Period</label>
                    <select
                      value={editing.rentalPeriod || 'monthly'}
                      onChange={(e) => updateField('rentalPeriod', e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 bg-white"
                    >
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Rental Notes <span className="text-gray-400 font-normal">(optional)</span>
                    </label>
                    <input
                      type="text"
                      value={editing.rentalNotes || ''}
                      onChange={(e) => updateField('rentalNotes', e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                      placeholder="e.g., Minimum 6-month lease, furnished option available, service charge included"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Property Type</label>
                <select
                  value={editing.type}
                  onChange={(e) => updateField('type', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 bg-white"
                >
                  <option>Detached House</option>
                  <option>Duplex</option>
                  <option>Apartment</option>
                  <option>Townhouse</option>
                  <option>Land</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Listing Agent</label>
                <input
                  type="text"
                  value={editing.listingAgent}
                  onChange={(e) => updateField('listingAgent', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
                />
              </div>
            </div>
          </div>

          {/* Specs */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Specifications</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { label: 'Bedrooms', field: 'beds' },
                { label: 'Bathrooms', field: 'baths' },
                { label: 'Sq Ft', field: 'sqft' },
                { label: 'Year Built', field: 'yearBuilt' },
                { label: 'Garage', field: 'garage' },
                { label: 'Floors', field: 'floors' },
              ].map(({ label, field }) => (
                <div key={field}>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">{label}</label>
                  <input
                    type="number"
                    value={editing[field]}
                    onChange={(e) => updateField(field, Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Description</h2>
            <textarea
              rows={6}
              value={editing.description}
              onChange={(e) => updateField('description', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400 resize-none"
              placeholder="Describe the property in detail..."
            />
          </div>

          {/* Highlights */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Highlights</h2>
            <div className="flex flex-wrap gap-2 mb-3">
              {(editing.highlights || []).map((h: string, idx: number) => (
                <span key={idx} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-full text-sm text-gray-700">
                  {h}
                  <button onClick={() => removeHighlight(idx)} className="text-gray-400 hover:text-red-500">
                    <X size={14} />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={highlightInput}
                onChange={(e) => setHighlightInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addHighlight())}
                placeholder="Add a highlight (e.g., Panoramic ocean views)"
                className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-accent-400"
              />
              <button
                onClick={addHighlight}
                className="px-4 py-2.5 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-800"
              >
                Add
              </button>
            </div>
          </div>

          {/* Nearby Schools */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-semibold text-gray-900">Nearby Schools</h2>
                <p className="text-xs text-gray-500 mt-1">Add or delete schools shown on the property detail page.</p>
              </div>
              <button onClick={addSchool} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-800">
                <Plus size={14} /> Add School
              </button>
            </div>
            <div className="space-y-3">
              {(editing.nearbySchools || []).map((school: any, idx: number) => (
                <div key={idx} className="grid md:grid-cols-[1fr_120px_140px_120px_auto] gap-2 rounded-xl border border-gray-200 p-3">
                  <input value={school.name || ''} onChange={e => updateArrayItem('nearbySchools', idx, { name: e.target.value })} placeholder="School name" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input type="number" value={school.rating || 0} onChange={e => updateArrayItem('nearbySchools', idx, { rating: Number(e.target.value) })} placeholder="Rating" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input value={school.distance || ''} onChange={e => updateArrayItem('nearbySchools', idx, { distance: e.target.value })} placeholder="Distance" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <select value={school.type || 'primary'} onChange={e => updateArrayItem('nearbySchools', idx, { type: e.target.value })} className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400 bg-white">
                    <option value="primary">Primary</option>
                    <option value="secondary">Secondary</option>
                    <option value="university">University</option>
                  </select>
                  <button onClick={() => removeArrayItem('nearbySchools', idx)} className="p-2 rounded-lg text-red-500 hover:bg-red-50 justify-self-start">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {(editing.nearbySchools || []).length === 0 && <p className="text-sm text-gray-400 italic">No schools added yet.</p>}
            </div>
          </div>

          {/* Nearby Amenities */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-semibold text-gray-900">Nearby Amenities</h2>
                <p className="text-xs text-gray-500 mt-1">Add or delete amenities around this property.</p>
              </div>
              <button onClick={addAmenity} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-800">
                <Plus size={14} /> Add Amenity
              </button>
            </div>
            <div className="space-y-3">
              {(editing.nearbyAmenities || []).map((amenity: any, idx: number) => (
                <div key={idx} className="grid md:grid-cols-[1fr_160px_140px_auto] gap-2 rounded-xl border border-gray-200 p-3">
                  <input value={amenity.name || ''} onChange={e => updateArrayItem('nearbyAmenities', idx, { name: e.target.value })} placeholder="Amenity name" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input value={amenity.type || ''} onChange={e => updateArrayItem('nearbyAmenities', idx, { type: e.target.value })} placeholder="Type" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input value={amenity.distance || ''} onChange={e => updateArrayItem('nearbyAmenities', idx, { distance: e.target.value })} placeholder="Distance" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <button onClick={() => removeArrayItem('nearbyAmenities', idx)} className="p-2 rounded-lg text-red-500 hover:bg-red-50 justify-self-start">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {(editing.nearbyAmenities || []).length === 0 && <p className="text-sm text-gray-400 italic">No amenities added yet.</p>}
            </div>
          </div>

          {/* Price History */}
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-semibold text-gray-900">Price History</h2>
                <p className="text-xs text-gray-500 mt-1">Add or delete price events for this listing.</p>
              </div>
              <button onClick={addPriceHistory} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-800">
                <Plus size={14} /> Add Event
              </button>
            </div>
            <div className="space-y-3">
              {(editing.priceHistory || []).map((event: any, idx: number) => (
                <div key={idx} className="grid md:grid-cols-[160px_1fr_180px_auto] gap-2 rounded-xl border border-gray-200 p-3">
                  <input type="date" value={event.date || ''} onChange={e => updateArrayItem('priceHistory', idx, { date: e.target.value })} className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input value={event.event || ''} onChange={e => updateArrayItem('priceHistory', idx, { event: e.target.value })} placeholder="Event (Listed, Sold, Price Change)" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <input type="number" value={event.price || 0} onChange={e => updateArrayItem('priceHistory', idx, { price: Number(e.target.value) })} placeholder="Price" className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400" />
                  <button onClick={() => removeArrayItem('priceHistory', idx)} className="p-2 rounded-lg text-red-500 hover:bg-red-50 justify-self-start">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {(editing.priceHistory || []).length === 0 && <p className="text-sm text-gray-400 italic">No price history added yet.</p>}
            </div>
          </div>

          {/* Media */}
          <div>
            <h2 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <ImageIcon size={18} className="text-accent-500" />
              Media (Images & Videos)
            </h2>
            <MediaUploader
              images={editing.images || []}
              videos={editing.videos || []}
              onImagesChange={(imgs) => updateField('images', imgs)}
              onVideosChange={(vids) => updateField('videos', vids)}
              disabled={!isFirebaseConfigured}
            />
            {!isFirebaseConfigured && (
              <p className="text-xs text-amber-700 mt-2">
                ⚠️ File uploads require Firebase to be configured. You can still add images/videos by URL.
              </p>
            )}
          </div>
        </div>
      </AdminLayout>
    );
  }

  // List view
  return (
    <AdminLayout>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-gray-900">Properties</h1>
          <p className="text-gray-500 mt-1">Manage your property listings</p>
        </div>
        <Link
          to="/admin/properties/new"
          className="px-5 py-2.5 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 flex items-center gap-2"
        >
          <Plus size={16} />
          New Property
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent-500" />
        </div>
      ) : properties.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-100 p-16 text-center">
          <Building2 size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="font-semibold text-gray-900 mb-1">No properties yet</h3>
          <p className="text-sm text-gray-500 mb-4">Add your first property listing to get started.</p>
          <Link to="/admin/properties/new" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gray-900 text-white text-sm font-medium">
            <Plus size={16} /> Add Property
          </Link>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Property</th>
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Location</th>
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Price</th>
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Status</th>
                  <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Media</th>
                  <th className="text-right text-xs font-medium text-gray-500 uppercase tracking-wider px-6 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {properties.map((p: any) => (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {p.images?.[0] ? (
                          <img src={p.images[0]} alt="" className="w-12 h-12 rounded-lg object-cover" />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center">
                            <ImageIcon size={16} className="text-gray-400" />
                          </div>
                        )}
                        <div>
                          <div className="font-medium text-sm text-gray-900 line-clamp-1">{p.title || 'Untitled'}</div>
                          <div className="text-xs text-gray-500">{p.type}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{p.city}, {p.state}</div>
                      <div className="text-xs text-gray-500">{p.neighborhood}</div>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">{formatPrice(p.price)}</td>
                    <td className="px-6 py-4">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        p.status === 'For Sale' ? 'bg-emerald-50 text-emerald-700' :
                        p.status === 'For Rent' ? 'bg-indigo-50 text-indigo-700' :
                        p.status === 'Sold' ? 'bg-red-50 text-red-700' :
                        'bg-blue-50 text-blue-700'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {p.images?.length || 0} 📷 / {p.videos?.length || 0} 🎬
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          to={`/admin/properties/${p.id}`}
                          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                          title="Edit"
                        >
                          <Edit2 size={16} />
                        </Link>
                        <button
                          onClick={() => handleDelete(p.id)}
                          className="p-2 rounded-lg text-gray-500 hover:bg-red-50 hover:text-red-600"
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
