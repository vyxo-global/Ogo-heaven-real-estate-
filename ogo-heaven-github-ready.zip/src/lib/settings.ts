/**
 * Site Settings
 *
 * Defines the shape of all configurable site settings and their defaults.
 * Settings are persisted to Firestore (if Firebase configured) + localStorage cache.
 */

export interface CompanySettings {
  name: string;
  tagline: string;
  logoUrl: string;
  logoText: string;
  rcNumber: string;
  about: string;
}

export interface ContactSettings {
  phone: string;
  phoneDisplay: string;
  email: string;
  whatsapp: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  country: string;
  hoursWeekday: string;
  hoursWeekend: string;
}

export interface SocialSettings {
  facebook: string;
  instagram: string;
  twitter: string;
  linkedin: string;
  youtube: string;
  tiktok: string;
}

export interface ApiSettings {
  web3formsAccessKey: string;
}

export interface SeoSettings {
  metaDescription: string;
  keywords: string;
}

export interface SecuritySettings {
  /** Username required to log into admin (leave empty to allow open access) */
  adminUsername: string;
  /** Password required to log into admin (leave empty to allow open access) */
  adminPassword: string;
}

export interface DemoDataSettings {
  /** When true, demo/example records are hidden from the public site */
  hideDemoData: boolean;
}

export interface StatItem {
  id: string;
  value: string;
  label: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  linkLabel: string;
  linkHref: string;
  /** icon key, maps to a small set of built-in icons */
  icon: 'home' | 'trend' | 'building' | 'key' | 'handshake' | 'shield';
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  quote: string;
  avatar: string;
}

export interface HomepageSettings {
  heroBadge: string;
  heroTitle: string;
  heroTitleAccent: string;
  heroSubtitle: string;
  heroImage: string;
  primaryCtaLabel: string;
  primaryCtaHref: string;
  secondaryCtaLabel: string;
  secondaryCtaHref: string;
  stats: StatItem[];
  services: ServiceItem[];
  testimonials: TestimonialItem[];
  testimonialsHeading: string;
  testimonialsSubheading: string;
  ctaHeading: string;
  ctaSubheading: string;
}

export interface SiteSettings {
  company: CompanySettings;
  contact: ContactSettings;
  socials: SocialSettings;
  api: ApiSettings;
  seo: SeoSettings;
  security: SecuritySettings;
  demoData: DemoDataSettings;
  homepage: HomepageSettings;
  updatedAt?: string;
}

const uid = () => Math.random().toString(36).slice(2, 10);

export const DEFAULT_SETTINGS: SiteSettings = {
  company: {
    name: 'Ogo Heavens',
    tagline: 'Realtors Limited',
    logoUrl: '',
    logoText: 'O',
    rcNumber: 'RC 1234567',
    about: 'Boutique real estate services across Nigeria. Your trusted partner in finding exceptional properties that match your lifestyle and aspirations.',
  },
  contact: {
    phone: '+2348035243518',
    phoneDisplay: '+234 803 524 3518',
    email: 'info@ogoheavens.com',
    whatsapp: '2348035243518',
    addressLine1: '12 Adeola Odeku Street',
    addressLine2: '',
    city: 'Victoria Island',
    state: 'Lagos',
    country: 'Nigeria',
    hoursWeekday: 'Mon–Fri: 8am – 6pm',
    hoursWeekend: 'Sat: 10am – 4pm • Sun: By appointment',
  },
  socials: {
    facebook: '',
    instagram: '',
    twitter: '',
    linkedin: '',
    youtube: '',
    tiktok: '',
  },
  api: {
    web3formsAccessKey: '',
  },
  seo: {
    metaDescription: 'Ogo Heavens Realtors Limited — Premium Nigerian Real Estate. Find luxury homes, duplexes and apartments in Lagos and Abuja.',
    keywords: 'Nigeria real estate, Lagos properties, Abuja homes, Banana Island, Maitama, Lekki',
  },
  security: {
    adminUsername: '',
    adminPassword: '',
  },
  demoData: {
    hideDemoData: false,
  },
  homepage: {
    heroBadge: 'Trusted Nigerian Real Estate — Since 2010',
    heroTitle: 'Find Your',
    heroTitleAccent: 'Heaven on Earth.',
    heroSubtitle: 'Premium properties across Lagos, Abuja, and beyond. We connect discerning buyers with exceptional homes that match their lifestyle and aspirations.',
    heroImage: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1920',
    primaryCtaLabel: 'View Properties',
    primaryCtaHref: '/listings',
    secondaryCtaLabel: 'Speak With an Agent',
    secondaryCtaHref: '/contact',
    stats: [
      { id: uid(), value: '15+', label: 'Years in Business' },
      { id: uid(), value: '₦50B+', label: 'Properties Sold' },
      { id: uid(), value: '98%', label: 'Client Satisfaction' },
      { id: uid(), value: '350+', label: 'Happy Families' },
    ],
    services: [
      {
        id: uid(),
        title: 'Buy a Home',
        description: "From first-time buyers to seasoned investors, our agents guide you through every step with market intelligence and personalized service across Nigeria's premium locations.",
        linkLabel: 'Browse Listings',
        linkHref: '/listings',
        icon: 'home',
      },
      {
        id: uid(),
        title: 'Meet Our Team',
        description: 'Get to know the experienced agents behind our agency. Our team brings decades of combined experience in Nigerian real estate and a commitment to exceptional service.',
        linkLabel: 'About Us',
        linkHref: '/about',
        icon: 'building',
      },
    ],
    testimonials: [
      {
        id: uid(),
        name: 'Mr. & Mrs. Adekunle',
        role: 'Home Buyers',
        quote: "Chioma made our dream of owning a home on Banana Island a reality. Her knowledge of the market, patience, and negotiation skills were extraordinary.",
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
      },
      {
        id: uid(),
        name: 'Alhaji Bello',
        role: 'Property Investor',
        quote: "Adebayo's data-driven approach completely transformed how I think about real estate investing in Lagos. His market analysis is second to none.",
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100',
      },
      {
        id: uid(),
        name: 'The Okonkwo Family',
        role: 'Home Sellers',
        quote: 'Ibrahim sold our Maitama duplex in just 6 days, well above asking price. Professional, discreet, and genuinely caring.',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100',
      },
    ],
    testimonialsHeading: 'What our clients say',
    testimonialsSubheading: '93% of our business comes from referrals. Here\'s why.',
    ctaHeading: 'Ready to find your heaven?',
    ctaSubheading: "Let our expert team guide you home. Schedule a consultation today.",
  },
};

/**
 * Deep merge: overlay user settings onto defaults so new fields never break old data.
 */
export function mergeWithDefaults(partial: Partial<SiteSettings> | null | undefined): SiteSettings {
  if (!partial) return structuredClone(DEFAULT_SETTINGS);

  const merged = structuredClone(DEFAULT_SETTINGS) as SiteSettings;
  for (const group of ['company', 'contact', 'socials', 'api', 'seo', 'security', 'demoData', 'homepage'] as const) {
    const source = (partial as any)?.[group];
    if (source && typeof source === 'object') {
      if (Array.isArray(source)) continue;
      for (const key of Object.keys(source)) {
        if (source[key] !== undefined && source[key] !== null) {
          (merged[group] as any)[key] = source[key];
        }
      }
    }
  }
  if (partial.updatedAt) merged.updatedAt = partial.updatedAt;
  return merged;
}

export function getActiveSocials(socials: SocialSettings): Array<{ platform: keyof SocialSettings; url: string }> {
  const platforms: (keyof SocialSettings)[] = ['facebook', 'instagram', 'twitter', 'linkedin', 'youtube', 'tiktok'];
  return platforms
    .map(platform => ({ platform, url: socials[platform] || '' }))
    .filter(s => s.url.trim().length > 0);
}

export function buildWhatsAppUrl(settings: SiteSettings, message?: string) {
  const num = settings.contact.whatsapp.replace(/\D/g, '');
  const base = `https://wa.me/${num}`;
  if (!message) return base;
  return `${base}?text=${encodeURIComponent(message)}`;
}

export { uid };
