/**
 * Firebase Configuration
 * ======================
 *
 * SETUP INSTRUCTIONS:
 * 1. Go to https://console.firebase.google.com/
 * 2. Click "Add project" and follow the prompts
 * 3. In your project, go to "Project settings" (gear icon)
 * 4. Scroll to "Your apps" and click the web icon (</>)
 * 5. Register your app and copy the firebaseConfig
 * 6. Paste the values below
 *
 * ENABLE THESE SERVICES IN FIREBASE CONSOLE:
 * - Firestore Database (Start in test mode, then lock down with rules)
 * - Storage (Start in test mode)
 * - Authentication > Sign-in method > Email/Password (enable it)
 *
 * RECOMMENDED FIRESTORE RULES (paste in Firestore > Rules):
 * rules_version = '2';
 * service cloud.firestore {
 *   match /databases/{database}/documents {
 *     match /{document=**} {
 *       allow read: if true;
 *       allow write: if request.auth != null;
 *     }
 *   }
 * }
 *
 * RECOMMENDED STORAGE RULES:
 * rules_version = '2';
 * service firebase.storage {
 *   match /b/{bucket}/o {
 *     match /{allPaths=**} {
 *       allow read: if true;
 *       allow write: if request.auth != null && request.resource.size < 50 * 1024 * 1024;
 *     }
 *   }
 * }
 */

export const firebaseConfig = {
  apiKey: "AIzaSyAL_gZq5f7jERWrUBOEY6181Jy-rOmWcrM",
  authDomain: "ogo-heaven-real-estate.firebaseapp.com",
  projectId: "ogo-heaven-real-estate",
  storageBucket: "ogo-heaven-real-estate.firebasestorage.app",
  messagingSenderId: "476066540588",
  appId: "1:476066540588:web:260fcee1104260bafef589",
  measurementId: "G-BJY4YB7BBZ"
};

// Flag indicating whether Firebase is properly configured
export const isFirebaseConfigured =
  firebaseConfig.apiKey !== "REPLACE_WITH_YOUR_API_KEY" &&
  firebaseConfig.projectId !== "REPLACE_WITH_YOUR_PROJECT_ID";
