/**
 * Local admin authentication.
 *
 * This uses credentials stored in site settings (localStorage + Firestore).
 * No third-party auth service required.
 */

const SESSION_KEY = 'ogo_heavens_admin_session_v1';

export interface AdminSession {
  username: string;
  loggedAt: string;
}

export function getAdminSession(): AdminSession | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setAdminSession(session: AdminSession) {
  try {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {
    // ignore
  }
}

export function clearAdminSession() {
  try {
    sessionStorage.removeItem(SESSION_KEY);
  } catch {
    // ignore
  }
}

/**
 * Returns true if no password is set in settings — in that case, admin is open
 * and anyone visiting /admin can access without credentials.
 */
export function isAdminOpenAccess(adminUsername: string, adminPassword: string) {
  return !(adminUsername && adminUsername.trim().length > 0 && adminPassword && adminPassword.trim().length > 0);
}

export function verifyCredentials(
  inputUsername: string,
  inputPassword: string,
  adminUsername: string,
  adminPassword: string,
) {
  return inputUsername === adminUsername && inputPassword === adminPassword;
}
