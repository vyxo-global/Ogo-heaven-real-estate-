import { isFirebaseConfigured, firebaseConfig } from './firebase';

// Types
export interface Property {
  id: string;
  title: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  price: number;
  type: string;
  status: string;
  beds: number;
  baths: number;
  halfBaths?: number;
  sqft: number;
  lotSize?: number;
  yearBuilt: number;
  garage: number;
  floors: number;
  description: string;
  highlights: string[];
  neighborhood: string;
  mlsNumber: string;
  listingAgent: string;
  listingDate: string;
  images: string[];
  videos?: string[];
  virtualTour?: string;
  coordinates: { lat: number; lng: number };
  walkScore?: number;
  transitScore?: number;
  bikeScore?: number;
  nearbySchools: { name: string; rating: number; distance: string; type: string }[];
  nearbyAmenities: { name: string; type: string; distance: string }[];
  priceHistory: { date: string; price: number; event: string }[];
  propertyTax?: number;
  hoaFees?: number;
  createdAt: string;
  updatedAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
  slug: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  photo: string;
  bio: string;
  specialties: string[];
  phone: string;
  email: string;
  transactions: number;
  yearsOfExperience: number;
  createdAt: string;
  updatedAt: string;
}

export interface ContactInquiry {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  interest: string;
  message: string;
  status: 'new' | 'contacted' | 'closed';
  createdAt: string;
}

// Firebase imports (dynamic to avoid errors if not configured)
let db: any = null;
let auth: any = null;
let storage: any = null;

async function initializeFirebase() {
  if (!isFirebaseConfigured) return null;
  if (db) return { db, auth, storage };

  const { initializeApp } = await import('firebase/app');
  const { getFirestore } = await import('firebase/firestore');
  const { getAuth } = await import('firebase/auth');
  const { getStorage } = await import('firebase/storage');

  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
  storage = getStorage(app);

  return { db, auth, storage };
}

// ==================== AUTH ====================
export async function signIn(email: string, password: string) {
  const firebase = await initializeFirebase();
  if (!firebase?.auth) throw new Error('Firebase not configured');

  const { signInWithEmailAndPassword } = await import('firebase/auth');
  return signInWithEmailAndPassword(firebase.auth, email, password);
}

export async function signOut() {
  const firebase = await initializeFirebase();
  if (!firebase?.auth) throw new Error('Firebase not configured');

  const { signOut: firebaseSignOut } = await import('firebase/auth');
  return firebaseSignOut(firebase.auth);
}

export async function onAuthStateChanged(callback: (user: any) => void) {
  const firebase = await initializeFirebase();
  if (!firebase?.auth) {
    callback(null);
    return () => {};
  }

  const { onAuthStateChanged: firebaseOnAuthStateChanged } = await import('firebase/auth');
  return firebaseOnAuthStateChanged(firebase.auth, callback);
}

// ==================== PROPERTIES ====================
export async function getProperties(): Promise<Property[]> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    // Fallback to seed data
    const { properties } = await import('../data/properties');
    return properties as any;
  }

  const { collection, getDocs, query, orderBy } = await import('firebase/firestore');
  const q = query(collection(firebase.db, 'properties'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Property[];
}

export async function getProperty(id: string): Promise<Property | null> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    const { properties } = await import('../data/properties');
    return (properties.find(p => p.id === id) as any) || null;
  }

  const { doc, getDoc } = await import('firebase/firestore');
  const docRef = doc(firebase.db, 'properties', id);
  const snapshot = await getDoc(docRef);
  return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } as Property : null;
}

export async function saveProperty(property: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>, id?: string): Promise<string> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { collection, doc, setDoc } = await import('firebase/firestore');

  const now = new Date().toISOString();
  const propertyData = {
    ...property,
    updatedAt: now,
  };

  if (id) {
    await setDoc(doc(firebase.db, 'properties', id), propertyData, { merge: true });
    return id;
  } else {
    const newDoc = doc(collection(firebase.db, 'properties'));
    await setDoc(newDoc, { ...propertyData, createdAt: now });
    return newDoc.id;
  }
}

export async function deleteProperty(id: string): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { doc, deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(firebase.db, 'properties', id));
}

// ==================== MEDIA UPLOAD ====================
export async function uploadFile(file: File, folder: string = 'uploads'): Promise<string> {
  const firebase = await initializeFirebase();
  if (!firebase?.storage) throw new Error('Firebase not configured');

  const { ref, uploadBytes, getDownloadURL } = await import('firebase/storage');

  const timestamp = Date.now();
  const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
  const fileName = `${folder}/${timestamp}_${safeName}`;
  const storageRef = ref(firebase.storage, fileName);

  await uploadBytes(storageRef, file);
  return await getDownloadURL(storageRef);
}

export async function uploadFiles(files: File[], folder: string = 'uploads', onProgress?: (current: number, total: number) => void): Promise<string[]> {
  const urls: string[] = [];
  for (let i = 0; i < files.length; i++) {
    const url = await uploadFile(files[i], folder);
    urls.push(url);
    onProgress?.(i + 1, files.length);
  }
  return urls;
}

export async function deleteFile(url: string): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.storage) throw new Error('Firebase not configured');

  try {
    const { ref, deleteObject } = await import('firebase/storage');
    const fileRef = ref(firebase.storage, url);
    await deleteObject(fileRef);
  } catch (error) {
    console.error('Error deleting file:', error);
  }
}

// ==================== BLOG POSTS ====================
export async function getBlogPosts(): Promise<BlogPost[]> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    const { blogPosts } = await import('../data/properties');
    return blogPosts.map(p => ({ ...p, content: p.excerpt, createdAt: p.date, updatedAt: p.date })) as any;
  }

  const { collection, getDocs, query, orderBy } = await import('firebase/firestore');
  const q = query(collection(firebase.db, 'blogPosts'), orderBy('date', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as BlogPost[];
}

export async function saveBlogPost(post: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>, id?: string): Promise<string> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { collection, doc, setDoc } = await import('firebase/firestore');

  const now = new Date().toISOString();
  const postData = {
    ...post,
    updatedAt: now,
  };

  if (id) {
    await setDoc(doc(firebase.db, 'blogPosts', id), postData, { merge: true });
    return id;
  } else {
    const newDoc = doc(collection(firebase.db, 'blogPosts'));
    await setDoc(newDoc, { ...postData, createdAt: now });
    return newDoc.id;
  }
}

export async function deleteBlogPost(id: string): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { doc, deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(firebase.db, 'blogPosts', id));
}

// ==================== TEAM MEMBERS ====================
export async function getTeamMembers(): Promise<TeamMember[]> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    const { teamMembers } = await import('../data/properties');
    const now = new Date().toISOString();
    return teamMembers.map(m => ({ ...m, createdAt: now, updatedAt: now })) as any;
  }

  const { collection, getDocs, query, orderBy } = await import('firebase/firestore');
  const q = query(collection(firebase.db, 'teamMembers'), orderBy('name', 'asc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as TeamMember[];
}

export async function saveTeamMember(member: Omit<TeamMember, 'id' | 'createdAt' | 'updatedAt'>, id?: string): Promise<string> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { collection, doc, setDoc } = await import('firebase/firestore');

  const now = new Date().toISOString();
  const memberData = {
    ...member,
    updatedAt: now,
  };

  if (id) {
    await setDoc(doc(firebase.db, 'teamMembers', id), memberData, { merge: true });
    return id;
  } else {
    const newDoc = doc(collection(firebase.db, 'teamMembers'));
    await setDoc(newDoc, { ...memberData, createdAt: now });
    return newDoc.id;
  }
}

export async function deleteTeamMember(id: string): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { doc, deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(firebase.db, 'teamMembers', id));
}

// ==================== CONTACT INQUIRIES ====================
export async function submitInquiry(inquiry: Omit<ContactInquiry, 'id' | 'createdAt' | 'status'>): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    // In demo mode, just log
    console.log('Inquiry submitted (demo mode):', inquiry);
    return;
  }

  const { collection, addDoc } = await import('firebase/firestore');
  await addDoc(collection(firebase.db, 'inquiries'), {
    ...inquiry,
    status: 'new',
    createdAt: new Date().toISOString(),
  });
}

export async function getInquiries(): Promise<ContactInquiry[]> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) {
    // Return demo data
    return [
      {
        id: 'demo-1',
        firstName: 'Demo',
        lastName: 'User',
        email: 'demo@example.com',
        phone: '+234 800 000 0000',
        interest: 'Buying a home',
        message: 'Configure Firebase to see real inquiries.',
        status: 'new',
        createdAt: new Date().toISOString(),
      }
    ];
  }

  const { collection, getDocs, query, orderBy } = await import('firebase/firestore');
  const q = query(collection(firebase.db, 'inquiries'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as ContactInquiry[];
}

export async function updateInquiryStatus(id: string, status: ContactInquiry['status']): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { doc, updateDoc } = await import('firebase/firestore');
  await updateDoc(doc(firebase.db, 'inquiries', id), { status });
}

export async function deleteInquiry(id: string): Promise<void> {
  const firebase = await initializeFirebase();
  if (!firebase?.db) throw new Error('Firebase not configured');

  const { doc, deleteDoc } = await import('firebase/firestore');
  await deleteDoc(doc(firebase.db, 'inquiries', id));
}
