import { DEFAULT_SETTINGS, SiteSettings } from './settings';

const STORAGE_KEY = 'ogo_heavens_site_settings_v1';

/**
 * Read the most up-to-date settings from the local cache.
 * Falls back to defaults if nothing is cached yet.
 */
export function getCachedSettings(): SiteSettings {
  try {
    const cached = localStorage.getItem(STORAGE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      return {
        company: { ...DEFAULT_SETTINGS.company, ...(parsed.company || {}) },
        contact: { ...DEFAULT_SETTINGS.contact, ...(parsed.contact || {}) },
        socials: { ...DEFAULT_SETTINGS.socials, ...(parsed.socials || {}) },
        api: { ...DEFAULT_SETTINGS.api, ...(parsed.api || {}) },
        seo: { ...DEFAULT_SETTINGS.seo, ...(parsed.seo || {}) },
        security: { ...DEFAULT_SETTINGS.security, ...(parsed.security || {}) },
        demoData: { ...DEFAULT_SETTINGS.demoData, ...(parsed.demoData || {}) },
        homepage: { ...DEFAULT_SETTINGS.homepage, ...(parsed.homepage || {}) },
        updatedAt: parsed.updatedAt,
      };
    }
  } catch {
    // ignore
  }
  return DEFAULT_SETTINGS;
}

export interface LeadProperty {
  id: string;
  title: string;
  address: string;
  city: string;
  state: string;
  price: number;
  beds: number;
  baths: number;
  sqft: number;
  status: string;
  type: string;
}

export interface PropertyEmailInquiryInput {
  fullName: string;
  email: string;
  phone: string;
  message: string;
}

export function buildPropertyWhatsAppMessage(property: LeadProperty, settings: SiteSettings) {
  const fmt = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0,
  }).format(property.price);

  return [
    `Hello ${settings.company.name} ${settings.company.tagline},`,
    '',
    'I am interested in this property:',
    property.title,
    `${property.address}, ${property.city}, ${property.state}`,
    `Price: ${fmt}`,
    `Details: ${property.beds} beds • ${property.baths} baths • ${property.sqft.toLocaleString()} sqft • ${property.type}`,
    `Status: ${property.status}`,
    '',
    `Property ID: ${property.id}`,
    'Please share more details and next steps.',
  ].join('\n');
}

export function buildPropertyWhatsAppUrl(property: LeadProperty, settings?: SiteSettings) {
  const s = settings || getCachedSettings();
  const num = (s.contact.whatsapp || '').replace(/\D/g, '');
  const text = buildPropertyWhatsAppMessage(property, s);
  if (!num) return `https://wa.me/?text=${encodeURIComponent(text)}`;
  return `https://wa.me/${num}?text=${encodeURIComponent(text)}`;
}

export function isWeb3FormsConfigured(settings?: SiteSettings) {
  const s = settings || getCachedSettings();
  const key = (s.api.web3formsAccessKey || '').trim();
  return key.length > 0 && key !== 'REPLACE_WITH_WEB3FORMS_ACCESS_KEY';
}

export async function submitPropertyEmailInquiry(
  property: LeadProperty,
  payload: PropertyEmailInquiryInput,
  settings?: SiteSettings,
) {
  const s = settings || getCachedSettings();
  const key = (s.api.web3formsAccessKey || '').trim();

  if (!key || key === 'REPLACE_WITH_WEB3FORMS_ACCESS_KEY') {
    throw new Error('Web3Forms access key is not configured yet. Update it in Admin → Settings → API Keys.');
  }

  const fmt = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0,
  }).format(property.price);

  const response = await fetch('https://api.web3forms.com/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({
      access_key: key,
      subject: `Property Inquiry — ${property.title}`,
      from_name: `${s.company.name} ${s.company.tagline}`,
      replyto: payload.email,
      name: payload.fullName,
      email: payload.email,
      phone: payload.phone,
      message: payload.message,
      property_title: property.title,
      property_address: `${property.address}, ${property.city}, ${property.state}`,
      property_price: fmt,
      property_specs: `${property.beds} beds • ${property.baths} baths • ${property.sqft.toLocaleString()} sqft • ${property.type}`,
      property_status: property.status,
      property_id: property.id,
    }),
  });

  const result = await response.json();
  if (!result.success) {
    throw new Error(result.message || 'Unable to send inquiry right now.');
  }
  return result;
}
