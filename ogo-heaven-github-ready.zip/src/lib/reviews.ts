import { isFirebaseConfigured, firebaseConfig } from './firebase';

const LOCAL_REVIEWS_KEY = 'ogo_heavens_reviews_v1';
const LOCAL_REVIEWS_EVENT = 'ogo_heavens_reviews_updated';

export type ReviewStatus = 'pending' | 'approved' | 'rejected';

export interface Review {
  id: string;
  name: string;
  email: string;
  phone?: string;
  rating: number;
  message: string;
  status: ReviewStatus;
  createdAt: string;
  approvedAt?: string;
}

export interface ReviewSummary {
  totalApproved: number;
  averageRating: number;
}

function localId() {
  return `review_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function readLocalReviews(): Review[] {
  try {
    const raw = localStorage.getItem(LOCAL_REVIEWS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeLocalReviews(reviews: Review[]) {
  try {
    localStorage.setItem(LOCAL_REVIEWS_KEY, JSON.stringify(reviews));
    window.dispatchEvent(new Event(LOCAL_REVIEWS_EVENT));
  } catch {
    // ignore local persistence failures
  }
}

function summarize(reviews: Review[]): ReviewSummary {
  const approved = reviews.filter(r => r.status === 'approved');
  const total = approved.length;
  const average = total === 0
    ? 0
    : approved.reduce((sum, review) => sum + Number(review.rating || 0), 0) / total;

  return {
    totalApproved: total,
    averageRating: Math.round(average * 10) / 10,
  };
}

async function getFirebase() {
  if (!isFirebaseConfigured) return null;

  const { initializeApp, getApps } = await import('firebase/app');
  const { getFirestore } = await import('firebase/firestore');

  const app = getApps()[0] || initializeApp(firebaseConfig);
  const db = getFirestore(app);
  return { db };
}

export async function submitReview(input: Omit<Review, 'id' | 'status' | 'createdAt' | 'approvedAt'>) {
  const cleanRating = Math.max(1, Math.min(5, Number(input.rating)));
  const payload = {
    ...input,
    rating: cleanRating,
    status: 'pending' as ReviewStatus,
    createdAt: new Date().toISOString(),
  };

  const firebase = await getFirebase();
  if (firebase?.db) {
    const { collection, addDoc } = await import('firebase/firestore');
    await addDoc(collection(firebase.db, 'reviews'), payload);
    return;
  }

  const reviews = readLocalReviews();
  writeLocalReviews([{ id: localId(), ...payload }, ...reviews]);
}

export async function updateReviewStatus(id: string, status: ReviewStatus) {
  const firebase = await getFirebase();
  const patch = {
    status,
    approvedAt: status === 'approved' ? new Date().toISOString() : undefined,
  };

  if (firebase?.db) {
    const { doc, updateDoc } = await import('firebase/firestore');
    await updateDoc(doc(firebase.db, 'reviews', id), patch);
    return;
  }

  const reviews = readLocalReviews().map(review =>
    review.id === id ? { ...review, ...patch } : review,
  );
  writeLocalReviews(reviews);
}

export async function deleteReview(id: string) {
  const firebase = await getFirebase();
  if (firebase?.db) {
    const { doc, deleteDoc } = await import('firebase/firestore');
    await deleteDoc(doc(firebase.db, 'reviews', id));
    return;
  }

  writeLocalReviews(readLocalReviews().filter(review => review.id !== id));
}

export async function getAllReviews(): Promise<Review[]> {
  const firebase = await getFirebase();
  if (firebase?.db) {
    const { collection, getDocs, query, orderBy } = await import('firebase/firestore');
    const q = query(collection(firebase.db, 'reviews'), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Review[];
  }

  return readLocalReviews();
}

export async function subscribeAllReviews(callback: (reviews: Review[], summary: ReviewSummary) => void) {
  const firebase = await getFirebase();
  if (firebase?.db) {
    const { collection, onSnapshot, query, orderBy } = await import('firebase/firestore');
    const q = query(collection(firebase.db, 'reviews'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, snapshot => {
      const reviews = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Review[];
      callback(reviews, summarize(reviews));
    });
  }

  const emit = () => {
    const reviews = readLocalReviews();
    callback(reviews, summarize(reviews));
  };
  emit();
  window.addEventListener(LOCAL_REVIEWS_EVENT, emit);
  return () => window.removeEventListener(LOCAL_REVIEWS_EVENT, emit);
}

export async function subscribeApprovedReviews(callback: (reviews: Review[], summary: ReviewSummary) => void) {
  const unsubscribe = await subscribeAllReviews((reviews) => {
    const approved = reviews.filter(review => review.status === 'approved');
    callback(approved, summarize(approved));
  });
  return unsubscribe;
}
