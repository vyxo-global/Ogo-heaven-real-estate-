// Centralized currency formatting utility
export const formatPrice = (price: number) =>
  new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0,
  }).format(price);

// Shorter format (e.g., ₦1.2B, ₦450M)
export const formatPriceShort = (price: number) => {
  if (price >= 1_000_000_000) {
    return `₦${(price / 1_000_000_000).toFixed(2)}B`;
  }
  if (price >= 1_000_000) {
    return `₦${(price / 1_000_000).toFixed(0)}M`;
  }
  return formatPrice(price);
};
