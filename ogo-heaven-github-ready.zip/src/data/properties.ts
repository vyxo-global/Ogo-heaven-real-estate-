export interface Property {
  id: string;
  title: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  price: number;
  type: 'Detached House' | 'Duplex' | 'Apartment' | 'Townhouse' | 'Land';
  status: 'For Sale' | 'For Rent' | 'Sold' | 'Coming Soon';
  rentalPeriod?: 'weekly' | 'monthly' | 'yearly';
  rentalNotes?: string;
  beds: number;
  baths: number;
  halfBaths?: number;
  sqft: number;
  lotSize?: number;
  yearBuilt: number;
  garage: number;
  floors: number;
  description: string;
  highlights: string[];
  neighborhood: string;
  mlsNumber: string;
  listingAgent: string;
  listingDate: string;
  images: string[];
  virtualTour?: string;
  coordinates: { lat: number; lng: number };
  walkScore?: number;
  transitScore?: number;
  bikeScore?: number;
  nearbySchools: { name: string; rating: number; distance: string; type: 'primary' | 'secondary' | 'university' }[];
  nearbyAmenities: { name: string; type: string; distance: string }[];
  priceHistory: { date: string; price: number; event: string }[];
  propertyTax?: number;
  hoaFees?: number;
}

export const properties: Property[] = [
  {
    id: 'prop-1',
    title: 'Luxury Waterfront Villa with Panoramic Lagoon Views',
    address: '42 Banana Island Road',
    city: 'Lagos',
    state: 'Lagos',
    zip: '100001',
    price: 850000000,
    type: 'Detached House',
    status: 'For Sale',
    beds: 5,
    baths: 6,
    halfBaths: 2,
    sqft: 4500,
    lotSize: 0.45,
    yearBuilt: 2020,
    garage: 3,
    floors: 3,
    description: 'Experience unparalleled luxury on Banana Island, Lagos\'s most prestigious address. This architectural masterpiece offers breathtaking views of the Lagos Lagoon from every room. Floor-to-ceiling windows flood the open-plan living spaces with natural light, showcasing Italian marble floors, custom woodwork, and a gourmet kitchen with premium appliances. The primary suite features a spa-like bathroom with a soaking tub overlooking the water. Step outside to your private infinity pool, outdoor entertainment area, and direct water access.',
    highlights: ['Panoramic lagoon views', 'Infinity pool with deck', 'Private water access', 'Smart home automation', '3-car garage', 'Wine cellar'],
    neighborhood: 'Banana Island',
    mlsNumber: 'LAG-24-001234',
    listingAgent: 'Chioma Okafor',
    listingDate: '2025-11-15',
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1200',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200',
      'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=1200',
      'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=1200'
    ],
    virtualTour: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    coordinates: { lat: 6.4432, lng: 3.4327 },
    walkScore: 75,
    transitScore: 60,
    bikeScore: 45,
    nearbySchools: [
      { name: 'Corona School Ikoyi', rating: 9, distance: '0.8 km', type: 'primary' },
      { name: 'Lagoon School', rating: 8, distance: '1.2 km', type: 'secondary' }
    ],
    nearbyAmenities: [
      { name: 'Ikoyi Golf Club', type: 'Recreation', distance: '0.5 km' },
      { name: 'Shoprite Ikoyi', type: 'Shopping', distance: '1.0 km' },
      { name: 'Mega Chicken', type: 'Restaurant', distance: '0.7 km' }
    ],
    priceHistory: [
      { date: '2025-11-15', price: 850000000, event: 'Listed' },
      { date: '2022-08-10', price: 720000000, event: 'Sold' }
    ],
    propertyTax: 2500000
  },
  {
    id: 'prop-2',
    title: 'Elegant Executive Duplex in Maitama',
    address: '14 Adetokunbo Ademola Crescent',
    city: 'Abuja',
    state: 'FCT',
    zip: '900211',
    price: 420000000,
    type: 'Duplex',
    status: 'For Sale',
    beds: 5,
    baths: 5,
    sqft: 3800,
    lotSize: 0.3,
    yearBuilt: 2022,
    garage: 2,
    floors: 2,
    description: 'A rare opportunity to own a piece of Maitama luxury. This meticulously designed executive duplex sits on a quiet, tree-lined street in Abuja\'s most prestigious neighborhood. Features include soaring 4-meter ceilings, hand-carved wooden details, marble finishes throughout, and a fully fitted modern kitchen with premium appliances. The master suite spans the entire upper wing with walk-in closets and a private balcony. Outside, a manicured garden with gazebo and children\'s play area awaits.',
    highlights: ['4-meter ceilings', 'Marble finishes', 'Fully fitted kitchen', 'Landscaped garden', 'Private balcony', 'CCTV security'],
    neighborhood: 'Maitama',
    mlsNumber: 'ABJ-24-002341',
    listingAgent: 'Ibrahim Musa',
    listingDate: '2025-11-20',
    images: [
      'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=1200',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200'
    ],
    coordinates: { lat: 9.0820, lng: 7.4909 },
    walkScore: 68,
    transitScore: 55,
    bikeScore: 40,
    nearbySchools: [
      { name: 'Loyola Jesuit College', rating: 9, distance: '1.5 km', type: 'secondary' },
      { name: 'Nizamiye School', rating: 9, distance: '2.0 km', type: 'primary' }
    ],
    nearbyAmenities: [
      { name: 'Jabi Lake Mall', type: 'Shopping', distance: '3.0 km' },
      { name: 'Transcorp Hilton', type: 'Hotel', distance: '1.2 km' },
      { name: 'Nkoyo Restaurant', type: 'Restaurant', distance: '0.8 km' }
    ],
    priceHistory: [
      { date: '2025-11-20', price: 420000000, event: 'Listed' }
    ],
    propertyTax: 1200000
  },
  {
    id: 'prop-3',
    title: 'Beachfront Penthouse on Victoria Island',
    address: '1 Bishop Aboyade Cole Street, Penthouse 15',
    city: 'Lagos',
    state: 'Lagos',
    zip: '101241',
    price: 1250000000,
    type: 'Apartment',
    status: 'For Sale',
    beds: 4,
    baths: 5,
    halfBaths: 2,
    sqft: 5200,
    yearBuilt: 2023,
    garage: 2,
    floors: 1,
    description: 'The crown jewel of Victoria Island\'s skyline. This 5,200 sq ft penthouse offers 360-degree views of the Atlantic Ocean, Lagos Lagoon, and the glittering city below. Retractable glass walls open the great room to a wrap-around terrace with private pool and outdoor kitchen. Interior finishes include Bulthaup cabinetry, Calacatta marble, and smart home automation throughout. Building amenities include 24-hour concierge, rooftop lounge, fitness center, and private cinema.',
    highlights: ['360° ocean & city views', 'Private rooftop pool', 'Wrap-around terrace', '24-hour concierge', 'Private cinema', 'Helipad access'],
    neighborhood: 'Victoria Island',
    mlsNumber: 'LAG-24-003456',
    listingAgent: 'Chioma Okafor',
    listingDate: '2025-10-01',
    images: [
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=1200',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200',
      'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1200'
    ],
    coordinates: { lat: 6.4331, lng: 3.4187 },
    walkScore: 85,
    transitScore: 70,
    bikeScore: 50,
    nearbySchools: [
      { name: 'British International School', rating: 10, distance: '1.5 km', type: 'primary' },
      { name: 'Greensprings School', rating: 9, distance: '2.0 km', type: 'secondary' }
    ],
    nearbyAmenities: [
      { name: 'Eko Hotel & Suites', type: 'Hotel', distance: '0.3 km' },
      { name: 'The Place Restaurant', type: 'Restaurant', distance: '0.5 km' },
      { name: 'Landmark Beach', type: 'Recreation', distance: '1.0 km' }
    ],
    priceHistory: [
      { date: '2025-10-01', price: 1250000000, event: 'Listed' }
    ],
    propertyTax: 3500000,
    hoaFees: 150000
  },
  {
    id: 'prop-4',
    title: 'Charming Family Home in Lekki Phase 1',
    address: '23 Admiralty Way',
    city: 'Lagos',
    state: 'Lagos',
    zip: '105102',
    price: 185000000,
    type: 'Detached House',
    status: 'For Sale',
    beds: 4,
    baths: 4,
    sqft: 2400,
    lotSize: 0.18,
    yearBuilt: 2019,
    garage: 2,
    floors: 2,
    description: 'A beautifully finished family home in the heart of Lekki Phase 1. This thoughtfully designed property features an open-plan living area with high ceilings, a fully fitted kitchen, spacious bedrooms with en-suite bathrooms, and a private backyard perfect for entertaining. Located on a quiet street within walking distance of schools, shopping centers, and restaurants. The property includes 24-hour power supply via inverter and generator backup, modern security systems, and tasteful finishes throughout.',
    highlights: ['Fully fitted kitchen', '24-hour power supply', 'Modern security system', 'Private backyard', 'En-suite bedrooms', 'Walking distance to amenities'],
    neighborhood: 'Lekki Phase 1',
    mlsNumber: 'LAG-24-004567',
    listingAgent: 'Adebayo Johnson',
    listingDate: '2025-11-28',
    images: [
      'https://images.unsplash.com/photo-1605146769289-440113cc3d00?w=1200',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200'
    ],
    coordinates: { lat: 6.4355, lng: 3.4539 },
    walkScore: 78,
    transitScore: 65,
    bikeScore: 55,
    nearbySchools: [
      { name: 'Lekki British School', rating: 9, distance: '0.5 km', type: 'primary' },
      { name: 'Atlantic Hall School', rating: 8, distance: '2.0 km', type: 'secondary' }
    ],
    nearbyAmenities: [
      { name: 'Lekki Conservation Centre', type: 'Recreation', distance: '1.5 km' },
      { name: 'Palms Shopping Mall', type: 'Shopping', distance: '1.0 km' },
      { name: 'Cactus Restaurant', type: 'Restaurant', distance: '0.3 km' }
    ],
    priceHistory: [
      { date: '2025-11-28', price: 185000000, event: 'Listed' }
    ],
    propertyTax: 550000
  },
  {
    id: 'prop-5',
    title: 'Modern Smart Apartment in Ikeja GRA',
    address: '8 Mobolaji Bank Anthony Way, Unit 12B',
    city: 'Lagos',
    state: 'Lagos',
    zip: '100282',
    price: 95000000,
    type: 'Apartment',
    status: 'For Sale',
    beds: 3,
    baths: 3,
    halfBaths: 1,
    sqft: 1800,
    yearBuilt: 2024,
    garage: 1,
    floors: 1,
    description: 'A brand-new smart apartment in the heart of Ikeja GRA, Lagos\'s most sought-after mainland neighborhood. This 3-bedroom apartment features modern finishes, floor-to-ceiling windows, a fully fitted kitchen, and integrated smart home technology. The master suite includes a walk-in closet and en-suite bathroom with premium fittings. Building amenities include 24-hour power, swimming pool, gym, and secured parking. Perfect for young professionals and small families.',
    highlights: ['Smart home technology', 'Swimming pool', 'Fully fitted gym', '24-hour power', 'Secured parking', 'Modern finishes'],
    neighborhood: 'Ikeja GRA',
    mlsNumber: 'LAG-24-005678',
    listingAgent: 'Oluwaseun Adeyemi',
    listingDate: '2025-12-02',
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200'
    ],
    coordinates: { lat: 6.5954, lng: 3.3489 },
    walkScore: 82,
    transitScore: 75,
    bikeScore: 60,
    nearbySchools: [
      { name: 'Lagoon Schools', rating: 8, distance: '1.0 km', type: 'primary' },
      { name: 'Ansar-Ud-Deen Grammar', rating: 7, distance: '1.5 km', type: 'secondary' }
    ],
    nearbyAmenities: [
      { name: 'Ikeja City Mall', type: 'Shopping', distance: '0.5 km' },
      { name: 'Mr Bigg\'s', type: 'Restaurant', distance: '0.3 km' },
      { name: 'Johnson Jakande Park', type: 'Recreation', distance: '0.8 km' }
    ],
    priceHistory: [
      { date: '2025-12-02', price: 95000000, event: 'Listed' }
    ],
    propertyTax: 280000,
    hoaFees: 50000
  },
  {
    id: 'prop-6',
    title: 'Stately Asokoro Mansion with Hill Views',
    address: '5 Nelson Mandela Street',
    city: 'Abuja',
    state: 'FCT',
    zip: '900271',
    price: 680000000,
    type: 'Detached House',
    status: 'Sold',
    beds: 6,
    baths: 7,
    sqft: 5800,
    lotSize: 0.6,
    yearBuilt: 2021,
    garage: 4,
    floors: 3,
    description: 'Commanding presence in Asokoro, Abuja\'s most exclusive enclave. This 6-bedroom mansion sits on a hilltop with sweeping views of the Aso Rock and the city. Every detail speaks of refined luxury: from the grand double-height foyer and marble stairway to the library with built-in shelving, wine cellar, and private cinema. The primary suite occupies its own wing with a spa bathroom, dressing rooms, and private terrace. Outside, a resort-style pool, tennis court, and staff quarters complete the estate.',
    highlights: ['Hilltop location', 'Private cinema', 'Wine cellar', 'Tennis court', 'Staff quarters', 'Resort-style pool'],
    neighborhood: 'Asokoro',
    mlsNumber: 'ABJ-24-006789',
    listingAgent: 'Ibrahim Musa',
    listingDate: '2025-11-10',
    images: [
      'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1200',
      'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=1200'
    ],
    coordinates: { lat: 9.0539, lng: 7.5188 },
    walkScore: 55,
    transitScore: 45,
    bikeScore: 35,
    nearbySchools: [
      { name: 'Turkish International School', rating: 9, distance: '2.0 km', type: 'primary' },
      { name: 'Regina Pacis College', rating: 9, distance: '3.5 km', type: 'secondary' }
    ],
    nearbyAmenities: [
      { name: 'Dunes Center', type: 'Shopping', distance: '1.5 km' },
      { name: 'Sheraton Hotel', type: 'Hotel', distance: '2.0 km' },
      { name: 'Asokoro Park', type: 'Recreation', distance: '0.5 km' }
    ],
    priceHistory: [
      { date: '2025-11-25', price: 680000000, event: 'Sold' },
      { date: '2025-11-10', price: 680000000, event: 'Listed' }
    ],
    propertyTax: 2000000
  }
];

export const teamMembers = [
  {
    id: 'tm-1',
    name: 'Chioma Okafor',
    role: 'Founder & Principal Agent',
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400',
    bio: 'With over 15 years of experience in Nigerian real estate, Chioma has closed over ₦50 billion in transactions across Lagos and Abuja. Her deep market knowledge, negotiation expertise, and commitment to client success have earned her recognition as one of Nigeria\'s most trusted luxury real estate agents.',
    specialties: ['Luxury Residential', 'Investment Properties', 'Commercial'],
    phone: '+234 802 555 0121',
    email: 'chioma@ogoheavens.com',
    transactions: 280,
    yearsOfExperience: 15
  },
  {
    id: 'tm-2',
    name: 'Ibrahim Musa',
    role: 'Senior Agent — Abuja Market',
    photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400',
    bio: 'A native of Abuja with over a decade of experience in the FCT property market. Ibrahim specializes in high-value residential and diplomatic properties in Maitama, Asokoro, and Guzape. His network and discretion make him the go-to agent for Nigeria\'s most discerning buyers and sellers.',
    specialties: ['Diplomatic Quarters', 'Executive Homes', 'Land Acquisition'],
    phone: '+234 803 555 0122',
    email: 'ibrahim@ogoheavens.com',
    transactions: 195,
    yearsOfExperience: 12
  },
  {
    id: 'tm-3',
    name: 'Adebayo Johnson',
    role: 'Senior Agent — Lagos Mainland',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    bio: 'Adebayo brings data-driven insights to Lagos\'s rapidly growing mainland property market. With 10 years in real estate and a background in urban planning, he helps clients identify emerging opportunities in Ikeja, Surulere, and Yaba. His approachable style and market mastery have built him a loyal following.',
    specialties: ['Mid-Market Homes', 'Investment Analysis', 'First-Time Buyers'],
    phone: '+234 805 555 0123',
    email: 'adebayo@ogoheavens.com',
    transactions: 220,
    yearsOfExperience: 10
  },
  {
    id: 'tm-4',
    name: 'Oluwaseun Adeyemi',
    role: 'Agent — Lekki & VI Specialist',
    photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400',
    bio: 'Oluwaseun is the definitive expert on Lekki and Victoria Island real estate. With 8 years specializing in these high-growth corridors, she provides unmatched insights into new developments, off-plan opportunities, and rental yields. Her creative marketing strategies consistently deliver results for sellers.',
    specialties: ['New Developments', 'Off-Plan Properties', 'Rental Market'],
    phone: '+234 806 555 0124',
    email: 'seun@ogoheavens.com',
    transactions: 165,
    yearsOfExperience: 8
  }
];

export const testimonials = [
  {
    id: 'test-1',
    name: 'Mr. & Mrs. Adekunle',
    role: 'Home Buyers',
    quote: 'Chioma made our dream of owning a home on Banana Island a reality. Her knowledge of the market, patience, and negotiation skills were extraordinary. We couldn\'t be happier with our new waterfront villa.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100'
  },
  {
    id: 'test-2',
    name: 'Alhaji Bello',
    role: 'Property Investor',
    quote: 'Adebayo\'s data-driven approach completely transformed how I think about real estate investing in Lagos. He identified an off-plan opportunity in Ikeja that has already appreciated 40%. His market analysis is second to none.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100'
  },
  {
    id: 'test-3',
    name: 'The Okonkwo Family',
    role: 'Home Sellers',
    quote: 'Ibrahim sold our Maitama duplex in just 6 days, well above asking price. His marketing strategy and network of qualified buyers made all the difference. Professional, discreet, and genuinely caring.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100'
  }
];

export const blogPosts = [
  {
    id: 'blog-1',
    title: '2026 Nigerian Real Estate Market Outlook: What Buyers & Sellers Need to Know',
    excerpt: 'With the Naira stabilizing and infrastructure investments accelerating, Nigeria\'s property market is entering a new chapter. Here\'s our comprehensive analysis.',
    category: 'Market Update',
    date: '2025-12-28',
    readTime: '8 min read',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600',
    slug: '2026-market-outlook'
  },
  {
    id: 'blog-2',
    title: 'First-Time Home Buyer Guide: From C of O to Keys',
    excerpt: 'Navigating property ownership in Nigeria can be complex. Our step-by-step guide covers everything from Certificate of Occupancy to final handover.',
    category: 'Buying',
    date: '2025-12-15',
    readTime: '12 min read',
    image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600',
    slug: 'first-time-buyer-guide'
  },
  {
    id: 'blog-3',
    title: 'Spotlight: Why Lekki Is Nigeria\'s Fastest-Growing Real Estate Corridor',
    excerpt: 'From the Lekki-Epe Expressway to the new Deep Sea Port, discover what\'s driving property values in this dynamic Lagos neighborhood.',
    category: 'Neighborhoods',
    date: '2025-12-08',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=600',
    slug: 'lekki-neighborhood-spotlight'
  },
  {
    id: 'blog-4',
    title: 'How to Stage Your Nigerian Home for a Quick Sale at Top Dollar',
    excerpt: 'Professional staging can increase your sale price by up to 10%. Learn techniques that work specifically for Nigerian buyers and properties.',
    category: 'Selling',
    date: '2025-12-01',
    readTime: '7 min read',
    image: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=600',
    slug: 'home-staging-tips'
  },
  {
    id: 'blog-5',
    title: 'Understanding Nigerian Land Titles: Governor\'s Consent, C of O, and More',
    excerpt: 'Land titles in Nigeria can be confusing. We break down the key documents every property buyer must understand before signing.',
    category: 'Resources',
    date: '2025-11-20',
    readTime: '10 min read',
    image: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600',
    slug: 'nigerian-land-titles'
  },
  {
    id: 'blog-6',
    title: 'Investment Returns: Lagos vs Abuja — Where Should You Put Your Money?',
    excerpt: 'We analyze rental yields, capital appreciation, and liquidity across Nigeria\'s two biggest property markets to help you make informed investment decisions.',
    category: 'Investment',
    date: '2025-11-12',
    readTime: '9 min read',
    image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600',
    slug: 'lagos-vs-abuja-investment'
  }
];
