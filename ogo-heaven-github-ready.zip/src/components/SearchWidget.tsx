import { useState } from 'react';
import { Search, MapPin, Wallet, Home } from 'lucide-react';
import { cn } from '../utils/cn';

interface SearchWidgetProps {
  variant?: 'hero' | 'inline';
  onSearch?: (filters: { location: string; priceMin: string; priceMax: string; type: string }) => void;
}

export default function SearchWidget({ variant = 'inline', onSearch }: SearchWidgetProps) {
  const [location, setLocation] = useState('');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [type, setType] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.({ location, priceMin, priceMax, type });
  };

  const isHero = variant === 'hero';

  return (
    <form
      onSubmit={handleSubmit}
      className={cn(
        'w-full',
        isHero
          ? 'bg-white/10 backdrop-blur-xl rounded-2xl p-3 sm:p-4 border border-white/20 shadow-2xl'
          : 'bg-white rounded-xl p-3 border border-gray-200 shadow-lg shadow-gray-200/50'
      )}
    >
      <div className="flex flex-col sm:flex-row gap-2 sm:gap-0">
        {/* Location */}
        <div className="flex-1 relative">
          <MapPin size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isHero ? 'text-white/60' : 'text-gray-400')} />
          <input
            type="text"
            placeholder="City, neighborhood, or ZIP"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className={cn(
              'w-full pl-9 pr-3 py-3 rounded-xl sm:rounded-r-none text-sm outline-none border transition-colors',
              isHero
                ? 'bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 sm:border-r-0'
                : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-gray-300 sm:border-r-0'
            )}
          />
        </div>

        {/* Price Range */}
        <div className="flex sm:flex-1 gap-2 sm:gap-0">
          <div className="flex-1 relative">
            <Wallet size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isHero ? 'text-white/60' : 'text-gray-400')} />
            <input
              type="text"
              placeholder="Min price (₦)"
              value={priceMin}
              onChange={(e) => setPriceMin(e.target.value)}
              className={cn(
                'w-full pl-9 pr-2 py-3 sm:rounded-none text-sm outline-none border transition-colors',
                isHero
                  ? 'bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 sm:border-r-0'
                  : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-gray-300 sm:border-r-0'
              )}
            />
          </div>
          <div className="flex-1 relative">
            <Wallet size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2', isHero ? 'text-white/60' : 'text-gray-400')} />
            <input
              type="text"
              placeholder="Max price (₦)"
              value={priceMax}
              onChange={(e) => setPriceMax(e.target.value)}
              className={cn(
                'w-full pl-9 pr-3 py-3 sm:rounded-none text-sm outline-none border transition-colors',
                isHero
                  ? 'bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40'
                  : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-gray-300'
              )}
            />
          </div>
        </div>

        {/* Property Type */}
        <div className="sm:flex-1 relative">
          <Home size={16} className={cn('absolute left-3 top-1/2 -translate-y-1/2 z-10', isHero ? 'text-white/60' : 'text-gray-400')} />
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className={cn(
              'w-full pl-9 pr-3 py-3 sm:rounded-l-none rounded-xl text-sm outline-none border appearance-none cursor-pointer transition-colors',
              isHero
                ? 'bg-white/10 border-white/20 text-white focus:border-white/40 sm:border-r-0'
                : 'bg-gray-50 border-gray-200 text-gray-900 focus:border-gray-300 sm:border-r-0',
              isHero ? '[&>option]:text-gray-900' : ''
            )}
          >
            <option value="">All Types</option>
            <option value="detached-house">Detached House</option>
            <option value="duplex">Duplex</option>
            <option value="apartment">Apartment</option>
            <option value="townhouse">Townhouse</option>
            <option value="land">Land</option>
          </select>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="px-6 py-3 rounded-xl sm:rounded-l-none bg-accent-500 hover:bg-accent-600 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2 shrink-0"
        >
          <Search size={16} />
          <span className="hidden sm:inline">Search</span>
        </button>
      </div>
    </form>
  );
}
