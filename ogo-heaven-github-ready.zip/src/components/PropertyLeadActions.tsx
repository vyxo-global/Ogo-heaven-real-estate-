import { useMemo, useState } from 'react';
import { MessageCircle, Mail, X, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import type { Property } from '../data/properties';
import {
  buildPropertyWhatsAppUrl,
  submitPropertyEmailInquiry,
  isWeb3FormsConfigured,
} from '../lib/contact';
import { useSettings } from '../context/SettingsContext';

interface PropertyLeadActionsProps {
  property: Property;
  compact?: boolean;
}

export default function PropertyLeadActions({ property, compact = false }: PropertyLeadActionsProps) {
  const { settings } = useSettings();
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    message: `Hello, I would like more information about ${property.title}.`,
  });

  const whatsappUrl = useMemo(() => buildPropertyWhatsAppUrl({
    id: property.id,
    title: property.title,
    address: property.address,
    city: property.city,
    state: property.state,
    price: property.price,
    beds: property.beds,
    baths: property.baths,
    sqft: property.sqft,
    status: property.status,
    type: property.type,
  }, settings), [property, settings]);

  const configured = useMemo(() => isWeb3FormsConfigured(settings), [settings]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      await submitPropertyEmailInquiry({
        id: property.id,
        title: property.title,
        address: property.address,
        city: property.city,
        state: property.state,
        price: property.price,
        beds: property.beds,
        baths: property.baths,
        sqft: property.sqft,
        status: property.status,
        type: property.type,
      }, formData, settings);
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'Unable to send your inquiry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <div className={`grid ${compact ? 'grid-cols-2 gap-2' : 'grid-cols-2 gap-3'} mt-4`}>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-600"
        >
          <MessageCircle size={16} />
          WhatsApp
        </a>
        <button
          onClick={() => {
            setShowEmailModal(true);
            setSubmitted(false);
            setError('');
          }}
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm font-semibold text-gray-800 transition-colors hover:bg-gray-50"
        >
          <Mail size={16} />
          Email
        </button>
      </div>

      {showEmailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4">
          <div className="relative max-h-[90vh] w-full max-w-lg overflow-auto rounded-3xl bg-white shadow-2xl">
            <button
              onClick={() => setShowEmailModal(false)}
              className="absolute right-4 top-4 rounded-full bg-gray-100 p-2 text-gray-500 transition-colors hover:bg-gray-200 hover:text-gray-800"
            >
              <X size={16} />
            </button>

            <div className="border-b border-gray-100 px-6 py-5 pr-14">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-600">Property Email Inquiry</p>
              <h3 className="mt-2 font-serif text-2xl font-bold text-gray-900">Request details by email</h3>
              <p className="mt-2 text-sm text-gray-500">
                Fill in your details and we'll email the full property inquiry for this listing.
              </p>
            </div>

            <div className="px-6 py-5">
              <div className="mb-5 rounded-2xl bg-gray-50 p-4">
                <div className="text-sm font-semibold text-gray-900">{property.title}</div>
                <div className="mt-1 text-sm text-gray-500">{property.address}, {property.city}, {property.state}</div>
                <div className="mt-2 text-xs text-gray-500">
                  {property.beds} beds • {property.baths} baths • {property.sqft.toLocaleString()} sqft • {property.type}
                </div>
              </div>

              {submitted ? (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-center">
                  <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100">
                    <CheckCircle size={24} className="text-emerald-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900">Inquiry sent</h4>
                  <p className="mt-2 text-sm text-gray-600">
                    Your property request has been sent successfully.
                  </p>
                  <button
                    onClick={() => setShowEmailModal(false)}
                    className="mt-4 rounded-xl bg-gray-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-gray-800"
                  >
                    Close
                  </button>
                </div>
              ) : (
                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  {!configured && (
                    <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                      Web3Forms is not configured yet. Go to <strong>Admin → Settings → API Keys</strong> and paste your access key.
                    </div>
                  )}

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.fullName}
                        onChange={(e) => setFormData((prev) => ({ ...prev, fullName: e.target.value }))}
                        className="w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-accent-400"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-sm font-medium text-gray-700">Phone Number *</label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                        className="w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-accent-400"
                        placeholder="+234 800 000 0000"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-accent-400"
                      placeholder="you@example.com"
                    />
                  </div>

                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-gray-700">Message *</label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-accent-400 resize-none"
                    />
                  </div>

                  {error && (
                    <div className="flex items-start gap-2 rounded-2xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                      <AlertCircle size={16} className="mt-0.5 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitting || !configured}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gray-900 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? <Loader2 size={16} className="animate-spin" /> : <Mail size={16} />}
                    {submitting ? 'Sending...' : 'Send Property Inquiry'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
