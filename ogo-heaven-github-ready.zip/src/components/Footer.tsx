import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, ArrowUpRight } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { getActiveSocials } from '../lib/settings';
import SocialIcon from './SocialIcon';

export default function Footer() {
  const { settings } = useSettings();
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });
  const { company, contact } = settings;
  const activeSocials = getActiveSocials(settings.socials);
  const fullAddress = [contact.addressLine1, contact.addressLine2].filter(Boolean).join(', ');

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* CTA Banner */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="font-serif text-3xl lg:text-4xl text-white mb-2">Ready to make your move?</h2>
              <p className="text-gray-400 text-lg">Let's find the perfect property for your next chapter.</p>
            </div>
            <div className="flex items-center gap-4">
              <Link
                to="/contact"
                className="px-6 py-3 rounded-full bg-white text-gray-900 text-sm font-semibold hover:bg-gray-100 transition-colors"
              >
                Get in Touch
              </Link>
              <Link
                to="/listings"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/30 text-white text-sm font-semibold hover:bg-white/10 transition-colors"
              >
                Browse Listings
                <ArrowUpRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="inline-flex items-center gap-2 mb-4" onClick={scrollToTop}>
              <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                {company.logoUrl ? (
                  <img src={company.logoUrl} alt={company.name} className="w-full h-full object-cover" />
                ) : (
                  <>
                    <span className="font-serif text-gray-900 text-xl font-bold italic">{company.logoText || 'O'}</span>
                    <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-accent-500" />
                  </>
                )}
              </div>
              <div>
                <span className="font-serif text-white text-lg font-semibold leading-tight block">{company.name}</span>
                <span className="block text-[9px] uppercase tracking-[0.2em] text-gray-400">{company.tagline}</span>
              </div>
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed mt-3">
              {company.about}
            </p>
            {activeSocials.length > 0 && (
              <div className="flex items-center gap-3 mt-5">
                {activeSocials.map(({ platform, url }) => (
                  <a
                    key={platform}
                    href={url}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={platform}
                    className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:border-white/30 transition-colors"
                  >
                    <SocialIcon platform={platform} size={16} />
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white text-sm uppercase tracking-wider mb-5">Explore</h4>
            <ul className="space-y-3">
              {[{ label: 'Home', href: '/' }, { label: 'Listings', href: '/listings' }, { label: 'About Us', href: '/about' }, { label: 'Reviews', href: '/reviews' }, { label: 'Blog', href: '/blog' }].map((item) => (
                <li key={item.label}>
                  <Link to={item.href} className="text-sm text-gray-400 hover:text-white transition-colors" onClick={scrollToTop}>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-white text-sm uppercase tracking-wider mb-5">Company</h4>
            <ul className="space-y-3">
              {[{ label: 'About Us', href: '/about' }, { label: 'Contact Us', href: '/contact' }, { label: 'Our Team', href: '/about' }].map((item) => (
                <li key={item.label}>
                  <Link to={item.href} className="text-sm text-gray-400 hover:text-white transition-colors" onClick={scrollToTop}>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white text-sm uppercase tracking-wider mb-5">Contact</h4>
            <ul className="space-y-4">
              <li>
                <a href={`tel:${contact.phone}`} className="flex items-center gap-3 text-sm text-gray-400 hover:text-white transition-colors group">
                  <Phone size={15} className="text-gray-500 group-hover:text-white transition-colors" />
                  {contact.phoneDisplay}
                </a>
              </li>
              <li>
                <a href={`mailto:${contact.email}`} className="flex items-center gap-3 text-sm text-gray-400 hover:text-white transition-colors group">
                  <Mail size={15} className="text-gray-500 group-hover:text-white transition-colors" />
                  {contact.email}
                </a>
              </li>
              <li>
                <span className="flex items-start gap-3 text-sm text-gray-400">
                  <MapPin size={15} className="text-gray-500 mt-0.5 shrink-0" />
                  <span>
                    {fullAddress}<br />{contact.city}, {contact.state}
                  </span>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-gray-500">&copy; {new Date().getFullYear()} {company.name} {company.tagline}. All rights reserved. {company.rcNumber}</p>
          <div className="flex items-center gap-4">
            <p className="text-xs text-gray-500">Licensed Real Estate Agency | {contact.country}</p>
            <Link to="/admin/login" className="text-xs text-gray-600 hover:text-gray-400 transition-colors">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
