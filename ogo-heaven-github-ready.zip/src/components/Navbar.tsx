import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Search } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { cn } from '../utils/cn';

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Listings', href: '/listings' },
  { label: 'About Us', href: '/about' },
  { label: 'Reviews', href: '/reviews' },
  { label: 'Blog', href: '/blog' },
  { label: 'Contact Us', href: '/contact' },
];

export default function Navbar() {
  const { settings } = useSettings();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => { setIsOpen(false); }, [location]);

  const { company, contact } = settings;

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
        scrolled
          ? 'bg-white/90 backdrop-blur-xl shadow-lg shadow-black/[0.02] border-b border-gray-100'
          : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-lg bg-gray-900 flex items-center justify-center transition-transform group-hover:scale-105 relative overflow-hidden">
              {company.logoUrl ? (
                <img src={company.logoUrl} alt={company.name} className="w-full h-full object-cover" />
              ) : (
                <>
                  <span className="font-serif text-white text-xl font-bold italic">{company.logoText || 'O'}</span>
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-accent-400" />
                </>
              )}
            </div>
            <div className="hidden sm:block">
              <span className={cn(
                'font-serif text-lg font-semibold tracking-tight transition-colors leading-tight block',
                scrolled ? 'text-gray-900' : 'text-white'
              )}>
                {company.name}
              </span>
              <span className={cn(
                'block text-[9px] uppercase tracking-[0.2em] transition-colors',
                scrolled ? 'text-gray-500' : 'text-white/70'
              )}>
                {company.tagline}
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => {
              const isActive = link.href === '/'
                ? location.pathname === '/'
                : location.pathname === link.href || location.pathname.startsWith(link.href + '/');
              return (
                <Link
                  key={link.label}
                  to={link.href}
                  className={cn(
                    'text-sm font-medium tracking-wide transition-colors relative py-1',
                    'after:absolute after:bottom-0 after:left-0 after:h-[2px] after:bg-current after:transition-all after:duration-300',
                    isActive
                      ? (scrolled ? 'text-gray-900 after:w-full' : 'text-white after:w-full')
                      : (scrolled ? 'text-gray-600 hover:text-gray-900 after:w-0 hover:after:w-full' : 'text-white/80 hover:text-white after:w-0 hover:after:w-full')
                  )}
                >
                  {link.label}
                </Link>
              );
            })}
          </div>

          {/* Right actions */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={`tel:${contact.phone}`}
              className={cn(
                'flex items-center gap-2 text-sm font-medium transition-colors',
                scrolled ? 'text-gray-700 hover:text-gray-900' : 'text-white/80 hover:text-white'
              )}
            >
              <Phone size={15} />
              <span>{contact.phoneDisplay}</span>
            </a>
            <Link
              to="/listings"
              className="ml-2 inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-accent-500 text-white text-sm font-semibold hover:bg-accent-600 transition-all shadow-lg shadow-accent-500/25 hover:shadow-accent-500/40"
            >
              <Search size={15} />
              Browse Listings
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={cn(
              'lg:hidden p-2 rounded-lg transition-colors',
              scrolled ? 'text-gray-700 hover:bg-gray-100' : 'text-white hover:bg-white/10'
            )}
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          'lg:hidden overflow-hidden transition-all duration-300',
          isOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'
        )}
      >
        <div className="bg-white border-t border-gray-100 px-4 py-4 space-y-1 shadow-xl">
          {navLinks.map((link) => {
            const isActive = link.href === '/'
              ? location.pathname === '/'
              : location.pathname === link.href || location.pathname.startsWith(link.href + '/');
            return (
              <Link
                key={link.label}
                to={link.href}
                className={cn(
                  'block px-4 py-3 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-gray-50 text-gray-900'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                )}
              >
                {link.label}
              </Link>
            );
          })}
          <div className="pt-3 flex flex-col gap-2">
            <a
              href={`tel:${contact.phone}`}
              className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-gray-600 hover:text-gray-900"
            >
              <Phone size={15} />
              {contact.phoneDisplay}
            </a>
            <Link
              to="/listings"
              className="mx-4 flex items-center justify-center gap-2 px-4 py-3 rounded-full bg-gray-900 text-white text-sm font-semibold hover:bg-gray-800 transition-colors"
            >
              <Search size={15} />
              Browse Listings
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
