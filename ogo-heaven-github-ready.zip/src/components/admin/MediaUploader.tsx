import { useState, useRef, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Video, Link as LinkIcon, Loader2, GripVertical } from 'lucide-react';
import { uploadFiles } from '../../lib/backend';
import { cn } from '../../utils/cn';

interface MediaUploaderProps {
  images: string[];
  videos?: string[];
  onImagesChange: (images: string[]) => void;
  onVideosChange?: (videos: string[]) => void;
  disabled?: boolean;
}

interface PendingMedia {
  id: string;
  type: 'image' | 'video';
  preview: string;
  file?: File;
  status: 'pending' | 'uploading' | 'success' | 'error';
}

export default function MediaUploader({
  images,
  videos = [],
  onImagesChange,
  onVideosChange,
  disabled = false,
}: MediaUploaderProps) {
  const [imageFiles, setImageFiles] = useState<PendingMedia[]>([]);
  const [videoFiles, setVideoFiles] = useState<PendingMedia[]>([]);
  const [imageUrl, setImageUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({ current: 0, total: 0 });
  const [dragActive, setDragActive] = useState<'image' | 'video' | null>(null);

  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const generateId = () => Math.random().toString(36).substring(2, 11);

  // Handle drag events
  const handleDrag = useCallback((e: React.DragEvent, type: 'image' | 'video') => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(type);
    } else if (e.type === 'dragleave') {
      setDragActive(null);
    }
  }, []);

  const processFiles = (files: FileList | File[], type: 'image' | 'video') => {
    const fileArray = Array.from(files).filter(file => {
      if (type === 'image') return file.type.startsWith('image/');
      if (type === 'video') return file.type.startsWith('video/');
      return false;
    });

    const newMedia: PendingMedia[] = fileArray.map(file => ({
      id: generateId(),
      type,
      preview: URL.createObjectURL(file),
      file,
      status: 'pending' as const,
    }));

    if (type === 'image') {
      setImageFiles(prev => [...prev, ...newMedia]);
    } else {
      setVideoFiles(prev => [...prev, ...newMedia]);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent, type: 'image' | 'video') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(null);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files, type);
    }
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files, type);
    }
  };

  const removePending = (id: string, type: 'image' | 'video') => {
    if (type === 'image') {
      setImageFiles(prev => prev.filter(f => f.id !== id));
    } else {
      setVideoFiles(prev => prev.filter(f => f.id !== id));
    }
  };

  const removeSaved = (url: string, type: 'image' | 'video') => {
    if (type === 'image') {
      onImagesChange(images.filter(i => i !== url));
    } else {
      onVideosChange?.(videos.filter(v => v !== url));
    }
  };

  const addImageUrl = () => {
    if (!imageUrl.trim()) return;
    // Basic URL validation
    try {
      new URL(imageUrl);
      onImagesChange([...images, imageUrl]);
      setImageUrl('');
    } catch {
      alert('Please enter a valid URL');
    }
  };

  const addVideoUrl = () => {
    if (!videoUrl.trim()) return;
    try {
      new URL(videoUrl);
      onVideosChange?.([...videos, videoUrl]);
      setVideoUrl('');
    } catch {
      alert('Please enter a valid URL');
    }
  };

  const uploadAll = async () => {
    const allFiles = [...imageFiles.filter(f => f.file), ...videoFiles.filter(f => f.file)];
    if (allFiles.length === 0) return;

    setIsUploading(true);
    setUploadProgress({ current: 0, total: allFiles.length });

    try {
      // Upload images
      const imageFilesToUpload = imageFiles.filter(f => f.file);
      if (imageFilesToUpload.length > 0) {
        const imageUrls = await uploadFiles(
          imageFilesToUpload.map(f => f.file!),
          'properties/images',
          (current, total) => setUploadProgress({ current, total })
        );
        onImagesChange([...images, ...imageUrls]);
        setImageFiles([]);
      }

      // Upload videos
      const videoFilesToUpload = videoFiles.filter(f => f.file);
      if (videoFilesToUpload.length > 0) {
        const videoUrls = await uploadFiles(
          videoFilesToUpload.map(f => f.file!),
          'properties/videos',
          (current) => setUploadProgress({ current: imageFilesToUpload.length + current, total: allFiles.length })
        );
        onVideosChange?.([...videos, ...videoUrls]);
        setVideoFiles([]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Error uploading files. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const moveImage = (fromIdx: number, direction: 'up' | 'down') => {
    const newImages = [...images];
    const toIdx = direction === 'up' ? fromIdx - 1 : fromIdx + 1;
    if (toIdx < 0 || toIdx >= newImages.length) return;
    [newImages[fromIdx], newImages[toIdx]] = [newImages[toIdx], newImages[fromIdx]];
    onImagesChange(newImages);
  };

  return (
    <div className="space-y-6">
      {/* Images Section */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <ImageIcon size={18} className="text-accent-500" />
            Property Images
          </h3>
          <span className="text-xs text-gray-500">{images.length + imageFiles.length} images</span>
        </div>

        {/* Saved Images */}
        {images.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mb-4">
            {images.map((url, idx) => (
              <div key={url} className="relative group aspect-square rounded-lg overflow-hidden bg-gray-100">
                <img src={url} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors" />
                <div className="absolute top-1 left-1 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => moveImage(idx, 'up')}
                    disabled={idx === 0}
                    className="p-1 bg-white/90 rounded text-gray-700 hover:bg-white disabled:opacity-30"
                    title="Move up (main photo)"
                  >
                    <GripVertical size={12} />
                  </button>
                </div>
                <button
                  onClick={() => removeSaved(url, 'image')}
                  className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={12} />
                </button>
                {idx === 0 && (
                  <span className="absolute bottom-1 left-1 px-2 py-0.5 bg-accent-500 text-white text-xs rounded-full font-semibold">
                    Main
                  </span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Pending Images */}
        {imageFiles.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Pending upload ({imageFiles.length})</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {imageFiles.map(file => (
                <div key={file.id} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 border-2 border-dashed border-accent-300">
                  <img src={file.preview} alt="" className="w-full h-full object-cover" />
                  <button
                    onClick={() => removePending(file.id, 'image')}
                    className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Drag & Drop Zone for Images */}
        <div
          onDragEnter={(e) => handleDrag(e, 'image')}
          onDragLeave={(e) => handleDrag(e, 'image')}
          onDragOver={(e) => handleDrag(e, 'image')}
          onDrop={(e) => handleDrop(e, 'image')}
          onClick={() => imageInputRef.current?.click()}
          className={cn(
            'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors',
            dragActive === 'image'
              ? 'border-accent-500 bg-accent-50'
              : 'border-gray-200 hover:border-accent-300 hover:bg-gray-50'
          )}
        >
          <Upload size={32} className={cn('mx-auto mb-2', dragActive === 'image' ? 'text-accent-500' : 'text-gray-400')} />
          <p className="text-sm font-medium text-gray-700">
            Drag & drop images here, or <span className="text-accent-600">click to browse</span>
          </p>
          <p className="text-xs text-gray-400 mt-1">PNG, JPG, WEBP • Multiple files supported</p>
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => handleFileInput(e, 'image')}
            className="hidden"
          />
        </div>

        {/* Image URL Input */}
        <div className="mt-4">
          <label className="text-xs font-medium text-gray-700 block mb-1.5 flex items-center gap-1">
            <LinkIcon size={12} /> Or add via URL
          </label>
          <div className="flex gap-2">
            <input
              type="url"
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400"
            />
            <button
              onClick={addImageUrl}
              disabled={!imageUrl.trim()}
              className="px-4 py-2 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Add
            </button>
          </div>
        </div>
      </div>

      {/* Videos Section */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <Video size={18} className="text-accent-500" />
            Property Videos
          </h3>
          <span className="text-xs text-gray-500">{videos.length + videoFiles.length} videos</span>
        </div>

        {/* Saved Videos */}
        {videos.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            {videos.map((url) => (
              <div key={url} className="relative group aspect-video rounded-lg overflow-hidden bg-gray-900">
                <video src={url} className="w-full h-full object-cover" controls />
                <button
                  onClick={() => removeSaved(url, 'video')}
                  className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Pending Videos */}
        {videoFiles.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Pending upload ({videoFiles.length})</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {videoFiles.map(file => (
                <div key={file.id} className="relative aspect-video rounded-lg overflow-hidden bg-gray-900 border-2 border-dashed border-accent-300">
                  <video src={file.preview} className="w-full h-full object-cover" controls />
                  <button
                    onClick={() => removePending(file.id, 'video')}
                    className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Drag & Drop Zone for Videos */}
        <div
          onDragEnter={(e) => handleDrag(e, 'video')}
          onDragLeave={(e) => handleDrag(e, 'video')}
          onDragOver={(e) => handleDrag(e, 'video')}
          onDrop={(e) => handleDrop(e, 'video')}
          onClick={() => videoInputRef.current?.click()}
          className={cn(
            'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors',
            dragActive === 'video'
              ? 'border-accent-500 bg-accent-50'
              : 'border-gray-200 hover:border-accent-300 hover:bg-gray-50'
          )}
        >
          <Video size={32} className={cn('mx-auto mb-2', dragActive === 'video' ? 'text-accent-500' : 'text-gray-400')} />
          <p className="text-sm font-medium text-gray-700">
            Drag & drop videos here, or <span className="text-accent-600">click to browse</span>
          </p>
          <p className="text-xs text-gray-400 mt-1">MP4, MOV, WEBM • Max 50MB per file</p>
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*"
            multiple
            onChange={(e) => handleFileInput(e, 'video')}
            className="hidden"
          />
        </div>

        {/* Video URL Input */}
        <div className="mt-4">
          <label className="text-xs font-medium text-gray-700 block mb-1.5 flex items-center gap-1">
            <LinkIcon size={12} /> Or add video URL (MP4, YouTube embed, etc.)
          </label>
          <div className="flex gap-2">
            <input
              type="url"
              placeholder="https://example.com/video.mp4"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-accent-400"
            />
            <button
              onClick={addVideoUrl}
              disabled={!videoUrl.trim()}
              className="px-4 py-2 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Add
            </button>
          </div>
        </div>
      </div>

      {/* Upload Button */}
      {(imageFiles.length > 0 || videoFiles.length > 0) && (
        <button
          onClick={uploadAll}
          disabled={isUploading || disabled}
          className="w-full py-3 rounded-xl bg-accent-500 text-white font-semibold text-sm hover:bg-accent-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isUploading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Uploading {uploadProgress.current} / {uploadProgress.total}...
            </>
          ) : (
            <>
              <Upload size={16} />
              Upload {imageFiles.length + videoFiles.length} file(s) to Cloud Storage
            </>
          )}
        </button>
      )}
    </div>
  );
}
