import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Building2, FileText, Users, MessageSquare, Star, Settings, LogOut, Menu, X,
  ExternalLink
} from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { getAdminSession, clearAdminSession, isAdminOpenAccess, setAdminSession } from '../../lib/adminAuth';
import { cn } from '../../utils/cn';

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { settings } = useSettings();
  const [session, setSession] = useState(() => getAdminSession());
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const open = isAdminOpenAccess(settings.security.adminUsername, settings.security.adminPassword);

  // Auth logic:
  // - If open access and no session: auto-create session (direct access to dashboard)
  // - If password set and no session: redirect to login
  useEffect(() => {
    if (open && !session) {
      setAdminSession({ username: 'open-access', loggedAt: new Date().toISOString() });
      setSession(getAdminSession());
    } else if (!open && !session) {
      navigate('/admin/login');
    }
  }, [open, session, navigate]);

  // Re-check session on location change
  useEffect(() => {
    setSession(getAdminSession());
  }, [location.pathname]);

  const handleSignOut = () => {
    clearAdminSession();
    setSession(null);
    navigate('/admin/login');
  };

  const navItems = [
    { label: 'Dashboard', icon: LayoutDashboard, href: '/admin' },
    { label: 'Properties', icon: Building2, href: '/admin/properties' },
    { label: 'Blog Posts', icon: FileText, href: '/admin/blog' },
    { label: 'Team', icon: Users, href: '/admin/team' },
    { label: 'Reviews', icon: Star, href: '/admin/reviews' },
    { label: 'Inquiries', icon: MessageSquare, href: '/admin/inquiries' },
    { label: 'Settings', icon: Settings, href: '/admin/settings' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-2 rounded-lg text-gray-600 hover:bg-gray-100"
        >
          <Menu size={20} />
        </button>
        <span className="font-serif font-semibold text-gray-900">Admin Panel</span>
        <Link to="/" className="p-2 rounded-lg text-gray-600 hover:bg-gray-100">
          <ExternalLink size={18} />
        </Link>
      </div>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 bg-gray-900 text-white transform transition-transform lg:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                {settings.company.logoUrl ? (
                  <img src={settings.company.logoUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  <>
                    <span className="font-serif text-gray-900 text-lg font-bold italic">{settings.company.logoText || 'O'}</span>
                    <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-accent-500" />
                  </>
                )}
              </div>
              <div>
                <span className="font-serif text-sm font-semibold block">{settings.company.name}</span>
                <span className="text-[9px] uppercase tracking-wider text-gray-400">Admin Panel</span>
              </div>
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1 text-gray-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        <nav className="p-4 space-y-1">
          {navItems.map(item => {
            const isActive = location.pathname === item.href ||
              (item.href !== '/admin' && location.pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-accent-500 text-white'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                )}
              >
                <item.icon size={18} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-accent-500 flex items-center justify-center text-white font-semibold text-sm">
              {(session?.username || 'A')[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">{session?.username || 'Admin'}</div>
              <div className="text-xs text-gray-400">{open ? 'Open access' : 'Administrator'}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <Link
              to="/"
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-white/10 text-gray-300 text-xs font-medium hover:bg-white/5"
            >
              <ExternalLink size={13} />
              View Site
            </Link>
            <button
              onClick={handleSignOut}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-white/10 text-gray-300 text-xs font-medium hover:bg-white/5"
            >
              <LogOut size={13} />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden fixed inset-0 z-40 bg-black/50"
        />
      )}

      {/* Main Content */}
      <main className="lg:pl-64 pt-14 lg:pt-0">
        <div className="p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
