import { Link } from 'react-router-dom';
import { Bed, Bath, Square, MapPin, Heart } from 'lucide-react';
import { useState } from 'react';
import { Property } from '../data/properties';
import { formatPrice } from '../utils/currency';
import PropertyLeadActions from './PropertyLeadActions';

export default function PropertyCard({ property, featured = false, showLeadActions = false }: { property: Property; featured?: boolean; showLeadActions?: boolean }) {
  const [isLiked, setIsLiked] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);

  const statusColors = {
    'For Sale': 'bg-emerald-500',
    'For Rent': 'bg-indigo-500',
    'Sold': 'bg-red-500',
    'Coming Soon': 'bg-blue-500',
  };

  const img = property.images[imgIdx] || property.images[0];

  return (
    <div className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-2xl hover:shadow-gray-200/60 hover:-translate-y-1 transition-all duration-500">
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={img}
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />

        {/* Status badge */}
        <span className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold text-white ${statusColors[property.status]}`}>
          {property.status}
        </span>

        {/* Like button */}
        <button
          onClick={(e) => { e.preventDefault(); setIsLiked(!isLiked); }}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors shadow-lg"
        >
          <Heart size={16} className={isLiked ? 'fill-red-500 text-red-500' : 'text-gray-700'} />
        </button>

        {/* Image nav dots */}
        {property.images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {property.images.map((_, i) => (
              <button
                key={i}
                onClick={(e) => { e.preventDefault(); setImgIdx(i); }}
                className={`w-2 h-2 rounded-full transition-all ${i === imgIdx ? 'bg-white w-5' : 'bg-white/60 hover:bg-white/80'}`}
              />
            ))}
          </div>
        )}

        {/* Price */}
        <div className="absolute bottom-10 left-3 right-3">
          <span className="text-xl font-bold text-white drop-shadow-lg">{formatPrice(property.price)}</span>
          {property.status === 'For Rent' && property.rentalPeriod && (
            <span className="text-sm text-white/80 font-medium ml-1">/{property.rentalPeriod === 'weekly' ? 'wk' : property.rentalPeriod === 'monthly' ? 'mo' : 'yr'}</span>
          )}
        </div>
      </div>

      {/* Content */}
      <Link to={`/property/${property.id}`} className="block p-4 sm:p-5">
        <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1 group-hover:text-accent-600 transition-colors">
          {featured ? property.title : property.address}
        </h3>
        <div className="flex items-center gap-1 text-gray-500 text-sm mb-3">
          <MapPin size={13} />
          <span>{property.city}, {property.state}</span>
        </div>

        <div className="flex items-center gap-4 pt-3 border-t border-gray-100">
          {[
            { icon: Bed, value: property.beds, label: 'Beds' },
            { icon: Bath, value: property.baths, label: 'Baths' },
            { icon: Square, value: property.sqft.toLocaleString(), label: 'Sq Ft' },
          ].map(({ icon: Icon, value, label }) => (
            <div key={label} className="flex items-center gap-1.5 text-sm">
              <Icon size={15} className="text-gray-400" />
              <span className="font-medium text-gray-700">{value}</span>
              <span className="text-gray-400">{label}</span>
            </div>
          ))}
        </div>
      </Link>

      {showLeadActions && (
        <div className="px-4 pb-4 sm:px-5 sm:pb-5 pt-0 border-t border-gray-100/80">
          <PropertyLeadActions property={property} compact />
        </div>
      )}
    </div>
  );
}
