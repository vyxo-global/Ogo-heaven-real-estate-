import { Link, useLocation } from 'react-router-dom';
import { Shield, Lock } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { isAdminOpenAccess } from '../lib/adminAuth';

export default function FloatingAdminButton() {
  const { pathname } = useLocation();
  const { settings } = useSettings();

  // Hide on admin pages
  if (pathname.startsWith('/admin')) return null;

  const openAccess = isAdminOpenAccess(
    settings.security.adminUsername,
    settings.security.adminPassword,
  );

  return (
    <Link
      to="/admin"
      className="fixed bottom-6 right-6 z-40 group"
      title="Admin Dashboard"
    >
      <div className="flex items-center gap-2 bg-gray-900 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 px-4 py-3 hover:bg-gray-800 hover:scale-105">
        <div className="w-7 h-7 rounded-full bg-accent-500 flex items-center justify-center shrink-0">
          {openAccess ? <Shield size={14} /> : <Lock size={14} />}
        </div>
        <span className="text-sm font-semibold">Admin</span>
      </div>
    </Link>
  );
}
